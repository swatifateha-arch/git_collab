# WhatsApp Chat Export: Aashu
Export date: November 3, 2026 at 12:46 PM

---

## April 25, 2026

[5:58 PM] **You:** U.P.C Tray Set for Serving, Serving Tray Set of 3, Premium Printed Tray for Serving/Multi-Use Nashta Plate (Small, Medium & Large) 
 https://amzn.in/d/03s5VCa3

---

## April 26, 2026

[12:44 AM] **You:** RED RIBBON DECOR Heavy Luxury Premium Shining Foil Chinaar Print Blackout Curtains for Door, 4x7 Feet, Island Aqua, Single Piece 
 https://amzn.in/d/07oxNm16

---

## April 27, 2026

[8:03 PM] **You:** हे स्वामी जी 
भोजन में आज क्या ग्रहण कीजियेगा 
कृपया फरमाइए 😂🙏

[8:03 PM] **Aashu:** ye sab bhi chatgpt se hi koj rahi

[8:03 PM] **Aashu:** kya man hai aapko

[8:04 PM] **You:**
> _Aashu: kya man hai aapko_
आप बताइये आप जो खाएंगे उसी का परसाद समझ कर हम खा लेंगे

[8:05 PM] **Aashu:**
> _You: आप बताइये आप जो खाएंगे उसी का परसाद समझ कर हम खा लेंगे_
full fun kar rahi kya baat hai

[8:05 PM] **Aashu:** tm batao na kya khayegi

[8:05 PM] **Aashu:** egg curry khayegi

[8:05 PM] **Aashu:** bahut din ho gaya egg curry chawal

[8:05 PM] **Aashu:** pani aa gaya na aise

[8:05 PM] **You:** ना ना ये गुस्ताखी आज नहीं एकादशी है स्वामी जी

[8:06 PM] **You:**
> _Aashu: pani aa gaya na aise_
जी आ तो गया

[8:06 PM] **Aashu:**
> _You: ना ना ये गुस्ताखी आज नहीं एकादशी है स्वामी जी_
ohh accha haa bhul hi gaye

[8:06 PM] **Aashu:** phir chawal ke sath koi sabji bana lo accha

[8:06 PM] **Aashu:** kahe ki chawal daal idhar bahut ho gaya hai

[8:07 PM] **Aashu:** aur aaj chana de dena fulne kal ghugni chawal khana hai

[8:07 PM] **Aashu:** aur suno na milk nahi hai na

[8:07 PM] **You:**
> _Aashu: phir chawal ke sath koi sabji bana lo accha_
जी हम विचार करते हैं आपके कथनानुसार🙏

[8:08 PM] **Aashu:** aur kuch mangana hai bata do koi sabji chota mota

[8:08 PM] **You:**
> _Aashu: aur kuch mangana hai bata do koi sabji chota mota_
थोड़ा समय दीजिये

[8:08 PM] **Aashu:**
> _You: थोड़ा समय दीजिये_
jldii batana hum order kar rahe dhoodh

[8:09 PM] **Aashu:** agar nai kuch batayegi to hum kuch or kar denge thora mora

[8:09 PM] **You:**
> _Aashu: agar nai kuch batayegi to hum kuch or kar denge thora mora_
बस 10 मिनट

[8:09 PM] **Aashu:** rahne do

[8:09 PM] **Aashu:** egg order kar rahe

[8:10 PM] **Aashu:** [Forwarded] [Image]

[8:11 PM] **You:** गोभी और कद्दू और धनिया

[8:13 PM] **Aashu:** okk

[8:18 PM] **Aashu:** 5 min me aa jayega

[8:18 PM] **Aashu:** dekhte rehna

[8:26 PM] **You:** Okok

---

## April 28, 2026

[1:02 PM] **Aashu:** khana hua aaplog ka

[1:27 PM] **You:** Ji aapka hi wait kar rahe hain

[1:27 PM] **You:** Aapke sath hi karenge aaiye na

[1:46 PM] **Aashu:** 2:30 se 2:40 ho jayega humko

[1:46 PM] **Aashu:** halka sa kaam hai

[1:46 PM] **Aashu:** isko kar ke aayenge

[1:47 PM] **You:** Ok no problem aram se aao

[1:51 PM] **You:** Nikloge to message kar dena ek baar

[1:52 PM] **Aashu:** ok

[2:07 PM] **Aashu:** nikal rahe

[2:14 PM] **You:** Ok

---

## April 29, 2026

[11:23 AM] **You:** Mera jo is bar axis bank ka account khula tha uska upi pin kya dale the yaad hai kya

[11:23 AM] **You:** Mai bhul gayi

[11:24 AM] **You:** Phone pe pe add kiye the na

[11:26 AM] **Aashu:** hum dale the kya

[11:26 AM] **Aashu:** exact yaad nahi bro

[11:26 AM] **You:**
> _Aashu: hum dale the kya_
Haa

[11:27 AM] **You:** Matlab jab daal rhe the tab wahi the mujhe bhi yaad nahi aa raha

[11:34 AM] **Aashu:** 2008 se try kaena

[11:34 AM] **Aashu:** karna

[11:35 AM] **You:** 6 digit h

[11:53 AM] **Aashu:** 200008

[11:53 AM] **Aashu:** ya 200004

[11:53 AM] **Aashu:** please try

[12:05 PM] **You:** Ok

[12:06 PM] **You:** Not working 😔

[1:28 PM] **Aashu:** kya mangwana hai bro

[1:28 PM] **Aashu:** say me

[1:28 PM] **Aashu:** i will order for u whatever u say

[1:29 PM] **You:** Come na then we'll decide in evening

[1:29 PM] **Aashu:** accha ok

[1:29 PM] **Aashu:** i will come soon dont worry

[1:30 PM] **Aashu:** and may be a person will come to take measurement of utilitzy area

[1:30 PM] **You:** Ohh Today

[1:30 PM] **You:** Okok

[1:30 PM] **Aashu:** yes he called me

[1:30 PM] **You:** Ok nice

[1:30 PM] **You:** Come I'm waiting 😁

[1:31 PM] **Aashu:** till 2:30

[1:31 PM] **You:** Text me when you leave the office

[1:40 PM] **Aashu:** sure mam

[1:57 PM] **Aashu:** nikal rahe

[2:13 PM] **You:** Ok

---

## April 30, 2026

[12:26 AM] **You:** Hello

[12:26 AM] **You:** Kab aana hai

[2:29 PM] **Aashu:** [Image]

[2:34 PM] **Aashu:** [Image]

[2:48 PM] **You:**
> _Aashu: Image_
Cricketer figure name Rohit Sharma lite version 😅😅

[7:08 PM] **You:** [Image]

---

## May 1, 2026

[10:41 AM] **You:** Pigeon Radiant Infrared Cooktop 2000 Watt, Compatable for all cooking utensils, Black, Medium 
 https://amzn.in/d/07KxUVpY

[10:41 AM] **You:** Deal: LONGER 2500W Infrared Cooktop with Grill Rack – Dual Control (Touch + Knob), Crystal Glass Hot Plate, Digital Display, 240V Portable Electric Stove, Universal Cookware Compatible 
 https://amzn.in/d/06FhwH4k

[10:42 AM] **You:** Crompton Infrared 2200W Induction Cooktop with Feather Touch Controls, Rotary Knob and Adjustable Power Levels, LED Display, Overvoltage & Overheat Protection | Efficient Electric Cooker Kitchen 
 https://amzn.in/d/0bZ2W4dh

[10:57 AM] **You:** Pigeon Eva Infrared Cooktop 2000 Watts Black (with Free Stainless Steel Grill, Full touch Panel, Auto shut off and Overheat Protection) 
 https://amzn.in/d/0c4Lu2iN

[11:32 AM] **You:** Deal: iBELL 20YO 2000W Induction Cooktop featuring Full Touch Control, Auto Shut-Off, Overheat Protection, Durable Crystal Glass Surface, Compact Build & 1+1 Year Warranty (Black) 
 https://amzn.in/d/05EE6UGN

[11:34 AM] **You:** Pigeon By Stovekraft ABS Plastic Acer Plus Induction Cooktop 1800 Watts With Feather Touch Control - Black 
 https://amzn.in/d/0gz4wuTh

[11:40 AM] **Aashu:** Take a look at this 1800 W Induction Cooktop Push Button on Flipkart https://dl.flipkart.com/s/L7VdsVuuuN

[11:42 AM] **Aashu:** Take a look at this 1800 W Induction Cooktop Push Button on Flipkart https://dl.flipkart.com/s/2zvdgUNNNN

[5:44 PM] **You:** Hello

[5:44 PM] **You:** Kahan..?

[6:25 PM] **Aashu:** bus yahi tumhare dil me

[6:35 PM] **You:** 😯😯😯

[7:06 PM] **Aashu:** [Forwarded] Location: 13.038037300109863, 77.7475357055664 — https://maps.google.com/?q=13.038037300109863,77.7475357055664

---

## May 2, 2026

[6:59 PM] **You:** Jab banana hoga to batana

[7:03 PM] **Aashu:** 7;30 me bana lo

[7:04 PM] **You:** 7 30 me jana hai niche

[7:23 PM] **Aashu:** mi

[11:07 PM] **You:** Khana kab khana hai

---

## May 3, 2026

[2:20 AM] **Aashu:** khayenge aaram se

[2:22 AM] **You:** Kha ke so jao ab

[3:27 AM] **You:** Nind nhi aa rhi

[5:53 PM] **You:** Add2Cart Pre-Seasoned Tadka Pan, Compatible with Gas | Toxin-Free, Chemical Coating-Free, 100% Pure (Black Stainless Steel, 500ML) 
 https://amzn.in/d/02YILXmZ

[5:54 PM] **You:** C (DEVICE) Iron Tadka Pan 12 cm with Stainless Steel Whisk | Mini Tempering Pan for Dal & Spices | Heavy Duty Iron Cookware | Gas Stove Compatible | Kitchen Combo Set 
 https://amzn.in/d/071J8OL2

---

## May 4, 2026

[8:39 AM] **Aashu:** [Forwarded] [Document] New Doc 05-04-2026 07.29.pdf

[2:51 PM] **You:** [Document] IF26050442252431

[2:57 PM] **Aashu:** [Image]

[3:53 PM] **You:** https://www.myntra.com/mailers/bottomwear/glitchez/glitchez-women-90's-baggy-fit-high-rise-faded-jeans/31178344/buy?utm_source=social_share_pdp&utm_medium=deeplink&utm_campaign=social_share_pdp_deeplink

[3:53 PM] **You:** Dekhna

[5:38 PM] **Aashu:**
> _You: https://www.myntra.com/mailers/bottomwear/glitchez/glitchez-women-90's-baggy-fit-high-rise-faded-jeans/31178344/buy?utm_source=social_share_pdp&utm_medium=deeplink&utm_campaign=social_share_pdp_deeplink_
tmko sahi lag reha to manga lo

---

## May 7, 2026

[3:28 AM] **Aashu:** [Document] https://www.ixigo.com/image/upload/eTicket_IF26050642729343_48a93396-507a-425f-959a-79255001b48e.pdf

[4:44 AM] **Aashu:** [Forwarded] [Document] IF26050642729615

---

## May 10, 2026

[9:29 AM] **Aashu:**
> _You: Image: Happy mother's day Mumma ❤️🫀_
gajab

[7:30 PM] **You:** [Contact: BEGIN:VCARD
VERSION:3.0
N:❤️;Mamma;;;
FN:Mamma ❤️
item1.TEL;waid=917250069226:+91 72500 69226
item1.X-ABLabel:Phone
PHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAGBwUIAwQJAQL/xAA+EAABAwIEBAMGAwUHBQAAAAABAgMEBREABhIhBxMxQSJRYQgUFTJxgUKRoQkjJFKxFhczQ1OCwWJyssLh/8QAHAEAAgIDAQEAAAAAAAAAAAAABAYDBQACBwEI/8QALhEAAgICAQIDBwMFAAAAAAAAAQIAAwQRIRIxBRNBBiJRYXGRsRQygSOhwdHh/9oADAMBAAIRAxEAPwCz3w4/y432qdeMDbEt7n6DEixA/henQ4gQ7aY3aDHw7zTjz3FPlbBKYg8jjTdi2O4wTvUFA3B+WhMdpRIAABN79Bjmv7WXtOS+ImaHcq0CQtvLURxTbqmTvOcCrayf9MfhT0PzHsE219triWvhzwdqiYjnKqNTAgsLF7o131EEdDoC7HzGOeHBPhdL4lZgDSboiIUnmudrX6f/AD1xuLAqmxuwktdRscKo5Mk+GDqmqq/IMVEhTTRtq3CbkA9PriL4icPa1lerSXpcJQiqWSFtgkAE9Di/mQeBVCyahp2HG1SEp+ddib4Ia9w6TXmltutJcQrqDYf8YoT4kRcbEHEZR4eppFZ7jZ39pynrsSPJYQVJs5bZQO4wJvBTSwkkW/ri4HtM+zI9l6CuuUJtRss8+M30ttun163xUhbWtK0K8Kx4gD388MWNkLkL1LKK+h8dulppKOpQB64nci0ROY86UGkkXE+oR4pv5LcSn/nEHosb3vgk4fZlRkrOtEzAYon/AAuY1MTHLnLDikKCkjVY23A7YJtDmpvLHvaOvrriDggEb7TvnzNsScV4KhdBsd8DYk277Yk4MkGI4PI4oq97krdpuOOgdhiNmyA2FE9sZFv3HXEXUngpKgDgljIFEoj+0iqrjlBytCJIQ9Ocd37lDdv/AHwLeydR00+ktPFAQtw6lKPne36WwSftDaU5U6FlepISrTEqLkdywPhDg+Y/dAH3GFrkrPhyLSZcZyqx6JFjTHmW9TIeceKVKO2ogJHQX3ufLAtpL1ite5Mt8PpVy59JfGmIR7sgpdTqA7YlESoyACtafpfFQ8k8Za/XpLUZMyLKhSxojvsJUy4oEkXtcjse4tbB3xOy7XskZRgQo9VqM5htkIceL5U+5sdluAXue5Fj5Yp7aFQit20TGJLepepRG9mRugV5L0NVQhl+x/hlOp1X+l7g45pe1Zwm/u8zqZsNgM02oErQGx4EqFtQH53++LM5Fr+ZWg9TY2T2VQS3r98WpoJeVYXSEfNq3N1qV+Enc9cXtJcPKlnPg3He+HvR5sR9t5tlx1K1C5KSnUCbiyj+mJcc/ochR1cGC5C/qaCNcic+XGSlq9uow5+BvA6g8ScmVus1jMfwd6NIEaKwhxlK1EI1KVpcUNY3A2KbEdd9jxHsJcUc/Nio8P8AKEus5fKQ0tyXVILTzb4A1oKVuNk9QQQm1ldcDGZPYV495fdQ3K4W1t3cJSafHRLHlupkqH3OG6u9LFDK2t/SK7KaHIZQdfXX9iJ1pdlaOpxvU2fqacTfA0/L6774zUubd9Sb3288UqA7nrdoQOTLd8RlTnaEEnf0xicfuTcm2NCa9f8ArifRkMrJ7WrKanktiMXgluPPZlvJv1Rvf8jY4geFHs6UnN+VWKtKW21LnIK3kyWuYClatenqO56eeDXiZRZfEyHUWYI5FNh6161i6priN9Av8qLixP4r+Q3FsocRZFBpq4WyVMjSN9tttsU+WLQQtZ1uMnhoSxT1ekKJPCih5BmR3YbnvFQNtQSkWQgDayRcjy3OHnObYmpi8+N7zHdaTqbLdwRa++K0VuqVB1pFRRVlRZa1guErCQR2Sb/0xM0nOUisstormbCzFYIOiLJKPP5tB6b9Dt+QxTX4r2HzGbZEY6gNdKLHVSaXkZqYeVDZakIOotOpspPfvuMR3FZ+DWqKqFH0lLpSgaD64X1fqdCzDyn6JNW7OjkNqdZClhzpYK8jbcHE1lajTKpOajuyAFpBcK1pKkpCQVEkA+mPVo6itgJLfOQWstQbq4AhDQ6DLTAjqZqMmDYbiOhspUe5OpB3OCKA7XKWo8jMMw9wFpQP/AJw1KPSmqdSo0ZtjShttKTcXubbk+uMj1OirHiitKv/ADNjHQ8awVUJWw5AE5plbuuawHgkxTyahqUd9vTHlKqKUTwCqwIOBqXUtKidVgMDT2aFszAUWuSbb4ovNFfJlqayeBG47Um9R8YxrSJ7RQfGOnXCpezgVtrPMsUg3HljFAzSKgXEtucxTYBWEAnTfEJz0TvJEwrbAWUEgfASWotRhxoKcvOKSzUmtSFBXdvUf3g8wR+tx2OAXirktNOk/GIzCHIzilJlNtk2T4joV9CkgH1HridVU5DrxWxFLik76nNhfCo42cRs5UxmmwostuMxPkiO+hllPiaCFOLF1XIuEadj+LbAz+I49/8AT3zDKMTIocWDt67nqsq0qatEz3cSCpJRd8czSL9LKuP0wZZMoDceYHodMYYVbSXGGEtm31SP6YCcv1V+I226BzWlgEpte4wc0niJLjL0tRyofyhJGAtkqeI2VX2IOlX0IxHoiW6eSUpaUBsbd++CPhHMixa4+pUptM5xopZZURqW3ca1Ad7HSPv64X9PqE7MrgVJaDDI303uo/XywD8SKrmXL3ELKc2h08TIDJdbeKXS2pKjpKd0gmxCVdiOtxjPD2CZKiztz+JU+JdVmOwXk/8AZe6HXpYA8SFDyUgY3kZhdT88aM4PVsYW2RM1NZloUea2VNKN21suEFTa0mykmx7EHfv1F74K0SgbDUDh2ZR6RDBMqnmCrckqSlZFu98AEpFarkd2RTmnlxY6tT8hoglsCxO17nY9QDYXPQHBLAoMvOdaciNOFphsFb72kkJHl9T2HphyQ2Kbl2NDhxeRHpjbSElCQUlR+YqOpagTf5ugJvtfCFn5nljoT934jlhqiWLZYvUoPI+PylXJ1QW9ZKta1W2v0+uN/IlcFGzSwHllMWSQw6CemoixP0Nj9L4neLOTE5MzdKiRt4Wv3mKUg6SysmyB/wBu6f8AbgLLaZTKZCEJUTdJKfQ4UevfvNPpaunFz8ALQAK3XjQ1rf8Ar8x9LYMdpxCki6DYKH4hhN8Z4QepcedsDTpbcpSlbAN3KHTf0bWs/bDeoFRXmbLMSenxPgcp646rAFz99j98ROZcoIrlNfjPICkuoKFAjqCLb4OoIRw3pOE31PU7U2DTKdfaKihxkxW0sqTqbT8t99sGNLjJbWLKCU+RGInh9laQ7lampmhYfYSY7i3AQVKbUW1H7lJOGXFys0EJJFyPTrhjS5ACu4AAx5mSmJEaMEtfM51OI/MMcxlUma42la26rEbQVgKsHXAwoi/fQ6rf1wXQKGGtItskDGhnel605eZCyjm1mKTpF9kL5nT/AGYAdlLd5v2ENINLepIWuCeVzFa3EJFgtVrXPrYAX9BiQRmp+BYSrtdhqO354koqEsMAHoB1O+F7mKW7mKTzW0qchiQmIwlDrYDq1XBV4upG5HX5Tt1Kdas2/GXhuJCcGrKbZGvnB3hLxApjLnwdCG2aitZUpLg2k9dwQATpBsU7m247hJYmM1IXKKRZSdZbTpAQnc+I2SL9PPbb1tTvL081atqd5i08lQ0rQogpVe9wR3GLIZczItMFtc9bzxbaN5DS9JWL3NyB4VnbfodPY2B3z8dfNJXvAqC3QGn3xfYNXyjDkEoRIpilENtG4DJSnWDt2IQR6BXQ4Q+XZYkoDSVKLYurV0Bubj9LYLOMucWqZltTanihkSeYG1ctCU3HbTYqSASbFJsFG+xF1rluquxGwoRwlBNgp1RCvsi2w6gXN9unTFPZV7pIE7X7HZTvhvjv2U7H8+n35/mP3g/Wm4Fcco8on3acP3RtslwDYffp9bYbcigNgnln8xir1OlylrakocUl5pQWhaR8pHQjy/XFnsr5ojZhy5GqS3m2VaQl8LVbS4B4hv8An9LYCCt6HmV3tVgGu1cxBw3B+vp9x+IDUCmfCc8V6jO/4ExIqcRKjfe4Q+lI7JSSyr1L5wWrg8oWNgcaueKfMcaZqlHhyJdThAyYqW0KDcggeJoq+WziSU97EpUBdItOUdh/M1KhVOKqO1S5jaXm39fMVy1AFKwE7FJBBuFdCDixRjodUQP29+JghNFRGsbYh83aDmrJLXNabSzUXJbutQSeWmK+33/63W8GD9BiUiK9LqVWCIsUhch51YjtIRp1KPdRCQepIBsT0wkU51/tVnuZPy5HXIdlNilUBltLY5jalgvvrUu5VrW22lOr8DYUCQ4QZ+sKOrU3x8ds23y6efUn0A9SSewjOz9nIQI0amwm1vTp60ttpWkpSQT2Jte/QWPf6Yx5cppn1NDiYEaLCiApEhtakpfUn/N1WsspBGhSkghTunmKBSD80fKLC578aQ7NYqAQqXVJE0MuJdbSDzG0pbusoUhTaQkKWmzhGxtqMnqfGpDUj3dtiOwggv6kBvTp0gN28NrEbghJPyqFxcjEtbwV1Jcp6cZPJpO/n8f8a+Hx78bn/9k=
END:VCARD]

---

## May 13, 2026

[8:38 AM] **Aashu:** [Forwarded] [Document] IF26051143446691

---

## May 14, 2026

[7:46 AM] **You:** Chay piyoge

---

## May 15, 2026

[5:23 PM] **You:** _You deleted this message_

---

## May 16, 2026

[11:55 AM] **Aashu:** bro

[11:55 AM] **Aashu:** ac chalwa lena

[11:55 AM] **Aashu:** aur thanda kar lena matlab kam kar lena

[11:59 AM] **You:**
> _Aashu: aur thanda kar lena matlab kam kar lena_
Haa haa kiye hain

[12:02 PM] **Aashu:** okk

[12:02 PM] **Aashu:** kuch problem ho to call karna

[12:05 PM] **You:** Haa koi dikkat nahi h

[12:05 PM] **You:** Chill

[12:14 PM] **Aashu:** okk

[12:15 PM] **Aashu:** _This message was deleted_

[12:15 PM] **Aashu:** wo jo 200rs mummy dene boli hai wo lalu ko dena

[12:15 PM] **Aashu:** driver ko nhi ok

[12:16 PM] **You:** Hnn pata hai

[12:34 PM] **You:** [album message]

[12:34 PM] **You:** [Image]

[12:34 PM] **You:** [Image]

[12:34 PM] **You:** Ye bhi kah raha aa jaye airport 😅😅

[12:35 PM] **Aashu:**
> _You: Ye bhi kah raha aa jaye airport 😅😅_
dekh lo

[12:36 PM] **Aashu:** kahe paresan karegi

[12:37 PM] **You:** Kaha rha aa jate hain drop kar denge

[12:40 PM] **You:** [Image]

[12:41 PM] **Aashu:**
> _You: Image_
kon sonu bhaiya hai

[12:42 PM] **Aashu:** fhua wala

[12:42 PM] **You:** Fua wale

[12:42 PM] **Aashu:** aur adarsh ko dikkat hoga mtlb hum nhi samje

[12:42 PM] **Aashu:** kya bol rahe

[12:43 PM] **You:**
> _Aashu: aur adarsh ko dikkat hoga mtlb hum nhi samje_
Screenshot liye na to uske liye puch kyu ki wahi bole dikhane ke liye wo log worried h ki problem na ho jaye akle jane me

[12:43 PM] **You:** Isliye

[12:44 PM] **Aashu:** accha

[12:48 PM] **Aashu:** gana bhi baj reha

[12:49 PM] **You:** Nahi

[12:49 PM] **You:** Shanti hai bilkul

[12:49 PM] **Aashu:** okk

[12:49 PM] **Aashu:** bore ho rahi

[12:50 PM] **You:** Thoda thoda

[12:50 PM] **Aashu:** accha

[12:55 PM] **You:** Sone aa gaye

[12:55 PM] **You:** Room me

[12:55 PM] **Aashu:** kon hum

[12:55 PM] **You:** Haa

[12:55 PM] **Aashu:** aaj kaha sona hai

[12:55 PM] **Aashu:** itna jada kaam hai aaj

[12:56 PM] **You:** Baap re

[12:56 PM] **You:** Abhi kya kaam kar rahe ho

[12:56 PM] **You:** Batana

[12:56 PM] **Aashu:** chota chota bahut kaam hai

[12:56 PM] **You:** Mere samne to nahi hota tha koi kaam

[12:56 PM] **Aashu:** aaj se hai na

[12:57 PM] **Aashu:** 13th tak

[12:57 PM] **You:** Aaj hi aayi hu na mai

[12:57 PM] **You:** Kya kar rahe ho wiase

[12:57 PM] **Aashu:**
> _You: Kya kar rahe ho wiase_
padh rahe

[12:57 PM] **You:**
> _Aashu: padh rahe_
Ab ye kaam ho Raha

[12:58 PM] **Aashu:** yss

[12:58 PM] **You:** Fir ghar me to nhi h koi kaam

[12:58 PM] **Aashu:** thore der me hai

[12:58 PM] **You:** Sona aaj se Aaram se

[12:58 PM] **Aashu:** hmm

[12:58 PM] **You:** Koi disturb nahi hoga ab sone me

[12:59 PM] **Aashu:** hmm

[12:59 PM] **Aashu:** yss

[1:00 PM] **You:** 😏

[1:00 PM] **Aashu:** good night

[1:01 PM] **You:** Good night 😴😴

[1:19 PM] **Aashu:** good morning

[1:21 PM] **You:** Abhi nahi

[1:21 PM] **You:** Abhi to raat hi h

[1:22 PM] **Aashu:** 😆😆

[1:22 PM] **Aashu:** soyi nahi rm

[1:22 PM] **Aashu:** tm

[1:22 PM] **You:** So rhe the disturb kar diye

[1:23 PM] **You:** Ab to nind bhi nhi ayegi

[1:23 PM] **Aashu:** so jao ab disturb nahi karenge

[1:23 PM] **You:** 🫣🫣

[1:23 PM] **You:** Gadi me mai nahi soti hu

[1:24 PM] **Aashu:**
> _You: Gadi me mai nahi soti hu_
good girl

[1:26 PM] **You:** Yess I'm 🙈🙈

[1:26 PM] **Aashu:** pauch gayi nani gha

[1:26 PM] **Aashu:** ghar

[1:27 PM] **You:** Abhi to bahut door h

[1:28 PM] **Aashu:** accha

[1:28 PM] **Aashu:** aa jayega

[1:30 PM] **You:** Hmm

[2:49 PM] **Aashu:** kaha pauchi

[2:50 PM] **You:** Pagich gaye hain

[2:50 PM] **Aashu:** nikal gayi

[2:50 PM] **Aashu:** woha se

[2:51 PM] **You:** Abhi n nasta ho raha hai

[2:52 PM] **Aashu:** wahh

[2:52 PM] **Aashu:** mazza aa reha

[2:52 PM] **Aashu:** woha se nikal jana ab thore der me

[3:09 PM] **You:** Haa haa

[3:11 PM] **Aashu:** nikalna to msg karna

[3:11 PM] **Aashu:** [Image] yeha to hum kaam kar rahe pura

[3:34 PM] **You:** Ohh

[3:34 PM] **You:** Nikal gaye hum

[3:34 PM] **You:** Mama ji sath me ja rahe hain

[3:43 PM] **Aashu:** ok

[3:43 PM] **Aashu:**
> _You: Mama ji sath me ja rahe hain_
mama ji gaye chittu bhaiya nhi

[3:44 PM] **You:** Chittu bhaiya ko mami ko recieve krne Jana tha

[3:49 PM] **Aashu:** oh ok

[4:07 PM] **Aashu:** kaha ho bro

[4:07 PM] **Aashu:** pauchi

[5:19 PM] **You:** Hnn

[5:23 PM] **Aashu:** tab kya ho reha

[5:32 PM] **You:** [Image]

[5:33 PM] **Aashu:** gajab

[5:33 PM] **Aashu:** ab sabse ek ek ghanta baat hoga mya

[5:33 PM] **Aashu:** kya

[5:37 PM] **You:** Ab kya phle bhi hota tha

[5:40 PM] **Aashu:** karo karo

[5:42 PM] **You:** Waha icecream chal raha hai

[5:42 PM] **You:** Mere aane ke baad

[5:43 PM] **Aashu:** anurag bhaiya lekar aaye the

[5:44 PM] **You:** Sahi h

[5:44 PM] **You:** Mummy ko bata diye na mai pahuch gayi hu airport

[5:45 PM] **Aashu:** hmm

[5:45 PM] **Aashu:** sab ko bata diye

[5:45 PM] **Aashu:** sab baar baar yahi puch reha tha

[5:45 PM] **Aashu:** pauchi

[5:50 PM] **You:** Accha

[5:52 PM] **Aashu:** hh

[5:52 PM] **Aashu:** aur kya hua

[5:52 PM] **Aashu:** bani ghar me

[6:05 PM] **Aashu:** net off kaise

[6:05 PM] **Aashu:** abhi hi flight mode me daal di

[6:09 PM] **You:** Aise hi milna julna

[6:09 PM] **You:** Nasta wagera

[6:09 PM] **You:** Dono bhabhi yahi thi

[6:09 PM] **You:** Chittu bhaiya tha mama ji

[6:10 PM] **You:** Baatchit

[6:11 PM] **Aashu:**
> _You: Aise hi milna julna_
accha

[6:13 PM] **Aashu:** kitna der baithi

[6:17 PM] **You:** Nahi charge me lagai thi fir charge nahi karne ka jagah milta isliye

[6:17 PM] **You:**
> _Aashu: kitna der baithi_
1 ghante almost

[6:17 PM] **Aashu:**
> _You: Nahi charge me lagai thi fir charge nahi karne ka jagah milta isliye_
bhula jayega

[6:17 PM] **Aashu:** saman accha se

[6:18 PM] **You:** Haa haa careful hoke hi lagai thi

[6:19 PM] **You:** Delay ho gaya hai 6 45 time h ab

[6:21 PM] **Aashu:**
> _You: Delay ho gaya hai 6 45 time h ab_
accha

[6:21 PM] **Aashu:** koi nahi

[6:21 PM] **Aashu:** sonu bhaiya bhi aa rahe

[6:24 PM] **You:** Abhi tak to nahi bole hain

[6:34 PM] **You:** Aaj mujhe window sheet allot hua h

[6:34 PM] **You:** 😅😅

[6:44 PM] **Aashu:**
> _You: Aaj mujhe window sheet allot hua h_
gajab

[6:44 PM] **Aashu:** pura snap reel banao

[6:44 PM] **Aashu:** happy journey

[6:44 PM] **Aashu:** utarte hi msg karna ok

[6:45 PM] **You:** Reel n banate hum

[6:45 PM] **You:**
> _Aashu: happy journey_
Okk

[8:15 PM] **Aashu:** pauchi bro

[8:19 PM] **You:** Haa just land kar rahe

[8:19 PM] **Aashu:** wahh

[8:19 PM] **Aashu:** gajab

[8:19 PM] **Aashu:** kaise jaa rahi ghar

[8:19 PM] **Aashu:** koi aaya bai

[8:19 PM] **Aashu:** hai

[8:20 PM] **You:** Nahi khud se hi chali jaungi abhi flight me hi hu

[8:27 PM] **Aashu:**
> _You: Nahi khud se hi chali jaungi abhi flight me hi hu_
okk

[8:27 PM] **Aashu:** bolo kya hua

[8:27 PM] **Aashu:** call ki

[8:29 PM] **You:** Nhi glti se lag gaya

[8:30 PM] **Aashu:** okk

[8:33 PM] **Aashu:** saman lekar msg karna

[8:43 PM] **You:** Ok

[9:00 PM] **Aashu:** pauchi

[9:00 PM] **You:** HAA

[9:00 PM] **You:** Metro ja rahe ab

[9:45 PM] **Aashu:** pauchi

[9:45 PM] **You:** Dwarka me hu

[9:45 PM] **You:** Abhi lagega time

[9:45 PM] **You:** 11 baje Tak pahuchungi

[9:46 PM] **Aashu:** itna late

[9:46 PM] **Aashu:** tannu aa rahi receive karne

[9:46 PM] **Aashu:** jayegi kaise

[9:46 PM] **You:** Dekhte hain

[9:47 PM] **You:** [Document] Screenshot_2026_0516_214639.jpg

[9:47 PM] **Aashu:** kya dekhte hai

[9:47 PM] **Aashu:** akele cab me kyu jayegi

[9:47 PM] **Aashu:** bula leti atleast usko

[9:47 PM] **You:** Metro se ja rhi hu

[9:47 PM] **You:** Cab se nahi

[9:48 PM] **You:** Raat me mai cab se nhi jati

[9:48 PM] **Aashu:** to metro se utar kar to jayegi na

[9:48 PM] **You:** Waha se pass hi h

[9:48 PM] **Aashu:**
> _You: Raat me mai cab se nhi jati_
accha

[9:48 PM] **Aashu:** woha aayegi tannu

[9:48 PM] **You:** 5 minutes ka rasta h

[9:48 PM] **You:** Haa bula lenge

[9:49 PM] **Aashu:** okk

[9:49 PM] **Aashu:** phir thik ha

[9:49 PM] **You:** Hmmm

[9:49 PM] **Aashu:** flight me mazza aaya

[9:49 PM] **You:** Sir drd hone laga h mera ab

[9:49 PM] **You:** Or pair me bhi

[9:49 PM] **Aashu:** hmm travel travel ho gaya

[9:49 PM] **Aashu:** accha hai aaj rest ho jayega

[9:50 PM] **Aashu:** isiliye 16 ko beje

[9:50 PM] **Aashu:** kal jati to parso kya exam deti

[9:50 PM] **You:** Hmm sahi hi hai

[9:50 PM] **Aashu:** are hum bahut soch Kar karte na koi bhi kaam

[9:51 PM] **You:** Hmmm samajhdar ho rahe ho na mere sath rah ke

[9:51 PM] **You:** 🫣

[9:51 PM] **Aashu:**
> _You: Hmmm samajhdar ho rahe ho na mere sath rah ke_
tm to bewkoof wala baat kar rahi thi

[9:51 PM] **Aashu:** ki 17ko jayenge

[9:52 PM] **You:** 17 ko aate to morning tak nikalte

[10:05 PM] **Aashu:**
> _You: 17 ko aate to morning tak nikalte_
hmm

[10:05 PM] **Aashu:** kaha pauchi

[10:06 PM] **You:** Nawada

[10:07 PM] **Aashu:** ye to bihar me hai

[10:07 PM] **You:** Accha fir uttam nagar

[10:07 PM] **Aashu:** badmashi kar rahi

[10:08 PM] **You:** Are nawada metro station h

[10:08 PM] **Aashu:** oh aisa

[10:08 PM] **You:** Yess

[10:08 PM] **Aashu:** okkk

[10:08 PM] **You:** Bana liye khana

[10:08 PM] **Aashu:** hh kha bhi liye

[10:10 PM] **You:** Kaisa bana tha

[10:10 PM] **Aashu:** okok

[10:10 PM] **Aashu:** kuch khas nhi

[10:10 PM] **You:** Accha kya kya tha

[10:11 PM] **Aashu:** aloo parwal

[10:11 PM] **Aashu:** bhindi bujiya

[10:12 PM] **You:** Ohh

[10:22 PM] **Aashu:** aur kya ho reha

[10:24 PM] **You:** Metro me bor ho Rahi hu

[10:24 PM] **Aashu:** gana suno

[10:24 PM] **You:** Tannu se baat Hui hai aa jayegi wo

[10:24 PM] **Aashu:** [Video]

[10:24 PM] **Aashu:** yeha gab sap hasi majak ho reha

[10:24 PM] **Aashu:**
> _You: Tannu se baat Hui hai aa jayegi wo_
chalo sahi hai phir

[10:25 PM] **You:**
> _Aashu: Video_
Maze karo

[10:26 PM] **Aashu:** hmm

[10:26 PM] **Aashu:** miss kar reha tmko san

[10:26 PM] **Aashu:** sab

[10:31 PM] **You:** Anurag bhaiya baal nhi mundwa kyu

[10:31 PM] **You:**
> _Aashu: miss kar reha tmko san_
Ohh aisa kya bol rahe

[10:35 PM] **Aashu:**
> _You: Anurag bhaiya baal nhi mundwa kyu_
are wo log ka ek chutka hai

[10:35 PM] **Aashu:** parso karenge wo

[10:36 PM] **You:** Ohh

[10:37 PM] **Aashu:** pauchi nahi

[10:37 PM] **You:** 11 bajega mujhe

[10:37 PM] **Aashu:** baap re ok

[10:37 PM] **You:** Bhabhi bhi kal aayegi

[10:37 PM] **You:**
> _Aashu: baap re ok_
Door h

[10:38 PM] **You:** Or night me akele ki wajah se cab nhi kiye mujhe safe nahi lgta

[10:38 PM] **Aashu:**
> _You: Bhabhi bhi kal aayegi_
accha full masti

[10:38 PM] **Aashu:**
> _You: Or night me akele ki wajah se cab nhi kiye mujhe safe nahi lgta_
haa sahi hai metro hi thik hai

[10:39 PM] **You:**
> _Aashu: accha full masti_
Kya masti thak gyi hu mai

[10:39 PM] **Aashu:**
> _You: Kya masti thak gyi hu mai_
wo to thakegi hi

[10:39 PM] **You:** Hmm hmm

[10:39 PM] **You:** Mujhe headache hi pareshan kar deta

[10:40 PM] **Aashu:**
> _You: Mujhe headache hi pareshan kar deta_
kuch khayi nahi hogi na

[10:41 PM] **You:** Hmm bhukh bhi lagi hai

[10:41 PM] **Aashu:** hmm

[10:41 PM] **Aashu:** kya khayegi jaa kar

[10:41 PM] **Aashu:** kuch khayi nahi

[10:42 PM] **You:** Metro me change karne time sochi thi kuch kha lungi but metro lagi hui thi khane ke chakkar me or late ho jata

[10:42 PM] **You:** Isliye nahi liye kuch

[10:42 PM] **You:**
> _Aashu: kya khayegi jaa kar_
Banayi h chawal Dal bhindi ka bhujia

[10:42 PM] **Aashu:** metro me kha lo na

[10:42 PM] **Aashu:**
> _You: Banayi h chawal Dal bhindi ka bhujia_
accha

[10:43 PM] **You:**
> _Aashu: metro me kha lo na_
Station pe milta h andar nahi milta kuch

[10:43 PM] **You:** Or station pe time hi nahi tha

[10:43 PM] **Aashu:** bhai tumhare pass jo bag me tha

[10:43 PM] **Aashu:** wo sab kha lo ba

[10:43 PM] **Aashu:** na

[10:44 PM] **You:** Wo khaye lays 2 packet flight me hi

[10:44 PM] **You:** Ab man nhi kar rha

[10:44 PM] **Aashu:** okok

[10:45 PM] **You:** Accha mere baare me kya bol rahe sab

[10:46 PM] **Aashu:** chal gayi

[10:46 PM] **Aashu:** rahti tab mazza aata

[10:46 PM] **You:** Accha

[10:47 PM] **Aashu:** hmm

[10:47 PM] **Aashu:** nani ghar me mazza aaya

[10:47 PM] **Aashu:** aur jane me dikkat bhi hua

[10:47 PM] **Aashu:** lalu kuch bola bhi

[10:48 PM] **You:** Nhi maza hi aaya lalu thoda bolte hue ja raha tha to accha hi laga

[10:48 PM] **You:** Aaya lalu

[10:48 PM] **You:** Ghar

[10:48 PM] **Aashu:**
> _You: Aaya lalu_
haa aa gaya

[10:48 PM] **Aashu:**
> _You: Nhi maza hi aaya lalu thoda bolte hue ja raha tha to accha hi laga_
kyu mazza nahi aaya

[10:48 PM] **You:**
> _Aashu: kyu mazza nahi aaya_
Haa maza aaya wahi to bole

[10:48 PM] **You:** Lalu kuch bola bhi

[10:56 PM] **You:** [Image] Kha rhi hu

[10:56 PM] **Aashu:**
> _You: Lalu kuch bola bhi_
na baat nhi hua

[10:56 PM] **Aashu:**
> _You: Image: Kha rhi hu_
okk good

[10:57 PM] **You:**
> _Aashu: na baat nhi hua_
Kapda diya tha

[11:06 PM] **You:** Pahuch gye

[11:06 PM] **You:** Mummy ko bol Dena

[11:07 PM] **Aashu:**
> _You: Kapda diya tha_
hh

[11:07 PM] **Aashu:**
> _You: Mummy ko bol Dena_
ok

[11:07 PM] **Aashu:** rest karo

[11:09 PM] **You:** Hmm

[11:09 PM] **Aashu:** kha kar call karna

[11:11 PM] **You:** Thik h

[11:11 PM] **You:** Abhi sab baithe hi h ya chale gaye

[11:11 PM] **Aashu:**
> _You: Abhi sab baithe hi h ya chale gaye_
chale gaye

[11:11 PM] **Aashu:** kal kaam hai morning se hi na

[11:12 PM] **You:** Ohkk

[11:12 PM] **You:** To sone aa gye

[11:12 PM] **Aashu:** hh

[11:13 PM] **You:** Akele

[11:13 PM] **Aashu:** hj

[11:27 PM] **You:** Mujhe chicken mila h welcome me

[11:27 PM] **You:** 😅😅😅

[11:27 PM] **Aashu:** chicken nhi khana tha ma abhi

[11:28 PM] **Aashu:** mummy ko mat bolna chicken khaye

[11:28 PM] **You:** Mila h but khayenge nahi

[11:28 PM] **Aashu:**
> _You: Mila h but khayenge nahi_
mtpb

[11:28 PM] **Aashu:** mtlb

[11:28 PM] **You:** Mujhe bhi nahi lg Raha sahi khane me

[11:28 PM] **Aashu:** khane hi mila hoga na

[11:28 PM] **Aashu:** tannu hi banayi hogi na

[11:29 PM] **You:** Nahii

[11:29 PM] **Aashu:** oh

[11:29 PM] **You:** Ek collogue tha company ka usi ko leke aayi thi metro to wahi diya usko nhi pata tha ki mujhe nhi khana h

[11:30 PM] **Aashu:**
> _You: Ek collogue tha company ka usi ko leke aayi thi metro to wahi diya usko nhi pata tha ki mujhe nhi khana h_
okok

[11:32 PM] **You:** [Image] Pareshan😐

[11:32 PM] **Aashu:** garmi bahut hai na

[11:32 PM] **Aashu:** kha lo kuch pehle

[11:33 PM] **You:** Glucose pi rhi hu

[11:34 PM] **Aashu:** okk

[11:35 PM] **You:** Nind nhi aa rahi aaj

[11:35 PM] **Aashu:** aa reha

[11:35 PM] **Aashu:** bahut thak gaye hai

[11:36 PM] **Aashu:** kl morning 6 baje utna bhi hai

[11:36 PM] **You:**
> _Aashu: bahut thak gaye hai_
Ohh thak gaye kyu

[11:36 PM] **You:** Kya kiye ho aaj

[11:36 PM] **You:** Sona h

[11:36 PM] **Aashu:**
> _You: Sona h_
hmm

[11:36 PM] **Aashu:**
> _You: Kya kiye ho aaj_
saman laye hai bahut

[11:46 PM] **You:** 😡😡

[11:46 PM] **Aashu:** love u

[11:47 PM] **You:** Rhne do formality nhi Krna h

[11:48 PM] **You:** ☹️☹️☹️

---

## May 17, 2026

[1:01 AM] **You:** Good night

[7:49 AM] **Aashu:** uth gayi

[7:49 AM] **Aashu:** [Image]

[7:50 AM] **Aashu:** hum to 6 baje hi uth kar nikle hai

[8:09 AM] **You:** Good morning

[8:10 AM] **You:**
> _Aashu: hum to 6 baje hi uth kar nikle hai_
Karo achhi baat hai Krna chahiye

[8:17 AM] **Aashu:**
> _You: Karo achhi baat hai Krna chahiye_
yes

[8:17 AM] **Aashu:** uth gayi jldi

[8:18 AM] **You:** Haaa

[8:18 AM] **You:** Uth gayi

[8:19 AM] **You:** Abhi bahar hi ho

[8:19 AM] **Aashu:** abhi aaye

[8:19 AM] **You:** Ohh

[8:20 AM] **You:** Raat me kitna mushkil se nind aayi h itna body pain ho rha tha chatpat chhatpat kar ke soyi hu

[8:22 AM] **Aashu:**
> _You: Raat me kitna mushkil se nind aayi h itna body pain ho rha tha chatpat chhatpat kar ke soyi hu_
kyu bro

[8:22 AM] **Aashu:** pain kyu hua

[8:25 AM] **You:** Travel ki wajah se hi

[8:25 AM] **Aashu:** itna to karna hi tha na

[8:26 AM] **You:** Hmmmm

[8:26 AM] **You:** Ho jata h mujhe

[8:27 AM] **You:** Chay pi liye

[8:27 AM] **Aashu:** hmm

[8:27 AM] **Aashu:** rest karo

[8:27 AM] **Aashu:**
> _You: Chay pi liye_
nhai

[8:27 AM] **Aashu:** bahar chale gaye the na

[8:27 AM] **Aashu:** morning me hi

[8:27 AM] **Aashu:** abhi aakar icecream khaye hai

[8:27 AM] **Aashu:** garmi itna hai chai ka man nai kiye

[8:27 AM] **You:**
> _Aashu: abhi aakar icecream khaye hai_
Subah subah icecream

[8:27 AM] **Aashu:** aur ye aunty chai banati hai bahut kara

[8:27 AM] **Aashu:** wo accha nahi lagta humko

[8:27 AM] **Aashu:**
> _You: Subah subah icecream_
hh

[8:28 AM] **You:** Ohh

[8:28 AM] **You:** Mummy bana degi

[8:28 AM] **Aashu:** mummy boli

[8:28 AM] **Aashu:** but thik hai mana kar diye

[8:28 AM] **Aashu:** garmi bahut hai yaar

[8:29 AM] **You:** Haa garmi to hoga

[8:29 AM] **You:** Jyda dhup me possible ho to mat hi nikalna

[8:29 AM] **Aashu:** aaj kl to jana hi parega

[8:30 AM] **You:** Haa koi n hota h

[8:30 AM] **Aashu:** hmm

[8:30 AM] **Aashu:** tm padai karo thora ab

[8:30 AM] **You:** Lalu kapda diya tha na mummy ko

[8:30 AM] **Aashu:**
> _You: Lalu kapda diya tha na mummy ko_
haa bha

[8:30 AM] **You:**
> _Aashu: tm padai karo thora ab_
Haa aaj se to ab Krna h

[8:30 AM] **Aashu:** wo ghar lekar thori chal jaygaa

[8:30 AM] **Aashu:**
> _You: Haa aaj se to ab Krna h_
hh

[8:31 AM] **You:** Okk

[11:26 AM] **Aashu:** kya hua

[11:26 AM] **Aashu:** kuch hua

[12:13 PM] **You:** Kya hoga

[12:15 PM] **You:** [Image]

[12:46 PM] **Aashu:**
> _You: Image_
wahh

[12:46 PM] **Aashu:** full ready

[12:50 PM] **You:** Yess

[12:50 PM] **You:** But Bhabhi nhi aa rhi Aaj

[12:51 PM] **Aashu:** kyu

[12:52 PM] **Aashu:** yaar garmi bahut hai

[12:52 PM] **Aashu:** ghaat par

[12:53 PM] **You:** Accha wahi ho kya

[12:53 PM] **You:** Ho raha hai kaam

[12:54 PM] **You:** [Image] Yahan ka dekho

[12:56 PM] **Aashu:**
> _You: Image: Yahan ka dekho_
but tm room
me ho na

[12:56 PM] **Aashu:** hh

[12:56 PM] **Aashu:** [Video]

[12:58 PM] **You:** Haa haa

[12:59 PM] **You:** wahan dhup hoga abhi

[1:44 PM] **Aashu:** hh

[1:44 PM] **Aashu:** tabiyet ekdum kharab ho gaya mera

[1:44 PM] **Aashu:** baap re ye sab time me shadi hota tab to behos ho jate hum

[1:45 PM] **You:**
> _Aashu: tabiyet ekdum kharab ho gaya mera_
Hayee kya ho gaya

[1:45 PM] **You:**
> _Aashu: baap re ye sab time me shadi hota tab to behos ho jate hum_
Such me bahut pareshan ho jate

[1:46 PM] **Aashu:**
> _You: Hayee kya ho gaya_
are garmi bahut hai ghaat kar

[1:46 PM] **Aashu:** aur turant turant itna cheez lana mushkil ha

[1:47 PM] **You:**
> _Aashu: are garmi bahut hai ghaat kar_
Pani pite rahna

[1:47 PM] **Aashu:** hmm ok

[1:47 PM] **You:** Dehydration ho jayega nahi to

[1:48 PM] **Aashu:** hh pani to pii rahe

[1:48 PM] **You:** Khaye ho kuch

[1:48 PM] **Aashu:** hh kha liye abhi khana

[1:49 PM] **You:** Kya khaye

[1:50 PM] **Aashu:** [Voice message]

[1:50 PM] **You:** Wahan bhi yahi bana tha aaj

[1:50 PM] **Aashu:** hh

[1:51 PM] **You:** Okk

[1:51 PM] **You:** Abhi Ghar pe ho

[1:54 PM] **Aashu:** hh

[1:54 PM] **Aashu:** jain dharamsala

[1:54 PM] **Aashu:** aaye

[1:58 PM] **You:** Okk

[3:04 PM] **Aashu:**
> _You: Video_
gajab sassy mtlb kya hota

[3:19 PM] **You:** Naughty, jolly,good heart

[3:19 PM] **You:** 😅😅

[3:24 PM] **Aashu:**
> _You: Naughty, jolly,good heart_
gajab

[3:24 PM] **Aashu:** chatgpt se koj koj kar

[3:34 PM] **You:** Nhi

[3:34 PM] **Aashu:** accha

[3:35 PM] **You:** Ye chatgpt se n h

[3:36 PM] **Aashu:** haa ye easy wala hai uska cost

[3:38 PM] **You:** Kya easy wala

[3:38 PM] **Aashu:** are sorry

[3:38 PM] **Aashu:** wrong type ho gaya

[3:38 PM] **Aashu:** mera matlab tha easy wala hai ye

[3:40 PM] **You:** Accha

[3:40 PM] **Aashu:** soyi nahi

[3:41 PM] **Aashu:** tumhara time ho gaya sone ka

[3:41 PM] **You:** [Image] Sleeping mode hi h but nind n aa rahi

[3:41 PM] **Aashu:** tannu

[3:42 PM] **You:** Soyi h

[3:42 PM] **Aashu:** tm bhi so jao

[3:42 PM] **You:** Try kiye

[3:42 PM] **You:** Nind hi nhi aayi

[3:43 PM] **Aashu:** accha

[3:43 PM] **Aashu:** to padho na turant neend aane lagega

[3:44 PM] **You:** Haaa

[3:44 PM] **You:** Wo bhi kiye

[3:45 PM] **You:** Wahan kya ho rha

[5:18 PM] **Aashu:** bahut kaam ho reha bhai

[5:18 PM] **Aashu:** halat kharab ho jayega ekdum

[6:17 PM] **You:** Haa

[7:05 PM] **Aashu:** [Image] yahi baithe hai jaha tumhara shadi hua tha

[7:06 PM] **You:** Ohh sirf mera shadi hua tha

[7:06 PM] **Aashu:** to kya

[7:06 PM] **You:** Accha

[7:08 PM] **You:** Aap kya attend karne aaye the

[7:13 PM] **Aashu:** bhabhi kyu nhi aayi aaj

[7:18 PM] **You:** Babu log ka tabiyat kharab ho gaya tha

[9:53 PM] **You:** Kitne busy ho

[9:55 PM] **Aashu:** ek min bhi time kaha hai

[9:55 PM] **Aashu:** sab log ko khud se khana khilana

[9:56 PM] **Aashu:** itna garmi hai

[9:56 PM] **You:** Ohhh

[9:56 PM] **You:** Kha liye sab

[9:59 PM] **Aashu:** haa almost

[10:01 PM] **You:** Abhi kahan ho

[10:06 PM] **Aashu:** ab ghar jaa rahe

[10:07 PM] **You:** Okk khana kha liye

[10:18 PM] **Aashu:** hh

[10:27 PM] **Aashu:** [Image]

[10:27 PM] **Aashu:** bahut log baitha hai

[10:28 PM] **Aashu:** mami mummy mausi fhua

[10:47 PM] **You:** Okk

[10:50 PM] **You:** Mai sone ja Rahi hu ab

[10:50 PM] **You:** Good night

[10:50 PM] **Aashu:** ok good night

[10:53 PM] **Aashu:** khana kya khayi thi

[10:53 PM] **Aashu:** momos

[10:53 PM] **You:** Yahi

[10:54 PM] **Aashu:** accha

[10:54 PM] **Aashu:** kl kon se subject ka exam hai

[10:55 PM] **You:** Machine learning

[10:55 PM] **Aashu:** gajab

[10:55 PM] **Aashu:** kitna chapter hai

[10:55 PM] **You:** 8

[10:56 PM] **You:** Jyda Hi busy ho lgta h

[10:57 PM] **Aashu:** gussa ho rahi

[10:57 PM] **Aashu:**
> _You: 8_
sara ka naam batana

[10:57 PM] **You:**
> _Aashu: sara ka naam batana_
Nhi pata h yahi check karna h na

[10:57 PM] **You:** Jao phle bata diye

[10:58 PM] **Aashu:** good

[10:58 PM] **You:** Hmm

[10:59 PM] **Aashu:** okk koi nhi thik hai

[10:59 PM] **Aashu:** hota hai

[11:05 PM] **Aashu:** kya bro

[11:06 PM] **You:** Kuch ni

[11:06 PM] **Aashu:** gussa ho

[11:07 PM] **You:** Chhodo

[11:08 PM] **Aashu:** kya hua

[11:08 PM] **Aashu:** bolo

[11:08 PM] **You:** Kuch ni rest Karo

[11:08 PM] **You:** Bye

[11:08 PM] **Aashu:** ok as u wish

[11:08 PM] **Aashu:** bye

---

## May 18, 2026

[6:47 AM] **Aashu:** good morning

[7:05 AM] **You:** Good morning

[7:05 AM] **Aashu:** gayi nahi exam dene

[7:05 AM] **You:** 8 baje jaungi

[7:06 AM] **Aashu:** okkk

[7:06 AM] **Aashu:** khayi kuch

[7:06 AM] **You:** Dahi chuda khaungi

[7:06 AM] **Aashu:** okkk

[8:19 AM] **You:** Ja rhi hu

[8:19 AM] **Aashu:** okk

[8:19 AM] **Aashu:** best of luck

[8:19 AM] **Aashu:** kuch nahi aaye phir bhi likh dena

[8:19 AM] **Aashu:** aise chor kar mat aana

[8:20 AM] **You:** Haa haa

[9:04 AM] **You:** [Image]

[11:21 AM] **Aashu:** hello

[12:34 PM] **Aashu:** kaha ho

[12:43 PM] **You:** Exam me the

[12:43 PM] **You:** Abhi nikle hain

[1:20 PM] **Aashu:** kaisa gaya ecam

[1:26 PM] **You:** Sahi raha

[1:27 PM] **Aashu:** okk

[1:27 PM] **Aashu:** good

[1:34 PM] **You:** Bahut garmi lag raha hai

[1:34 PM] **You:** ☹️☹️

[1:34 PM] **Aashu:** ab kon accha hai banglore ya delhi

[1:35 PM] **Aashu:** [Video]

[1:51 PM] **You:**
> _Aashu: ab kon accha hai banglore ya delhi_
Garmi me delhi accha nahi lagta

[1:52 PM] **You:**
> _Aashu: Video_
Ye kon ga rhe hain

[1:52 PM] **Aashu:**
> _You: Ye kon ga rhe hain_
rishu ke chote nana

[1:52 PM] **Aashu:** nandan ke papa

[1:53 PM] **You:** Accha

[1:54 PM] **You:** Sab wahi gaye hue hain kya

[1:54 PM] **Aashu:** nhi

[1:54 PM] **Aashu:** wo bus ek gana

[1:55 PM] **You:** Oh

[2:06 PM] **You:** Nandan bhi aayi h kya

[2:06 PM] **Aashu:** hh

[2:07 PM] **You:** Badhiya hai

[2:13 PM] **Aashu:** hh

[2:13 PM] **Aashu:** aa gayi ghar

[2:13 PM] **You:** Hmm

[2:14 PM] **Aashu:** khayi kuch

[2:14 PM] **You:** Haa

[2:14 PM] **You:** Rajma chawal or kadhi chawal pack kara liye the

[2:14 PM] **Aashu:**
> _You: Rajma chawal or kadhi chawal pack kara liye the_
wahh gajb

[2:15 PM] **Aashu:** tumhara hi masti hI

[2:15 PM] **Aashu:** hai

[2:15 PM] **You:** Masti wala khana h ye

[2:15 PM] **You:** Bhukh lag gaya tha khana kon banata abhi garmi bhi lag raha tha

[5:52 PM] **You:** Hello

[6:01 PM] **Aashu:** bolo

[6:12 PM] **You:** Kya ho raha

[6:43 PM] **Aashu:** sab start hoga ab

[6:44 PM] **You:** Hum bhi ja rhe aaj bahar khane kuch

[6:50 PM] **Aashu:**
> _You: Hum bhi ja rhe aaj bahar khane kuch_
ok kha lo

[11:22 PM] **You:** Hello

[11:22 PM] **You:** Ho gaya sab

[11:22 PM] **You:** Wahan

[11:40 PM] **Aashu:** bolo

[11:40 PM] **Aashu:** hh ho gaya

[11:45 PM] **You:** Kahan pe ho abhi

[11:51 PM] **Aashu:** apne room me

[11:51 PM] **Aashu:** is room me aaj 10 log so rahe

[11:52 PM] **You:** Haa abhi Chhoti mami call ki thi

[11:52 PM] **Aashu:** hh mere samne se hi ki thi

[11:53 PM] **You:** Accha

[11:53 PM] **You:** Bed pe ho ya niche

[11:53 PM] **Aashu:** hum upar bed pae

[11:53 PM] **Aashu:** ek aadmi to sofa par hai

[11:54 PM] **You:** Ohho

[11:54 PM] **You:** Bed pe kon kon h

[11:54 PM] **Aashu:** hum mummy guriya

[11:55 PM] **You:** Ok

[11:55 PM] **Aashu:** aaj kya kya khayi

[11:56 PM] **You:** [Image]

[11:56 PM] **You:** Khana normal

[11:57 PM] **Aashu:**
> _You: Khana normal_
wahh mast

[11:57 PM] **Aashu:** kaisa tha

[11:57 PM] **You:** Thik tha

[11:57 PM] **Aashu:** tm chaar log hi to thi

[11:59 PM] **You:** Haa

[11:59 PM] **You:** Priya or shweta nhi aayi thi

---

## May 19, 2026

[12:00 AM] **Aashu:**
> _You: Priya or shweta nhi aayi thi_
ohh

[12:00 AM] **Aashu:** kyu

[12:00 AM] **Aashu:** thak gaye bahut aaj

[12:00 AM] **Aashu:** upae se mera laptop lock ho gaya

[12:00 AM] **Aashu:** wo alag tension hai

[12:01 AM] **You:**
> _Aashu: upae se mera laptop lock ho gaya_
Lock kaise accha location ki wajah se

[12:01 AM] **Aashu:** chalo hum sone jaa rahe

[12:01 AM] **Aashu:** kl morning jagna hai

[12:01 AM] **Aashu:** 6 baje

[12:01 AM] **Aashu:** tabiyet bhi thik nhi hai

[12:01 AM] **You:** Hmmm

[12:01 AM] **You:** Kal kitne baje milna h

[12:01 AM] **Aashu:** 😴 good night

[12:01 AM] **You:** Nikalna

[12:01 AM] **Aashu:**
> _You: Kal kitne baje milna h_
5

[12:02 AM] **You:** Sham me na

[12:02 AM] **Aashu:** hh

[12:02 AM] **You:**
> _Aashu: 😴 good night_
Okk so jao

[12:02 AM] **Aashu:** bbyy

[12:02 AM] **You:** Good night

[12:02 AM] **You:** Bye

[7:21 AM] **You:** Good morning

[7:46 AM] **Aashu:** good morning

[8:07 AM] **Aashu:** phir so gayi kya

[8:07 AM] **Aashu:** exam ha na tumhara aaj bhi

[8:21 AM] **You:** Haa hai

[8:21 AM] **You:** Ready ho rahe the

[8:21 AM] **Aashu:** chalo

[8:21 AM] **Aashu:** best of luck

[8:22 AM] **Aashu:** acche se likho

[8:27 AM] **You:** 9 30 se start hoga abhi n

[8:36 AM] **Aashu:** ohh okk

[8:36 AM] **Aashu:** kuch khayi

[8:41 AM] **You:** Haa poha bana liye the

[8:41 AM] **Aashu:** okk

[8:41 AM] **Aashu:** kl se sahi se baat hoga tmse

[8:41 AM] **Aashu:** jab banglore pauchenge tab

[8:42 AM] **You:** Achha koi n

[8:42 AM] **You:** Sham me nikloge na

[8:42 AM] **Aashu:** hh

[8:42 AM] **You:** Kaise jane ka plan hua h

[8:43 AM] **Aashu:** car

[12:42 PM] **You:** Ohhk

[12:42 PM] **Aashu:** kaisa gaya exam

[12:42 PM] **Aashu:** aur us din tmko airport jane me kitna time laga tha

[12:43 PM] **You:**
> _Aashu: kaisa gaya exam_
Okok

[12:43 PM] **Aashu:**
> _You: Okok_
ohh

[12:43 PM] **You:**
> _Aashu: aur us din tmko airport jane me kitna time laga tha_
Mai to bich me ruki bhi thi n

[12:43 PM] **Aashu:**
> _You: Mai to bich me ruki bhi thi n_
phir bhi total kitna time laga tha

[12:43 PM] **You:** 3 sade din ghante max lagega

[12:43 PM] **Aashu:** okk thik hai

[12:44 PM] **You:** But sham ke time jaoge to time leke hi nikalna kyuki

[12:44 PM] **You:** Traffic mil skta h

[12:44 PM] **Aashu:** hh ok

[12:44 PM] **You:** But airpot line ke traffic nahi hi milega

[12:45 PM] **Aashu:**
> _You: But airpot line ke traffic nahi hi milega_
accha woha khai rehta

[12:45 PM] **Aashu:** banglore jaisa traffic nahi rehta na

[12:52 PM] **You:**
> _Aashu: banglore jaisa traffic nahi rehta na_
Naa naa

[12:52 PM] **You:** Marine drive se jayega

[12:52 PM] **You:** To pura khali hoga

[2:06 PM] **Aashu:** okk

[3:06 PM] **You:** [Image] Wapas wahi khana

[5:24 PM] **You:** Nikal gaye

[5:24 PM] **Aashu:** hh

[5:24 PM] **You:** Batana bhi hota h

[5:39 PM] **Aashu:** are you

[5:40 PM] **Aashu:** gari me 8 log hai

[5:40 PM] **Aashu:** ph chalane me nhi ban reha tha

[5:52 PM] **You:** Kon kon h

[5:52 PM] **Aashu:** mausi pittu mama

[5:53 PM] **Aashu:** ek fhua ke relation ke hai

[6:31 PM] **You:** Ohh

[6:31 PM] **You:** Itne sare log

[6:31 PM] **You:** Flight kitne baje ki h

[6:45 PM] **Aashu:** [Document] https://www.ixigo.com/image/upload/eTicket_IF26050943145811_83fd6f89-ba3e-429a-b710-14d11b4a82e4.pdf

[7:12 PM] **You:** 2 baje pahuchoge

[7:12 PM] **You:** Ghar jane me to subah ho jayega

[8:53 PM] **Aashu:** hello

[8:53 PM] **Aashu:** pauch gaye airport

[8:53 PM] **Aashu:**
> _You: Ghar jane me to subah ho jayega_
hmm almost

[8:55 PM] **You:**
> _Aashu: pauch gaye airport_
Okk

[8:55 PM] **You:** Ho gaya checking

[9:04 PM] **Aashu:** hh

[9:04 PM] **Aashu:** yeha to net hi nahi chalta bha

[9:04 PM] **Aashu:** bhai

[9:04 PM] **Aashu:** itna bara airport bana diya hai tower lagaya hi nahi hai

[9:16 PM] **You:**
> _Aashu: yeha to net hi nahi chalta bha_
Haa dikkat to mai bhi feel ki thi ye

[9:16 PM] **You:** Bolo jake ab Samrat chaudhari ko

[9:19 PM] **Aashu:**
> _You: Bolo jake ab Samrat chaudhari ko_
hmm tweet karte

[10:06 PM] **Aashu:** tumhara do minute nhi hua

[10:09 PM] **You:** Accha haa

[10:09 PM] **You:** Mummy se baat karne lagi thi

[10:12 PM] **Aashu:** ok

[10:12 PM] **You:** Kya hua ab

[10:12 PM] **Aashu:** kuch nhi choro

[10:13 PM] **You:** Call kyu nahi utha rahe ho

[10:13 PM] **Aashu:** bolo

[10:13 PM] **Aashu:** kya hua

[10:48 PM] **You:** Kuchh nhi

[10:48 PM] **You:** Nhi Krna mujhe call ab

[10:57 PM] **Aashu:** ok

[11:02 PM] **You:** Ghar ka key liye ho

[11:11 PM] **Aashu:**
> _You: Ghar ka key liye ho_
yes

[11:12 PM] **Aashu:** ghar jaakar akele rahne me dar lagega

[11:13 PM] **Aashu:** flight me baith gaye hum ok

[11:16 PM] **You:**
> _Aashu: ghar jaakar akele rahne me dar lagega_
Koi n kyu darna

[11:16 PM] **You:** Suno jab land karoge to mujhe call kar dena ek baar

[11:16 PM] **You:** Agar mai so bhi gayi toh

[11:16 PM] **Aashu:**
> _You: Suno jab land karoge to mujhe call kar dena ek baar_
msg kar denge

[11:17 PM] **Aashu:** tm so jayegi tab tak

[11:18 PM] **You:** Koi n msg thodi dekh paungi

[11:18 PM] **You:** Call hi kar lena na

[11:18 PM] **Aashu:** accha kar denge

[11:18 PM] **Aashu:** ok

[11:40 PM] **You:** Hmm

---

## May 20, 2026

[1:40 AM] **Aashu:** hello

[7:41 AM] **You:** Good morning

[7:42 AM] **You:** Aa gye ghar

[10:26 AM] **Aashu:** gm

[10:26 AM] **Aashu:** hh

[11:47 AM] **Aashu:** aaj bhi exam hai

[12:48 PM] **You:** Haa

[12:48 PM] **You:** HO gaya

[2:11 PM] **Aashu:** ok

[3:45 PM] **Aashu:** [Video] mera poch ban reha

[3:46 PM] **You:** Khud se bana rhe ho

[3:46 PM] **Aashu:** [Image] hlka jl gaya

[3:46 PM] **Aashu:** hh

[3:47 PM] **You:** Itna chalta h

[3:47 PM] **You:** Jyda nhi jala h

[3:47 PM] **You:** Ban gaya acche se

[3:48 PM] **Aashu:** hh

[3:49 PM] **You:** Good 👍

[3:49 PM] **You:** Sikh lo

[3:50 PM] **Aashu:** hmm

[7:59 PM] **You:** Hello

[8:03 PM] **Aashu:** bolo

[8:04 PM] **You:** Kya kar rahe ho

[8:07 PM] **Aashu:** [Image] call pe hi hai

[8:17 PM] **You:** Okk

[8:25 PM] **Aashu:** cutipie

[8:42 PM] **You:** 😊

[8:43 PM] **You:** [Image] Mera dinner 😅😅

[8:46 PM] **Aashu:** hum bhi kuch aisa hi karenge

[8:50 PM] **You:** _You deleted this message_

[8:51 PM] **You:**
> _Aashu: hum bhi kuch aisa hi karenge_
Nhi kuch bana lo

[8:51 PM] **You:** Din me bhi to aise hi khaye ho

[8:55 PM] **Aashu:** dekhte hai yaar

[10:11 PM] **Aashu:** karte hai

[10:11 PM] **Aashu:** abhishek ke ghar hai

[10:18 PM] **You:** Ok

---

## May 21, 2026

[12:07 AM] **Aashu:** hello

[12:07 AM] **Aashu:** chalo so jao phir good night

[12:07 AM] **Aashu:** mera ph bhi 2 percent ho gaya hai

[12:07 AM] **You:** Okk

[6:02 AM] **Aashu:** party on

[7:16 AM] **You:** Yess

[7:16 AM] **You:** Good morning

[7:16 AM] **You:**
> _Aashu: party on_
Mujhe milegi na

[7:17 AM] **Aashu:** hh

[7:17 AM] **Aashu:** good morning

[7:17 AM] **You:** 🙂🙂

[7:17 AM] **You:** Uth gaye ho

[7:18 AM] **Aashu:** nhi

[7:18 AM] **You:** Ok

[7:19 AM] **You:** So jao abhi

[7:19 AM] **Aashu:** hm

[1:52 PM] **You:** [Image] Mil gya

[3:38 PM] **You:** _You deleted this message_

[3:38 PM] **You:** [album message]

[3:38 PM] **You:** [Image]

[3:38 PM] **You:** [Image]

[3:38 PM] **Aashu:** wahh gajan

[3:38 PM] **Aashu:** mast

[3:38 PM] **You:** Accha laga

[3:39 PM] **Aashu:** hh dekh kar to accha lag reha

[3:39 PM] **You:** Length short karaye ya itna hi rhne de

[3:39 PM] **Aashu:** itna hi rahne di

[3:39 PM] **Aashu:** do

[3:40 PM] **You:** Okk

[5:14 PM] **Aashu:** hello ghar aa gayi

[5:36 PM] **You:** Haa aa gayi

[5:41 PM] **Aashu:** wahh

[5:41 PM] **Aashu:** rest kar rahi

[5:42 PM] **You:** Nhi yaar

[5:43 PM] **Aashu:** kya kar rahi phir

[5:43 PM] **You:** Ladai

[5:43 PM] **You:** Kar rhi hu

[5:43 PM] **Aashu:** kise

[5:44 PM] **You:** Frame wali se

[5:44 PM] **Aashu:** kyu kya hua

[5:45 PM] **You:** Acche se nhi banai hai yarr

[5:45 PM] **You:** Jaisa expect kiye the

[5:45 PM] **Aashu:** ohh

[5:45 PM] **Aashu:** bejo to photo

[5:46 PM] **You:** [Image]

[8:28 PM] **Aashu:** hello

[8:51 PM] **You:** Hmm aa gaye

[8:51 PM] **Aashu:** free hokar call karna

[9:56 PM] **Aashu:** [Image]

[10:56 PM] **You:** So gye ho

[10:57 PM] **Aashu:** hh

[10:59 PM] **You:** Nind aa rhi h

---

## May 22, 2026

[7:43 AM] **You:** Good morning

[7:43 AM] **You:** Uthe nhi ho kya

[7:52 AM] **Aashu:** good morning

[8:53 AM] **You:** ja rhi hu mai

[8:53 AM] **Aashu:** okk

[8:53 AM] **Aashu:** best of luck

[8:57 AM] **You:** Hmm thankyou

[11:24 AM] **Aashu:** [Image]

[11:24 AM] **Aashu:** yaar ungli me fora ho gaya

[11:24 AM] **Aashu:** kaise thik hoga

[12:34 PM] **You:**
> _Aashu: Image_
Ohho ye kya

[12:35 PM] **You:** Drawer me alovera gel hoga

[12:35 PM] **You:** Wo laga lo

[2:56 PM] **Aashu:** ye rahul bahut famous aadmi hai kya

[2:56 PM] **Aashu:** almost bank of America ka sab log usi ko report karta lagta hai

[3:37 PM] **You:** Kiska message mujhe kar rhe ho

[3:40 PM] **Aashu:** ohh

[3:40 PM] **Aashu:** sorry

[3:40 PM] **Aashu:** swapna ko bol rahe the

[3:41 PM] **You:** Ok

[4:02 PM] **Aashu:** yes

[4:02 PM] **Aashu:** man

[4:37 PM] **You:** Aa gaye office de

[4:37 PM] **You:** Se

[4:48 PM] **Aashu:** hh

[4:48 PM] **Aashu:** chai bana rahe

[5:41 PM] **You:** Kahan ho

[5:43 PM] **Aashu:** wait bro

[5:43 PM] **Aashu:** i will call u

[5:59 PM] **You:** Ok I'm waiting

[5:59 PM] **Aashu:** net off kyu hai

[6:08 PM] **You:** Charge nhi hai

[6:08 PM] **You:** phone

[7:22 PM] **You:** [Image] 😔

[7:22 PM] **Aashu:**
> _You: Image: 😔_
kya ho gaya

[7:25 PM] **You:** Muh ka chhala bada ho gaya h

[7:25 PM] **Aashu:** ohh kha lo

[7:26 PM] **Aashu:** pet ke garmi se hota

[7:26 PM] **Aashu:** thanda cheez khao

[7:50 PM] **Aashu:** hello

[7:59 PM] **You:** Hmm hello

[8:23 PM] **You:** [Forwarded] [Video]

[8:55 PM] **Aashu:** hum abhishek ke ghar par hai

[9:13 PM] **You:** Kab aaoge

[9:13 PM] **Aashu:** thore der me

[9:16 PM] **You:** [Image]

[9:16 PM] **You:** [Video]

[9:16 PM] **You:** [Image]

[9:16 PM] **You:** [Image]

[9:17 PM] **Aashu:**
> _You: Image_
accha to lag reha

[10:02 PM] **You:** Hmm

[10:02 PM] **You:** Aaye nhi ho room

[10:03 PM] **Aashu:** abhi just aaye

[10:44 PM] **Aashu:** kaha ho

[10:45 PM] **Aashu:** khana nai banaye aaj hum

[10:57 PM] **Aashu:** chalo ab tmko nhi reply karna to good night

---

## May 23, 2026

[6:36 AM] **You:** Meri tabiyat kharab ho gyi thi kal

[6:36 AM] **You:** Mai so gyi thi

[6:37 AM] **You:** Phone nhi dekhne ka man kar raha tha

[8:32 AM] **Aashu:**
> _You: Phone nhi dekhne ka man kar raha tha_
kya ho gaya

[8:32 AM] **Aashu:** good morning

[8:37 AM] **You:** Good morning

[8:39 AM] **You:** [Forwarded] [Image]

[10:27 AM] **You:** Hello

[10:27 AM] **Aashu:** hh

[11:34 AM] **Aashu:** ho gaya baat

[11:37 AM] **You:** [Image]

[11:38 AM] **Aashu:** ye kom hai

[11:38 AM] **Aashu:** ashish bhaiya hai kya

[11:39 AM] **You:** Haa

[11:51 AM] **You:** [Forwarded] [Document] B9E537A274DB20080F1B22600.pdf

[11:52 AM] **You:** [Forwarded] [Document] BookingInvoice_BI_395798527

[11:52 AM] **Aashu:** [Image]

[3:02 PM] **You:** Ola or uber me itna price difference kyu hota h

[3:03 PM] **Aashu:** kitna difference hai

[3:05 PM] **You:** [album message]

[3:05 PM] **You:** [Image]

[3:05 PM] **You:** [Image]

[3:05 PM] **You:** [Image]

[3:05 PM] **You:** Uber bhi abhi rapido jitna price bhi dikha Raha tha

[3:05 PM] **Aashu:** go with uber

[3:07 PM] **You:** Why not ola

[3:07 PM] **Aashu:** i prefer uber

[3:07 PM] **Aashu:** its better then ola

[3:08 PM] **You:** Okk

[3:10 PM] **Aashu:** [Image] ice cream kha lo

[3:11 PM] **You:** Ye kon sa mangaye ho

[3:11 PM] **Aashu:** naturals

[3:16 PM] **You:** Sahi h khao khub

[3:28 PM] **Aashu:** ji

[7:56 PM] **Aashu:** pauch gayi

[8:02 PM] **You:** [Image]

[8:03 PM] **Aashu:** cool

[8:03 PM] **You:** Hmm

[8:32 PM] **You:** [album message]

[8:32 PM] **You:** [Image]

[8:32 PM] **You:** [Image]

[8:44 PM] **Aashu:** pauchi

[9:06 PM] **You:** Hmm

[9:09 PM] **You:** Okk

[9:09 PM] **You:** Yahi bus h

[9:10 PM] **You:** [Forwarded] "Booking PNR 395798527-1251742 Bus Info - Bus No:MP09BH9621, Bus Suffix: , PickupMan No:, Driver No: 9429388746, Driver2 No: 6367428615." - MANTIS

[9:13 PM] **Aashu:** good

[9:28 PM] **You:** [Image] Mummy ko dekho😅😅

[9:29 PM] **Aashu:**
> _You: Image: Mummy ko dekho😅😅_
full happy sahi hai yaar

[9:29 PM] **Aashu:** tumhare mummy papa abhi bahut kush hoenhe

[9:29 PM] **Aashu:** hoenge

[9:30 PM] **You:** Haaaa

[9:30 PM] **You:** Pura

[9:31 PM] **You:** 😊😊

[9:33 PM] **Aashu:** sahi hai

[9:33 PM] **Aashu:** jada complain nahi karna mera

[10:40 PM] **You:** [Image]

[10:42 PM] **Aashu:** yaar gyan pelne sab aa jata jisko nhi dimag hai wo bhi chalo hum ispe jada nahi bolenge warna bura lag jayega tmko

[10:44 PM] **You:** Bolne do na

[10:44 PM] **You:** Krna hame h na

---

## May 24, 2026

[3:12 AM] **Aashu:** hello

[5:43 AM] **Aashu:** good morning

[5:43 AM] **Aashu:** bro

[5:44 AM] **You:** [Image] Good morning

[5:44 AM] **Aashu:**
> _You: Image: Good morning_
wahh good

[5:54 AM] **You:** Abhi roka tha

[5:54 AM] **You:** Ab fir 3 ghante baad rokega

[5:54 AM] **You:** Biryani fek diye

[5:54 AM] **You:** Mujhe ghin aa gaya thoda sa hi kha k

[11:11 AM] **Aashu:** hello

[11:17 AM] **You:** Ha

[11:18 AM] **Aashu:** kya ho reha

[11:18 AM] **You:** Abhi fir bus ruki hai ek jagah

[11:19 AM] **Aashu:** okk kha lo kuch

[11:25 AM] **Aashu:** [Image]

[11:26 AM] **You:** Nhi h jyda dhul jayega

[11:26 AM] **Aashu:** [Video] ye sabse samne wale building ka video hai

[11:26 AM] **Aashu:** [Video] ye uske just piche wale ka

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:26 AM] **Aashu:** [Image]

[11:43 AM] **You:** Accha hai

[3:19 PM] **You:** [Image]

[6:02 PM] **Aashu:** [Forwarded] Hi all , 
I have list of the Flats with  water blockage issues , 
will be working to get it fixed by each blocks , will assign one day per block so that ,  all blockage issues related to that particular block is solved.

please check here 

Block A:
A1201, A-1303, A907, A1301, A207, A-308, A-1008, A-1401, A407, A1408, A307, A908

Block B:
B-1202, B107, B-1208, B-401, B1207, B-203, B1106, B1307, B-1002, B-1206, B-1405, B-1008, B-1408, B1203, B1208, B207, B1307

Block C:
C-903, C106, C203, C1203, C1303, C1404, C-1207, C-807, C504

Block D:
D-1404, D1308, D305, D1006, D-1306, D-108, D-105, D306, D-1403, D1308, D-401, D404, D1304, D406, D-502, D-705, D023, D204, D-1007, D1403

Block E:
E208, E-507, E-1406, E507, E-107, E-407, E308, E101, E-1405, E-1301

Block F:
F-505, F-605, F701, F507, F101, F602, F-301, F-901

will update the dates for each blocks

[7:00 PM] **You:** [Image] Dekho mai itna miss kr rhi hu ki wallpaper hi laga liya 🙈🙈

[7:01 PM] **Aashu:**
> _You: Image: Dekho mai itna miss kr rhi hu ki wallpaper hi laga liya 🙈🙈_
wahh acche lag rahe hum

[7:01 PM] **Aashu:**
> _You: Image: Dekho mai itna miss kr rhi hu ki wallpaper hi laga liya 🙈🙈_
bejo to ye photo

[7:02 PM] **You:** Matlab bilkul hi unromantic ho naa

[7:02 PM] **You:** Meri feeling ki aisi taisi kar ke rakh diye ek minute me

[7:02 PM] **You:** 🤨🤨🤨

[7:02 PM] **Aashu:** are matlab tm to humesa cute lagti

[7:03 PM] **Aashu:** hum kabhi kabhi acche lagte

[7:03 PM] **Aashu:** isme acche lag rahe

[7:03 PM] **Aashu:** acchanak itna miss kaise karne lagi bhai

[7:03 PM] **You:** Photo dekhne lag gye f feeling se koi matlab nahi

[7:04 PM] **You:**
> _Aashu: acchanak itna miss kaise karne lagi bhai_
Ab chhodo

[7:04 PM] **Aashu:** are bhai miss to hum bhi kar hi rahe

[7:05 PM] **You:** Kahan kbhi bolte ho

[7:06 PM] **You:** Feeling express Krna chahiye

[7:06 PM] **Aashu:**
> _You: Feeling express Krna chahiye_
hmm samje

[7:07 PM] **You:** Nahi samjh skte aap

[7:07 PM] **You:** Aapke bas ki h hi nhi

[7:07 PM] **Aashu:**
> _You: Aapke bas ki h hi nhi_
hmm aisa hai

[7:07 PM] **Aashu:** kya baat hua mummy se

[7:08 PM] **You:** Mummy se mummy wali baat Hui

[7:08 PM] **You:** Khana pina

[7:08 PM] **Aashu:** accha

[7:08 PM] **Aashu:** kya kya bana hai

[7:09 PM] **You:** https://www.instagram.com/reel/DX6J_JcxAJm/?igsh=OTR2Y2ZrZ3BvZWNm

[7:09 PM] **You:** Ye dekho

[7:10 PM] **Aashu:** ye sab kon bej reha tmko

[7:15 PM] **You:** Koi n

[7:17 PM] **You:** https://www.instagram.com/reel/DYrn9mJTrNP/?igsh=MXFnM3Q4OXpsdGpudA==

[7:17 PM] **You:** Ye bhi dekho

[7:18 PM] **Aashu:** ye asleel asleel prank dekh rahi kya baat hai

[7:19 PM] **You:** Aise hi aa gaya 😂

[7:22 PM] **Aashu:** accha ji

[7:41 PM] **You:** [Image]

[7:46 PM] **Aashu:**
> _You: Image_
wahh

[8:34 PM] **Aashu:** https://youtube.com/shorts/oVsYOK4Owmk?si=jIklNiHPN5QrolXG

[9:11 PM] **Aashu:** [Image]

[9:17 PM] **Aashu:** [Image]

[10:01 PM] **Aashu:** pauch gayi

[10:03 PM] **You:** Almost

[10:04 PM] **Aashu:** ok kaise jaa rahi phir

[10:04 PM] **Aashu:** woha sw

[10:04 PM] **Aashu:** papa aays

[10:05 PM] **You:** Rapido se jayenge

[10:05 PM] **Aashu:** oohh

[10:05 PM] **Aashu:** chalta hai rapido

[10:06 PM] **You:** [Image] Yes

[10:06 PM] **Aashu:** oh ok good

[10:53 PM] **You:** Pahuch gaye ghar

[10:53 PM] **Aashu:** wahh badisa

[10:53 PM] **Aashu:** badiya

[10:53 PM] **Aashu:** enjoy karo

[11:10 PM] **You:** [Video]

[11:10 PM] **You:** [Video]

[11:10 PM] **You:** 😂😂😂

[11:11 PM] **Aashu:** aawaz kahe mute kar di

[11:11 PM] **Aashu:** puri kush hai mummy

[11:24 PM] **You:** Haaa

[11:24 PM] **You:** 😅😅

[11:43 PM] **Aashu:** kha li

[11:43 PM] **Aashu:** so gayi kya

---

## May 25, 2026

[12:09 AM] **You:** Nahii

[12:09 AM] **You:** Abhi khayi hu

[12:09 AM] **You:** Phone charge me lagayi thi

[3:31 AM] **Aashu:** ok

[7:10 AM] **You:** Good morning

[9:02 AM] **You:** So hi rhe ho kya

[10:00 AM] **Aashu:** good morning

[10:20 AM] **You:** Abhi uthe ho

[10:20 AM] **Aashu:** hh

[10:21 AM] **Aashu:** raat me neend khul gaya tha to phir padne lage the uth kar

[10:21 AM] **You:** Accha

[10:21 AM] **You:** Kab soye the

[10:21 AM] **Aashu:** 5

[10:22 AM] **You:** Ooo

[10:22 AM] **You:** Nasta hua kuch

[10:22 AM] **Aashu:** abhi to nhi

[10:22 AM] **Aashu:** dahi musli khaysnge

[10:22 AM] **Aashu:** washroom me hai

[10:22 AM] **You:** Ohh

[10:23 AM] **You:** Aaj h n interview

[10:23 AM] **Aashu:**
> _You: Aaj h n interview_
hmm

[10:23 AM] **You:** Nasta wagera kar ke ready ho jao

[10:23 AM] **Aashu:** hmm ready hi hai

[10:23 AM] **You:** Naha bhi lena ho sake to

[10:23 AM] **Aashu:** hh

[10:24 AM] **You:** Thoda bhagwan ko pranam bhi kar lena

[10:24 AM] **Aashu:** okk

[10:25 AM] **You:** Okk

[10:26 AM] **Aashu:** tab man lag reha ghar me

[10:26 AM] **You:** Haaa

[10:26 AM] **You:** Par sone nahi mil raha

[10:26 AM] **You:** Papa subah 7 baje hi utha diye

[10:26 AM] **Aashu:** kyu

[10:27 AM] **Aashu:** accha

[10:27 AM] **You:** Wahi garam pani nasta nahana

[10:27 AM] **You:** Lage the

[10:27 AM] **You:** Bas

[10:27 AM] **Aashu:** ho gaya sab

[10:27 AM] **You:** Bed pe leke

[10:27 AM] **You:** Ha naha liye

[10:27 AM] **You:** Nasta bhi ho gaya

[10:27 AM] **You:** Kab ka

[10:27 AM] **Aashu:** so jao ab

[10:28 AM] **You:** Abhi ab kya soungi

[10:28 AM] **You:** Mummy ko chay bhi pine nahi diye hain

[10:28 AM] **Aashu:** kya kar rahi phir

[10:28 AM] **Aashu:** kyu

[10:28 AM] **You:** Phle fruit chai kya jaruri h

[10:28 AM] **You:** Abhi mummy chai bana rahi h

[10:28 AM] **Aashu:** accha

[10:28 AM] **Aashu:** 😅

[10:29 AM] **You:** Papa gaye hain abhi

[10:29 AM] **You:** Daliya khayi hu

[10:29 AM] **You:** Fruit khayi hu

[10:29 AM] **You:** Wo rhte hain to kuch se kuch khate rho

[10:29 AM] **Aashu:**
> _You: Wo rhte hain to kuch se kuch khate rho_
sahi hai na

[10:31 AM] **You:** [Image]

[10:31 AM] **You:** Fafra yahi h

[10:34 AM] **Aashu:**
> _You: Image_
ohh but pata hai ye sab utna tikha nahi hota

[10:34 AM] **Aashu:** humko okok lagta

[10:36 AM] **You:** Nahi mujhe accha laga

[10:37 AM] **You:** Bahut soft u

[10:37 AM] **You:** H

[10:37 AM] **Aashu:** accha

[10:37 AM] **You:** Isko lane me dikkat hai tut jata h

[10:37 AM] **Aashu:** ohh

[10:37 AM] **You:** Jalebi ke sath accha lagta h

[10:38 AM] **Aashu:** okk samje

[10:45 AM] **You:** Haaa

[1:06 PM] **You:** All the very best

[1:06 PM] **You:** 🤞🤞

[1:06 PM] **You:** 😅😅

[1:06 PM] **Aashu:** interview lene koi aaya hi nai hai

[1:06 PM] **You:** Jaaa

[1:07 PM] **Aashu:** isme ye bhi dikkaz hai

[1:07 PM] **You:** Kyu

[1:07 PM] **Aashu:** [Image]

[1:07 PM] **Aashu:** hum join kar ke baithe hai

[1:07 PM] **You:** Cap laga lo

[1:07 PM] **Aashu:** ek baar aur aisa hua tha koi aaya hi nai

[1:08 PM] **You:** Message dalo na jo HR interview schedule kiya tha

[1:37 PM] **Aashu:** ho gaya interview

[1:37 PM] **Aashu:** ye chutiya mere se kuch khas pucha hi nahi 🥲

[1:37 PM] **Aashu:** 15 se 20 min me hi bola ki ho gaya

[1:38 PM] **Aashu:** isko mainly jo cheez chaiye the uspe hum utna kaam hi nahi kiye hai

[1:43 PM] **You:** Ohh

[1:43 PM] **You:** Fir koi response nhi kiya

[1:43 PM] **Aashu:**
> _You: Fir koi response nhi kiya_
kon

[1:44 PM] **Aashu:** hum jispe kaam karte shayad usko wo utna nai aata tha to wo kuch pucha nai utna use

[1:47 PM] **You:** Accha koi nahi

[2:40 PM] **You:** Office me ho?

[3:39 PM] **Aashu:** hh

[6:10 PM] **You:** Aa gaye

[6:22 PM] **Aashu:** abui aa3

[6:26 PM] **You:** Aaj to kafi time baith gaye

[6:27 PM] **Aashu:** hh 3 ghanta

[6:48 PM] **Aashu:** hello

[6:48 PM] **Aashu:** pyaz wala wo kaha hai

[7:24 PM] **You:** Kya

[7:30 PM] **Aashu:** hum karenge call

[7:30 PM] **Aashu:** baad me

[7:30 PM] **You:** Kya kar rahe ho

[7:30 PM] **Aashu:** meeting hai

[7:30 PM] **You:** Ok

[9:26 PM] **You:** Free nhi hue ho

[9:27 PM] **Aashu:** na

[9:27 PM] **Aashu:** sir dard kar reha bahut

[9:27 PM] **You:** Ohh

[9:27 PM] **You:** Kyu

[9:27 PM] **Aashu:** [Video]

[9:27 PM] **You:** Khaye nahi kuch

[9:28 PM] **Aashu:** ab kya hi khayenge

[9:28 PM] **Aashu:** ab kon banayega itna raat me

[9:28 PM] **You:** Kuch order hi kar lo

[9:28 PM] **Aashu:** maggi khaye the

[9:29 PM] **Aashu:**
> _You: Kuch order hi kar lo_
hmm dekhte hai

[9:35 PM] **You:** Kya soche ho

[9:36 PM] **Aashu:** lets see

[9:36 PM] **You:** When

[9:36 PM] **Aashu:** now

[9:37 PM] **You:** Order kar rahe ho kya

[9:38 PM] **Aashu:**
> _You: Order kar rahe ho kya_
kya

[9:38 PM] **Aashu:** kare

[9:38 PM] **You:** Mat karo abhi

[9:38 PM] **Aashu:** kyu

[9:39 PM] **You:** Meeting kab tak khatam hoga

[9:39 PM] **Aashu:** hoga thore der me

[9:40 PM] **Aashu:** kya hua

[9:40 PM] **Aashu:** egg fried rice bana lenge

[9:40 PM] **You:** Kaam kar lo aaram se hi khaoge na

[9:41 PM] **Aashu:** pyaz kaat ke rakha hua hai

[9:41 PM] **Aashu:** egg fried rice bana lenge

[9:41 PM] **You:** Haa sahi hoga

[9:41 PM] **You:** Easy bhi h

[9:41 PM] **Aashu:** hh wohi bana lenge

[9:41 PM] **Aashu:** pyaz kaat diye hai pehle hi

[9:41 PM] **Aashu:** chawal soch rahe chadha de

[9:42 PM] **You:** Abhi hi

[9:42 PM] **Aashu:** hh

[9:42 PM] **Aashu:** chawal chadha de rahe

[9:42 PM] **Aashu:** 9:45 ho gaya

[9:42 PM] **You:** Hmm ho to gaya hai

[9:42 PM] **Aashu:** meeting ka koi idea nahi kab tak chalega

[9:42 PM] **Aashu:** chalo chawal chadha de rahe

[9:42 PM] **You:** Kuch order hi kar lo

[9:42 PM] **Aashu:** sir dard kar reha

[9:42 PM] **You:** Pareshan ho jaoge

[9:43 PM] **You:** Abhi banane me

[9:43 PM] **Aashu:** soyenge jldi

[9:43 PM] **You:** To mat banao

[9:44 PM] **You:** Okk

[9:44 PM] **You:** Abhi mat banana kuch

[9:44 PM] **You:** Mai call karungi

[9:45 PM] **Aashu:** kyu call par hi khila degi kya humko

[9:46 PM] **You:** Kya pata aisa bhi ho jaye

[9:46 PM] **Aashu:** order hi kar le rahe phir

[9:47 PM] **You:** Kya order karoge

[9:47 PM] **Aashu:** dekh rahe

[9:48 PM] **You:** Mat karo

[9:48 PM] **Aashu:** kyu bhai

[9:48 PM] **Aashu:** tm kya order ki ho ye batao

[9:48 PM] **Aashu:** seedha seedha

[9:48 PM] **You:** 😛😛😛

[9:48 PM] **Aashu:** bus baat ghuma rahi hum samaj rahe hai na

[9:49 PM] **Aashu:** 😅

[9:49 PM] **Aashu:** jada kuch mat kar dena

[9:49 PM] **Aashu:** kya ki ho batao to

[9:49 PM] **You:** Hi Swati

I have placed an order for you from Zomato ❤️ 

Click on the link below to track your order
https://zoma.to/t/GEOJeVRL

[9:49 PM] **You:** Normal hi kiye h

[9:50 PM] **Aashu:** wahh bhai gajab

[9:50 PM] **Aashu:** itna pyar babu

[9:51 PM] **You:**
> _Aashu: itna pyar babu_
Hum to karte hi h

[9:51 PM] **You:** 😊

[9:51 PM] **Aashu:**
> _You: Hum to karte hi h_
hum bhi to karte hai

[9:53 PM] **You:** Mai jyda karti hu

[9:53 PM] **Aashu:**
> _You: Mai jyda karti hu_
hh wo to hai

[10:00 PM] **Aashu:** kitne me diya ya

[10:00 PM] **Aashu:** ye

[10:00 PM] **You:** Wo chhodo na

[10:00 PM] **Aashu:**
> _You: Wo chhodo na_
batao to

[10:00 PM] **You:** Khake dekho pahle accha hai ya nhi

[10:01 PM] **Aashu:** batao to

[10:01 PM] **Aashu:** 315 me diya na

[10:01 PM] **You:** Nhii

[10:17 PM] **Aashu:** [Image]

[10:26 PM] **You:** Kaisa laga

[11:10 PM] **You:** Hello

[11:10 PM] **You:** So gaye kya

[11:14 PM] **Aashu:** hello

[11:14 PM] **Aashu:**
> _You: Kaisa laga_
accha tha bahut

[11:32 PM] **You:** Kya kar rahe ho

---

## May 26, 2026

[12:05 AM] **You:** Kya ho gaya bhai

[12:05 AM] **You:** Aise kaise so  rahe ho bina bole

[6:36 AM] **Aashu:** good morning

[7:35 AM] **You:** Good morning

[9:34 AM] **Aashu:** good morning

[9:49 AM] **You:** Abhi

[10:24 AM] **Aashu:** good morning

[10:31 AM] **You:** Pura din good morning hi ho Raha hai

[10:32 AM] **Aashu:** good morning

[10:36 AM] **You:** 😏

[11:21 AM] **Aashu:** good morning

[11:29 AM] **You:** 🙏

[12:27 PM] **Aashu:** kaam kar rahe

[12:28 PM] **You:** Jyda Busy ho rhe ho

[12:30 PM] **Aashu:** yes

[12:31 PM] **You:** Sahi h

[1:10 PM] **You:** Hello

[1:15 PM] **Aashu:** [Video]

[1:15 PM] **Aashu:** jhoot nahi bol rahe

[1:48 PM] **Aashu:** hello

[2:16 PM] **You:** Hmm

[4:41 PM] **You:** Kuch jyada busy nhi ho gaye ho

[4:42 PM] **Aashu:** _This message was deleted_

[4:42 PM] **Aashu:** kaam bahut hai yaar

[4:42 PM] **Aashu:** kl rk jaa reha hai na

[4:43 PM] **You:** Call bhi nahi dikh raha h bilkul

[4:56 PM] **Aashu:** call me

[4:56 PM] **Aashu:**
> _You: Video: I'm coming mahadev 🙏_
kaha jaa rahi

[4:57 PM] **You:** Kal ja rahe somnath

[4:57 PM] **You:** Means aaj raat me

[5:36 PM] **Aashu:**
> _You: Means aaj raat me_
wahh

[7:41 PM] **Aashu:** kya babu

[7:41 PM] **Aashu:** kon jeetega aaj

[7:42 PM] **You:** RCB forever ♾️

[7:42 PM] **Aashu:** gaya

[7:42 PM] **Aashu:** pehla

[7:43 PM] **Aashu:** lekin jeet jayega rcb

[7:43 PM] **You:** Dukhi kyu ho fir😁

[7:45 PM] **Aashu:** dekh rahi hona

[7:46 PM] **You:** Han ji

[8:38 PM] **Aashu:** aaj line bahut kat reha

[8:38 PM] **Aashu:** problem ho reha

[8:46 PM] **You:** Ohhhooo

[9:20 PM] **You:** Kya khela hai aaj patidar

[9:20 PM] **You:** 😅😅

[9:21 PM] **You:** Ab batao jeetegi na RCB

[9:21 PM] **Aashu:** prhle hi jeet gaya tha

[9:23 PM] **You:** pahle kaha

[9:24 PM] **Aashu:** sabse pehle

[9:27 PM] **You:** Ab bologe match fix h

[9:27 PM] **You:** Naaa

[9:27 PM] **Aashu:** nhi

[9:27 PM] **Aashu:** accha khela rcb

[9:27 PM] **Aashu:** aur rcb gujarat se bahut accha team hai

[9:29 PM] **You:** Waaah

[10:54 PM] **You:** So gaye kya

[10:54 PM] **Aashu:** [Video] khaye bhi nahi hai abhi tak kuvh

[10:55 PM] **You:** To kuch kha lo na

[11:31 PM] **You:** Kya hua

[11:31 PM] **You:** Khatam hua nhi abhi meeting

[11:33 PM] **Aashu:** haa ho gaya

[11:33 PM] **Aashu:** khana bana rahe the

[11:33 PM] **Aashu:** kha liye

[11:34 PM] **You:** Kya banaye the

[11:34 PM] **Aashu:** egg fried rice

[11:35 PM] **You:** Ohh

[11:36 PM] **You:** Ho gaya khana

[11:36 PM] **Aashu:** hh

[11:36 PM] **Aashu:** tmlog nikal gayi kya

[11:36 PM] **You:** Abhi nahii

[11:36 PM] **You:** Papa to aaye bhi nahi hai abhi

[11:37 PM] **You:** 2 baje train h

[11:37 PM] **You:** Station piche me hi h

[11:37 PM] **You:** Niklenge aaram se

[11:37 PM] **Aashu:** accha

[11:37 PM] **Aashu:** okok

[11:38 PM] **You:** Hmm

[11:38 PM] **You:** Ab sona h

[11:38 PM] **Aashu:** hh yaar ab kya karenge

[11:38 PM] **You:** Haa so jao

[11:38 PM] **You:** Bed pe aa gaye kya

[11:39 PM] **Aashu:**
> _You: Bed pe aa gaye kya_
hh

[11:39 PM] **Aashu:** kyu

[11:40 PM] **You:** Barish chhuta

[11:40 PM] **Aashu:** hh

[11:41 PM] **You:** Okk

[11:41 PM] **Aashu:** happy journey

[11:41 PM] **Aashu:** acche se jao

[11:42 PM] **You:** Hnn ji

[11:42 PM] **You:** Okok

[11:42 PM] **You:** Acche se hi jayenge

[11:42 PM] **Aashu:** hmm

---

## May 27, 2026

[6:21 AM] **You:** Good morning ❤️

[9:13 AM] **Aashu:** gm

[11:59 AM] **You:** [album message]

[11:59 AM] **You:** [Image]

[11:59 AM] **You:** [Image]

[11:59 AM] **You:** [Image]

[12:02 PM] **You:** [album message]

[12:02 PM] **You:** [Image]

[12:02 PM] **You:** [Image]

[12:05 PM] **You:** [Image]

[12:06 PM] **Aashu:** wahh pyari lag rahi

[12:07 PM] **You:** Haa?

[12:08 PM] **Aashu:** yes

[12:32 PM] **You:** Pareshan ho gaye pura saree pahan ke

[12:32 PM] **You:** Bhut utar gaya mer saree ka

[12:33 PM] **You:** 😅

[12:33 PM] **Aashu:** but accha lag reha saree

[12:34 PM] **You:** Itni garmi

[12:34 PM] **You:** Or saree

[12:34 PM] **Aashu:** hmm

[12:35 PM] **You:** [Video]

[12:35 PM] **You:** Ye dekho 😅😅

[12:36 PM] **Aashu:** pani me sharee pehan kar kahe jaa rahi

[12:38 PM] **You:** Maza aa raha tha

[12:39 PM] **Aashu:** badiya enjoy karo

[12:40 PM] **You:** Hmm

[3:27 PM] **You:** Aa gaye ghar

[3:27 PM] **Aashu:** office nahi gaye hai

[3:27 PM] **Aashu:** kaam itna hai aaj yaar

[3:27 PM] **Aashu:** kya bole

[3:29 PM] **You:** Ooo

[3:29 PM] **You:** Mai apne bare me boli ghar aa gaye

[3:29 PM] **Aashu:**
> _You: Mai apne bare me boli ghar aa gaye_
😅😅

[3:29 PM] **Aashu:** okok

[3:29 PM] **Aashu:** bahut jldi

[3:29 PM] **Aashu:** mtlb jada dur nahi hai

[3:30 PM] **You:** Nahii door nahi h

[3:30 PM] **You:** Garmi itni jyada thi

[3:30 PM] **You:** Kahi or gaye hi nahi

[3:30 PM] **You:** Baap re kaise ghumenge rameshwaram

[3:30 PM] **You:** Itni dhu me

[3:31 PM] **You:** [Image] Kitna tanning ho gaya hai dekho na🥺

[3:32 PM] **Aashu:**
> _You: Image: Kitna tanning ho gaya hai dekho na🥺_
hmm bahut jada

[3:32 PM] **Aashu:**
> _You: Baap re kaise ghumenge rameshwaram_
woha to aur garmi rahega

[3:41 PM] **You:** Pareshan hi hona hai or kya

[3:42 PM] **Aashu:**
> _You: Pareshan hi hona hai or kya_
na

[3:42 PM] **Aashu:** hum check kiye 31 degree hai abhi

[3:58 PM] **You:** Kahan

[3:59 PM] **You:** Rameshwaram me

[4:01 PM] **You:** [Image]

[4:01 PM] **You:** ☹️☹️☹️

[5:19 PM] **Aashu:**
> _You: Image_
garmi itna hai

[5:19 PM] **Aashu:**
> _You: Rameshwaram me_
hh

[8:08 PM] **Aashu:** kya mera baccha maar reha na

[8:13 PM] **You:** Kyaaa

[8:15 PM] **Aashu:** vaiabhh

[8:16 PM] **You:** Accha haa

[8:16 PM] **You:** Century maar diya

[8:16 PM] **Aashu:** out ho gaya yaar

[8:16 PM] **Aashu:** 97 par

[8:16 PM] **You:** Jaa

[8:16 PM] **You:** [Image] Mai abhi nahai hu

[8:24 PM] **Aashu:**
> _You: Image: Mai abhi nahai hu_
accha garmi hai kya bahut

[8:25 PM] **You:** Abhi thik h sham me garmi kam jata h

[8:25 PM] **You:** Din me bahut ho jata h

[8:25 PM] **Aashu:** ohh

[8:26 PM] **You:** Sare mera status dekh ke bola rhe akele akele husband kahan h

[8:27 PM] **You:** 🫣

[8:40 PM] **You:** Kaam kar rahe ho kya

[9:01 PM] **Aashu:**
> _You: Kaam kar rahe ho kya_
haa

[9:01 PM] **Aashu:** karte hai call

[9:15 PM] **You:** Okk

[9:37 PM] **Aashu:** hello

[9:39 PM] **You:** Hnn ji

[9:44 PM] **Aashu:** aur batao

[9:45 PM] **Aashu:** kya kya hua

[9:57 PM] **You:** Kaise bataye

[9:57 PM] **Aashu:** call kare

[9:57 PM] **You:** Ok

[10:46 PM] **You:** Ho gaya bat mummy se

[11:16 PM] **Aashu:** hello

[11:24 PM] **You:** Hnn

[11:46 PM] **You:** So rhi hu

[11:46 PM] **You:** Good night

---

## May 28, 2026

[6:52 AM] **Aashu:** good morning

[8:20 AM] **You:** Gm

[10:11 AM] **You:** So hi rhe ho kya

[10:51 AM] **Aashu:** uthe

[10:58 AM] **You:** Waah

[10:58 AM] **You:** Abhi

[10:59 AM] **Aashu:** hmm

[11:07 AM] **You:** [Forwarded] [Document] 8937137329.pdf

[4:02 PM] **You:** _You deleted this message_

[4:02 PM] **You:** Hello

[4:03 PM] **Aashu:** yes

[4:03 PM] **You:** Kya ho rha h

[4:05 PM] **Aashu:** office me hai

[4:09 PM] **You:** Ok

[9:15 PM] **You:** Hello

[9:20 PM] **Aashu:** [Image]

[9:20 PM] **Aashu:** abhi just ghar aaye

[9:20 PM] **You:** Office se

[9:20 PM] **Aashu:** hh

[9:20 PM] **You:** Itna late kyu

[9:21 PM] **Aashu:** kaam bahut tha

[9:21 PM] **Aashu:** ghar me karte ise accha wohi kar liye

[9:21 PM] **Aashu:** aur aane ke time pani parne laga bahut tez

[9:21 PM] **Aashu:** phir itna jada traffic ho gaya

[9:33 PM] **You:** Ohh

[9:43 PM] **You:** Fir khana pina

[9:43 PM] **You:** Kha ke aaye ho

[9:44 PM] **Aashu:** nahi mangwa rahe

[9:46 PM] **You:** Hmm

[10:41 PM] **You:** Mai kbhi call na karu to karoge bhi nhi na

[11:26 PM] **Aashu:** kya hua

---

## May 29, 2026

[9:30 AM] **You:** Kuch nhi

[10:34 AM] **Aashu:** hello

[10:34 AM] **Aashu:** good morning

[10:35 AM] **You:** Sahi h

[10:37 AM] **You:** _You deleted this message_

[2:28 PM] **You:** [Image] Khakhra

[2:47 PM] **Aashu:**
> _You: Image: Khakhra_
mast bro

[2:47 PM] **Aashu:** enjoy

[4:43 PM] **Aashu:**
> _You: Image: Khakhra_
ye sab me pizza ka taste aata

[5:44 PM] **You:**
> _Aashu: ye sab me pizza ka taste aata_
Sab alag alag h

[7:05 PM] **Aashu:** ohh

[8:19 PM] **You:** Aaj suryavanshi nahi khel rha kyu bhai

[8:30 PM] **Aashu:** pitch hlka hard hai

[8:30 PM] **Aashu:** aur wicket gir reha dusri taraf se isiliye aaram se khel reha

[8:35 PM] **You:** Ohh

[9:31 PM] **You:** Hua khana

[9:58 PM] **Aashu:** khayenge

[9:59 PM] **You:** Kuch banaye ho

[10:00 PM] **Aashu:** hh

[10:00 PM] **You:** Kya

[10:23 PM] **Aashu:** dekhte hai

[10:28 PM] **You:** Abhi dekhna hi h

[10:30 PM] **Aashu:** paratha managays hai

[10:30 PM] **Aashu:** omlete bana lenge

[10:32 PM] **You:** Okk

[11:01 PM] **Aashu:** good night

[11:15 PM] **You:** Okk

[11:15 PM] **You:** Haar gaya rr

[11:15 PM] **Aashu:** hmm dekhe

[11:16 PM] **You:** Dukhi ho kya

[11:16 PM] **Aashu:** hmm thora

[11:17 PM] **You:** RCB kr liye accha h na final jitega😅

[11:17 PM] **Aashu:** hh wo to hai

---

## May 30, 2026

[9:53 AM] **You:** Gd mng

[10:26 AM] **You:** So hi rhe ho kya abhi tak

[10:44 AM] **Aashu:** good morning

[10:44 AM] **Aashu:** uthenge ab

[10:45 AM] **You:** Itna late

[10:47 AM] **Aashu:** yes

[10:48 AM] **You:** Uth jao ab

[11:29 AM] **You:** Over nahi kar rahe ho ab

[1:53 PM] **Aashu:** what happened

[1:53 PM] **You:** Daru pi ke sote ho kya

[1:53 PM] **Aashu:**
> _You: Daru pi ke sote ho kya_
kya ho gaya

[1:53 PM] **Aashu:** aur jada mat bolo samji

[1:54 PM] **You:** Jyda kya bol rahe

[1:54 PM] **You:** Khud batao na Kya hua h

[1:54 PM] **You:** Aise random se ye behaviour kyu ho gaya hai

[1:54 PM] **Aashu:** padh rahe the raat me phir late se soye

[1:55 PM] **Aashu:** tmse baat hi karna bekar hai msg mat kiya karo humko

[1:55 PM] **You:**
> _Aashu: tmse baat hi karna bekar hai msg mat kiya karo humko_
Ok

[1:56 PM] **You:** Karo jo man h ab se hum na kuch puchenge ma kuch kahenge

[1:56 PM] **Aashu:**
> _You: Karo jo man h ab se hum na kuch puchenge ma kuch kahenge_
badiya hai tumhare liye samji

[1:57 PM] **Aashu:**
> _You: Daru pi ke sote ho kya_
aur jara soch samaj kar bola karo warna hum kuch bolne lagenge to phir bura lag jayega

[1:58 PM] **You:**
> _You: Daru pi ke sote ho kya_
Ye fun me bole the hum

[1:58 PM] **You:**
> _Aashu: aur jara soch samaj kar bola karo warna hum kuch bolne lagenge to phir bura lag jayega_
Kon si nayi baat hogi mere liye bolte hi ho bolo

[11:00 PM] **Aashu:** [Image]

[11:00 PM] **Aashu:** [Image]

[11:01 PM] **Aashu:** [Image]

[11:39 PM] **Aashu:** so gayi kya

[11:51 PM] **Aashu:** accha dekh kar no reply ok fine

[11:51 PM] **Aashu:** chalo bbyy fn

[11:51 PM] **Aashu:** gn

[11:57 PM] **You:**
> _Aashu: Image_
Nice

[11:57 PM] **You:** Phone charge me tha

[11:58 PM] **Aashu:** yaar humlog jeet gaye tournament

[11:58 PM] **Aashu:** ek match me man of the match hum the

---

## May 31, 2026

[12:18 AM] **You:** Great

[12:18 AM] **You:** Congratulations 🎉

[12:20 AM] **You:** [Image]

[12:24 AM] **Aashu:**
> _You: Image_
bhai ye sab photo

[12:25 AM] **Aashu:** aaj abhishek ke ghar hai

[12:25 AM] **Aashu:** iska housewarming party hai

[12:26 AM] **You:**
> _Aashu: bhai ye sab photo_
Caption padho na

[12:26 AM] **You:**
> _Aashu: iska housewarming party hai_
Okok

[12:27 AM] **Aashu:**
> _You: Image_
mtlb nhi samje

[12:28 AM] **You:** Koi n enjoy

[12:32 AM] **Aashu:** mtlb to batao uska

[12:35 AM] **You:** Gana lagai h

[12:35 AM] **You:** Yahi wahi caption dali h

[2:12 PM] **Aashu:** ohh ok

[6:58 PM] **Aashu:** hello

[6:58 PM] **Aashu:**
> _You: Video: God One more time 🤞_
😂

[7:05 PM] **You:** Hmm

[7:06 PM] **Aashu:** kon jeetega

[7:07 PM] **You:** Obviously RCB

[7:08 PM] **You:** [Image] Laptop me upgrade kyu mang raha

[7:09 PM] **Aashu:** logout ho gaya hoga

[7:09 PM] **Aashu:** mere number se login kar lona

[7:09 PM] **Aashu:** 8789684492

[7:09 PM] **You:** Ohh

[7:10 PM] **You:** Hotstar one month ke liye hi diya tha

[7:10 PM] **Aashu:** nahi na

[7:10 PM] **You:** [Image]

[7:10 PM] **Aashu:** hum do teen jagah login kiye hoenge

[7:11 PM] **You:** Ook

[7:11 PM] **Aashu:**
> _You: Image_
ye tumhara login number hai

[7:11 PM] **Aashu:** mere number se karo na

[7:11 PM] **Aashu:** mere me hai na subscription

[7:11 PM] **You:** Otp

[7:11 PM] **Aashu:** 9631

[7:12 PM] **You:** [Image] Kisme logout kare

[7:12 PM] **Aashu:**
> _You: Image: Kisme logout kare_
chrome

[7:13 PM] **You:** Ok

[7:13 PM] **Aashu:** chalo aaj ek party ka bet lagate ok

[7:13 PM] **You:** Dekh lo

[7:13 PM] **You:** 3 already pending h

[7:14 PM] **Aashu:**
> _You: 3 already pending h_
chill aate hi next ek month me sab clear kar denge

[7:14 PM] **Aashu:** aise aaj jeetega rcb hi

[7:14 PM] **Aashu:** but match dekhne me mazza aayega isliye laga rahe bhs

[7:14 PM] **You:** Okk

[7:14 PM] **You:** Mai rcb

[7:16 PM] **Aashu:** ok mai gt

[7:16 PM] **Aashu:** rcb ka chase aa gaya hai chance badh gaya hai

[7:17 PM] **You:** Ab jo bhi ho

[7:17 PM] **You:** Dekhte hain

[7:17 PM] **Aashu:** okk

[7:17 PM] **Aashu:** tv par nhi dekh rahi match

[7:18 PM] **You:** Tv me hotstar nhi h subscription or yahan android tv nhi hai

[7:19 PM] **Aashu:** okk ok got it

[7:23 PM] **Aashu:** [Image] kal pg ka sab dost aaya phir phor diya iska

[7:23 PM] **You:** Jaaaa

[7:25 PM] **You:** Kaise hua ye

[7:31 PM] **Aashu:** abhinay se fut gaya

[7:34 PM] **You:** Kuch bola nhi chaudhari

[7:34 PM] **You:** Kya kar raha tha aisa bhai

[7:35 PM] **You:** _You deleted this message_

[7:37 PM] **Aashu:** kya kya delete karti bro

[7:39 PM] **You:** Kuch nahi aise hi

[7:41 PM] **You:** Chaudhari ke yahan hi ho kya

[7:42 PM] **Aashu:**
> _You: Chaudhari ke yahan hi ho kya_
yes

[7:42 PM] **Aashu:** yahi dekh rahe match

[7:44 PM] **You:** Ok

[7:44 PM] **You:** Gill out 😁

[7:45 PM] **Aashu:** hmm

[7:45 PM] **Aashu:** jeet jaywga gt

[7:46 PM] **You:** Let's see

[7:52 PM] **Aashu:** chalo 4 party ho gaya tumhara

[7:53 PM] **Aashu:** ye wala party thora high level jagah par denge

[7:54 PM] **You:** 😂😂

[7:54 PM] **You:** Abhi hi haar kan gaye kya 😅😅😅

[7:58 PM] **Aashu:**
> _You: Abhi hi haar kan gaye kya 😅😅😅_
are ye to pata hi tha humko

[8:15 PM] **You:** Matlab ab yahi bologe ki fix tha

[8:44 PM] **You:** Kya ho gaya bhai ab TV band ho gaya kya

[9:20 PM] **Aashu:**
> _You: Matlab ab yahi bologe ki fix tha_
fix nhi tha

[9:21 PM] **Aashu:** rcb acchi team hai

[9:30 PM] **You:** Accha

[9:44 PM] **You:**
> _Aashu: ye wala party thora high level jagah par denge_
Decide mai karungi

[9:49 PM] **Aashu:**
> _You: Decide mai karungi_
ye deal nhi hua hai

[9:52 PM] **You:** Haa to jo jitega wahi decide karega na

[11:25 PM] **Aashu:**
> _You: Haa to jo jitega wahi decide karega na_
okl

[11:28 PM] **You:** 😂😂😂🥺

[11:30 PM] **Aashu:** hash rahi

[11:31 PM] **You:** Haaa😅😅😅

[11:31 PM] **Aashu:** jeet gaya na

[11:31 PM] **Aashu:** tab kaha party chaiye

[11:34 PM] **You:** Wo batayenge

[11:34 PM] **You:** Baad me

[11:34 PM] **Aashu:**
> _You: Wo batayenge_
abhi batao

[11:35 PM] **You:** Abhi kaise bataye

[11:41 PM] **Aashu:** accha kl batana

[11:41 PM] **Aashu:** rcb fan

[11:42 PM] **Aashu:** lagatar do saal

[11:42 PM] **You:** Yesss

[11:42 PM] **Aashu:** is baar to tmko kushi me party dena chaiys

[11:42 PM] **Aashu:** rcb jeeta hai

[11:42 PM] **You:** Sare team ek taraf rcb ek taraf

[11:42 PM] **You:** Wo to de denge but bet ka to chahiye na

[11:43 PM] **You:** [Image] Ye csk ki thi

[11:59 PM] **Aashu:**
> _You: Image: Ye csk ki thi_
csk to ab chutiya ho gaya hai uska team to ab kabhi nahi jeetega

---

## June 1, 2026

[12:00 AM] **You:** Sab ka time aata h ek time me rcb ke liye bhi log yahi bolte the

[12:07 AM] **Aashu:**
> _You: Sab ka time aata h ek time me rcb ke liye bhi log yahi bolte the_
haa wohi hai

[12:07 AM] **Aashu:** abhi rcb ka team accha hai balance hai pura

[12:09 AM] **You:** Hmm

[12:42 AM] **Aashu:** kya utha li cup

[12:43 AM] **You:** Haa naa

[12:48 AM] **You:** Ok good night

[12:49 AM] **Aashu:** sone jaa rahi

[12:49 AM] **You:** Haa

[12:50 AM] **Aashu:** lyu

[12:50 AM] **Aashu:** kyu

[12:50 AM] **Aashu:** insta chalao

[12:51 AM] **Aashu:** papa so gaye

[12:51 AM] **You:** Haa

[12:51 AM] **Aashu:** insta chalao har reels to aaj rcb ka dikheha

[12:51 AM] **You:** Dekh liye

[12:51 AM] **You:** Ab nhi dekhna

[12:55 AM] **Aashu:** ok good

[5:13 PM] **You:** Hello

[5:13 PM] **Aashu:** hey

[5:14 PM] **You:** Koi matlab nahi hai na

[5:14 PM] **Aashu:** mtlb nhi samje

[5:16 PM] **You:** No call no message

[5:16 PM] **Aashu:** ohh

[5:16 PM] **Aashu:** msg to ho hi reha

[5:21 PM] **You:** Hmm ho raha hai okk

[5:27 PM] **Aashu:** yes any more concern u have

[5:32 PM] **You:** No thankyou this is enough for me

[5:32 PM] **Aashu:** ok cool

[5:33 PM] **Aashu:** ticket tatkal me 4th ko try kar rahi hai na

[5:37 PM] **You:** Hmm bole to h papa ko

[5:37 PM] **You:** Wo lah rahe 7 ka hi karo ho jayega confirm

[5:37 PM] **Aashu:** jo tmko sahi lagr

[5:38 PM] **Aashu:** papa mere teen din se tmko bol rahe the bolne mera kaam tha bolna to bol diye

[5:39 PM] **Aashu:** baad baki tmlog ka jab man ho karne ka karo

[5:40 PM] **You:**
> _Aashu: papa mere teen din se tmko bol rahe the bolne mera kaam tha bolna to bol diye_
Accha bol k kaam kar rahe ho

[5:40 PM] **You:** Okk

[5:40 PM] **Aashu:**
> _You: Accha bol k kaam kar rahe ho_
tmlog ko kuch sunna rehta nhi hai karna apne man ka hi hai isiliye hum bolte nhi hai

[5:41 PM] **Aashu:** tmlog ye sab mamle me humse bahut tez ho to bolne ka mtlb hai nhi

[5:42 PM] **You:** Kya apne man ka kar liye hain or kya kar rahe hain

[5:42 PM] **You:** Tumlog tumlog kya hai ye

[5:43 PM] **Aashu:** chalo bbyy jab karna ho karo

[5:43 PM] **Aashu:** 7 ko ho jayega 7 ka karo no problem

[5:45 PM] **You:** Ok

[7:25 PM] **You:** Kya kar rahe ho

[8:24 PM] **Aashu:** meeting me hai

[8:25 PM] **You:** Okk free ho ke Krna

[8:26 PM] **Aashu:** kya hua bolo

[8:26 PM] **You:** Kuch nhi aise hi

[8:29 PM] **Aashu:** ok

[8:57 PM] **Aashu:** hello

[9:04 PM] **You:** [Image]

[9:05 PM] **You:** [Image]

[9:24 PM] **Aashu:** accha mukesh bhai ke ghar aayi ho

[9:24 PM] **You:** Nhi resturant gir gamthi

[9:33 PM] **Aashu:** oh ok

[9:33 PM] **Aashu:** accha rush hai

[10:37 PM] **You:** Bahut hota h

[11:22 PM] **You:** Hello

[11:26 PM] **Aashu:** hmm

[11:36 PM] **You:** Soye nahi ho abhi

[11:38 PM] **Aashu:** jaa rahe

[11:38 PM] **Aashu:** meeting tha ek

[11:38 PM] **You:** Abhi tak

[11:38 PM] **Aashu:** hh

[11:39 PM] **Aashu:** ek meeting tha business se rk nhi hai to humko attend karna

[11:49 PM] **You:** Ohh

[11:49 PM] **You:** Ho gaya

[11:51 PM] **Aashu:** hmm

[11:51 PM] **You:** Okk

[11:54 PM] **You:** Khana?

[11:56 PM] **Aashu:** ho gaya

[11:56 PM] **Aashu:** chalo good night

[11:57 PM] **You:** Ok

---

## June 2, 2026

[9:15 AM] **You:** Good morning

[10:54 AM] **Aashu:** gm

[11:14 AM] **You:** Kya kar rahe ho

[11:14 AM] **Aashu:** baithe hai bolo

[11:16 AM] **You:** Khud se call nhi kar skte ho

[11:22 AM] **Aashu:** i can

[11:45 AM] **Aashu:** ye bol rahe the ki agar tm 6 tak aa jayegi to humlog weekend me tirupati jaa sakte

[11:45 AM] **Aashu:** to 5 ka ticket try karna hai to kar lena

[11:57 AM] **You:** Okk try to karna hi h

[12:11 PM] **Aashu:** ok

[12:18 PM] **You:** Call karo baat karni h

[12:19 PM] **Aashu:** i m in meeting

[12:21 PM] **You:** Okk free ho ke Krna

[12:54 PM] **You:** Bahut bure ho😡😡😡

[2:25 PM] **You:** Papa mummy ka jo ticket hai aane ka wo mujhe send karna

[2:29 PM] **Aashu:**
> _You: Papa mummy ka jo ticket hai aane ka wo mujhe send karna_
kyu kya hua

[2:30 PM] **You:** Hai mujhe kuchh kaam

[2:30 PM] **You:** Do na

[2:32 PM] **Aashu:** kya pehle batao

[2:32 PM] **Aashu:** pnr hum dekh rahe abhi utna hi waiting hai

[2:32 PM] **Aashu:** unka do ticket hai tmko kon sa chaiye

[2:33 PM] **You:** Kal wala

[2:33 PM] **Aashu:** kya kaam hai

[2:33 PM] **Aashu:** pehle ye batai

[2:33 PM] **You:** Nhi bhejna h

[2:38 PM] **Aashu:** pehle kaam batana parega

[2:40 PM] **You:** Okk

[2:41 PM] **Aashu:** kya kaam hai

[2:41 PM] **You:** Kuch nhi

[2:41 PM] **Aashu:** okk

[2:55 PM] **You:** Nahi bhej rhe ho na

[2:56 PM] **Aashu:** pehle kaam batao

[2:58 PM] **You:** Are check karna h

[2:58 PM] **You:** Confirm hoga ki nahi

[2:58 PM] **You:** Itna ghichpich kyu karte ho

[2:58 PM] **Aashu:** wahh tmko pura pata chal jayega hoga ki nahi

[2:58 PM] **You:** Hum kuch kar denge kya ticket ka

[2:59 PM] **Aashu:** humko to pata hi nai chalega

[2:59 PM] **You:** Ticket bhejne me koi dikkat h

[2:59 PM] **Aashu:** [Forwarded] [Document] 6401655237.pdf

[3:00 PM] **Aashu:** dekh kar batao to coinfirm hoga ki nai

[3:02 PM] **Aashu:** hoga ki nhi

[3:05 PM] **You:** Ho jayega RAC tak

[3:05 PM] **Aashu:** wahh ye to mereko pata hi nhi tha

[3:06 PM] **You:** Thik h

[3:06 PM] **You:** Bas

[3:06 PM] **You:** Acchi baat hai pata tha to

[5:17 PM] **Aashu:** yesss

[5:17 PM] **Aashu:** aaj kl alag problem ho reha

[5:17 PM] **Aashu:** ye daily itna pani par reha ki office me fash jaa rahe

[7:15 PM] **You:** Badhiya hai na

[7:15 PM] **You:** Office bhi ho ja raha

[7:15 PM] **You:** Mausam bhi thanda

[8:47 PM] **Aashu:** nahi yaar

[8:48 PM] **Aashu:** traffic itna ganda hota pani chutne ke baad

[8:48 PM] **Aashu:** ek ghanta lag gaya aaj aane me

[8:59 PM] **You:** Ohhoo

[8:59 PM] **You:** Aa gaye ghar

[9:18 PM] **Aashu:** yes

[9:37 PM] **You:** Ok

[10:58 PM] **You:** Hello

[11:05 PM] **Aashu:** yes

[11:07 PM] **You:** Nothing good night

[11:07 PM] **Aashu:** good night

[11:10 PM] **Aashu:** mummy log ka to waiting hi rah gaya

[11:10 PM] **You:** RAC bhi nhi hua

[11:10 PM] **Aashu:** nhi

[11:11 PM] **You:** Chart ready ho gaya

[11:12 PM] **Aashu:** yes

[11:13 PM] **You:** Fir ab kya

[11:17 PM] **Aashu:** ab cancel sab

[11:17 PM] **Aashu:** rameshwaram sab program cancel

[11:17 PM] **Aashu:** ab aa hi nhi payegi tab

[11:18 PM] **You:** Accha bol diye or mai maan gayi naa

[11:18 PM] **Aashu:** hmm

[11:19 PM] **You:** Thik h fir

[11:19 PM] **You:** Mai bhi apna mana kar de rhi hu

[11:19 PM] **You:** Ticket nhi krne

[11:20 PM] **Aashu:** okk

[11:20 PM] **You:** Bol du na papa ko

[11:20 PM] **Aashu:** yes

[11:20 PM] **You:** Ok

[11:29 PM] **You:** Bol diye hain

[11:30 PM] **You:** Ab mai Lohra chali shadi ke baad aaungi

---

## June 3, 2026

[10:05 AM] **Aashu:** ok

[10:44 AM] **Aashu:** mummy log ka aise kl train hai

[11:29 AM] **You:** Accha

[11:30 AM] **You:** Mujhe to pata hi nhi tha

[12:03 PM] **Aashu:**
> _You: Mujhe to pata hi nhi tha_
ohh

[12:03 PM] **Aashu:** so sad

[12:04 PM] **You:** ☹️☹️

[4:57 PM] **Aashu:** tumhara kitna baje train hai

[4:57 PM] **Aashu:** ho gaya ticket tumhara

[6:09 PM] **You:** Aaj thodi hoga

[6:10 PM] **You:** Kal hoga

[6:10 PM] **Aashu:** ohh

[6:10 PM] **Aashu:** full ready ho

[6:10 PM] **You:** Mera ready hone se kya hoga

[6:10 PM] **You:** Ticket hoga tabhi na

[6:10 PM] **Aashu:** yes

[6:12 PM] **You:** Wahan mummy Papa ka anniversary kab aata h

[6:12 PM] **Aashu:** kyu

[6:13 PM] **You:** Mujhe nhi pata h isliye

[6:13 PM] **Aashu:** aa reha bus

[6:13 PM] **You:** Ab isme bhi dikkat ho rha batane me

[6:13 PM] **Aashu:** 9th ko

[6:14 PM] **You:** Ok

[6:14 PM] **Aashu:** ok

[9:27 PM] **You:** Hello

[9:30 PM] **Aashu:** yes

[9:30 PM] **You:** Boliye

[9:34 PM] **Aashu:** kha li panipuri

[9:35 PM] **You:** Yess

[9:36 PM] **You:** Bahut kha liye

[9:36 PM] **Aashu:** ok good

[9:57 PM] **You:** Kya ho gya ab

[10:13 PM] **Aashu:** kuch nhi

[10:13 PM] **Aashu:** ph charge me lagaye the

[10:15 PM] **You:** Meri badi mummy no mang rahi hai

[10:15 PM] **You:** Baat kregi

[10:16 PM] **You:** May be bhaiya call kare

[10:16 PM] **Aashu:**
> _You: May be bhaiya call kare_
kon bhaiya

[10:16 PM] **You:** Jiski shadi ho rahi hai

[10:16 PM] **You:** Gorelal bhaiya

[10:16 PM] **Aashu:** tm jaa rahi

[10:17 PM] **You:** Call karoge to bataungi

[10:17 PM] **You:** Itna type nahi hota

[10:17 PM] **Aashu:** ok haath me dard hai

[10:17 PM] **Aashu:** jada pani puri kha li

[10:17 PM] **You:** Haa

[10:18 PM] **You:** Ho gaya hai dard dimag me bhi ho gaya h

[10:18 PM] **Aashu:** kyu

[10:18 PM] **You:** Kuch log hain zindagi me aise jo dete rhte hain bina matlab me

[10:19 PM] **Aashu:** hmm badiya hai

[10:20 PM] **You:** Haaaaaaaaaa

[10:21 PM] **You:** Karoge call

[11:14 PM] **You:** [Image]

---

## June 4, 2026

[9:06 AM] **Aashu:** tab ready ho

[9:11 AM] **You:** Haaa

[9:11 AM] **You:** Agent ko to bola hua hai

[9:11 AM] **Aashu:** ok cool

[9:12 AM] **You:** Abhi fir bole hain

[9:12 AM] **Aashu:** ok cool

[9:12 AM] **You:** [Image]

[9:12 AM] **Aashu:** ok cool

[9:13 AM] **You:** Hmm

[9:14 AM] **You:** Mummy log nikal gayi Ghar s3

[9:14 AM] **Aashu:** yes

[9:15 AM] **You:** Sahi h

[9:15 AM] **Aashu:** yes

[10:03 AM] **Aashu:** [Image] ticket abhi tak available hai

[10:04 AM] **Aashu:** ho gaya hoga tumhara ticket coinfirm

[10:12 AM] **You:** Abhi call Kiya nhi h wo

[10:13 AM] **You:** Dekhte hain

[10:46 AM] **Aashu:** hua ya nhi

[10:46 AM] **You:** Nhii

[10:46 AM] **You:** Sleeper me try kar rahe ab

[10:46 AM] **Aashu:** bataya kya call kr ke

[10:46 AM] **You:** [Audio]

[10:47 AM] **You:** Haa

[12:53 PM] **You:** Hui baat..?

[12:56 PM] **Aashu:** papa tumhare baat kiye hai na papa se

[12:56 PM] **You:** Haa

[12:56 PM] **Aashu:** to phir

[12:57 PM] **Aashu:** hum kya baat kare

[12:57 PM] **You:** Mai kya puch rahi thi

[12:57 PM] **Aashu:** tm comfortable ho to aa jao

[12:57 PM] **You:** Aane ka to aa jayenge

[12:57 PM] **You:** But wahan rahoge to na

[12:57 PM] **You:** Agar nahi rahoge koi fir hum kaise aayenge

[12:57 PM] **You:** Ye confirm karna hai

[1:00 PM] **Aashu:** haa yahi rahenge

[7:27 PM] **You:** Hello

[7:36 PM] **Aashu:** yes

[7:49 PM] **You:** Kya ho raha

[7:49 PM] **Aashu:** call me hai serious

[7:49 PM] **Aashu:** karte hai

[7:50 PM] **You:** Okk

[9:36 PM] **You:** Call kiya tha aaj koi lohra se

[9:57 PM] **Aashu:** [Image]

[9:59 PM] **You:** Ohh

[10:21 PM] **Aashu:** hello

[10:21 PM] **Aashu:** na koi call nahi aaya tha

[10:24 PM] **You:** Accha

[10:24 PM] **You:** Okk

[11:32 PM] **You:** [Image] Iska itna dropping point dikha rha h

[11:33 PM] **Aashu:**
> _You: Image: Iska itna dropping point dikha rha h_
kiska

[11:34 PM] **Aashu:** manish ka na

[11:34 PM] **You:** Haa

[11:34 PM] **Aashu:** hh

[11:34 PM] **You:** Dono bus alag alag route se jata hai

[11:35 PM] **Aashu:** oh ok

---

## June 5, 2026

[9:30 AM] **You:** Good morning

[10:14 AM] **You:** [Image] Agent itna waiting kaat rakha tha chart prepare hone se phle try Kiya confirm karne ka fir bhi nahi hua

[10:45 AM] **Aashu:** gm

[10:49 AM] **Aashu:** aaj bhi nhi hua na ticket

[10:51 AM] **You:** Naa

[11:02 AM] **Aashu:** sleeper me bhi nhi hua

[11:09 AM] **You:** Nhi🥺

[11:54 AM] **Aashu:** [Image] baat kar rahe hai rk se

[11:57 AM] **You:** [Forwarded] [Image]

[8:28 PM] **Aashu:** hello

[8:53 PM] **You:** Yess

[8:53 PM] **Aashu:** kya ho reha

[8:56 PM] **You:** [Video message]

[8:56 PM] **You:** Packing ho raha ummid me ki ticket ho jaye🥺🥺

[8:56 PM] **Aashu:** kab kal

[9:01 PM] **You:** Hmmm kal last try hoga train ka nahi to fir papa bole flight se hi jana

[9:02 PM] **Aashu:** to ye sab saman phir

[9:11 PM] **You:** Currier

[9:50 PM] **You:** Kya kar rhe ho

[10:13 PM] **Aashu:** padh rahe hai bolo

[10:40 PM] **You:** Okk

[10:41 PM] **You:** Padh lo fir

[11:05 PM] **Aashu:** bolo

[11:05 PM] **Aashu:** rk se baat kar rahe the

[11:05 PM] **Aashu:** [Image]

[11:05 PM] **Aashu:** yaar itna jada problem ho reha humko rk se pura clarify karna parta ek ek ghanta

[11:11 PM] **You:** Ohh

[11:11 PM] **You:** Gap ho gaya tha us wajah se kya

[11:11 PM] **Aashu:** hmm 10 din kuch nahi the

[11:12 PM] **Aashu:** aur usme hum miss kar diye warna sab explain kar hi dete

[11:12 PM] **Aashu:** but abhi bhi kar dete hai wo sara jitna ho pata

[11:12 PM] **You:** Abhi kon leta hai kaam

[11:13 PM] **Aashu:**
> _You: Abhi kon leta hai kaam_
mtpb

[11:14 PM] **You:** Abhi jo kaam hota h wo koi to dekh rha hoga na jaise rk dekhta tha

[11:14 PM] **Aashu:**
> _You: Abhi jo kaam hota h wo koi to dekh rha hoga na jaise rk dekhta tha_
hum hi dekh rahe

[11:15 PM] **You:** Accha Aisa

[11:16 PM] **Aashu:** hmm

[11:16 PM] **You:** Kon n kuch din abhi starting me hoga

[11:16 PM] **You:** Fir normal ho jayega

[11:17 PM] **Aashu:** hh aise rk august me wapas aa jayenge

[11:17 PM] **Aashu:** mostly

[11:18 PM] **Aashu:** abhi shayad tumhari bari mummy call ki thi lekin hum rk ke sath call me the to baat nahi hua

[11:18 PM] **Aashu:** kal call karte hai unse

[11:22 PM] **You:** Ohh accha

[11:22 PM] **You:** Kab ki thi

[11:23 PM] **Aashu:** 10:30 ke asspass

[11:23 PM] **You:** Oo

[11:23 PM] **You:** Kya bologe

[11:23 PM] **You:** Bhaiya kiya tha ki badi mummy

[11:23 PM] **Aashu:** bol denge ki accha try karte hai

[11:24 PM] **Aashu:**
> _You: Bhaiya kiya tha ki badi mummy_
rani devi se aaya tha

[11:25 PM] **You:** Accha

[11:26 PM] **You:** 9852581941

[11:26 PM] **You:** Ye no Tha

[11:27 PM] **Aashu:** hmm

[11:27 PM] **You:** Haa fir wahi h

[11:28 PM] **Aashu:** hmm

[11:30 PM] **You:** Or

[11:31 PM] **You:** Taiyari kar rakhe ho

[11:31 PM] **You:** Mummy papa ke welcome ke

[11:32 PM] **Aashu:** haa aaj soyenge nhi

[11:32 PM] **Aashu:** padhenge hi

[11:32 PM] **Aashu:** morning me bartan dho denge aur jharu laga denge phir station chal jayenge

[11:33 PM] **You:** Soyenge nhi to fir

[11:33 PM] **You:** Kal jagoge kaise

[11:33 PM] **You:** So Jana

[11:33 PM] **You:** Kal wo log aayenge to sote rahoge

[11:34 PM] **Aashu:**
> _You: Kal jagoge kaise_
wo to chal jayenge

[11:34 PM] **You:** Pura din fir

[11:34 PM] **You:** Bedsheet aaya

[11:34 PM] **Aashu:**
> _You: Bedsheet aaya_
hh

[11:35 PM] **You:** Sahi h

[11:35 PM] **You:** Khana pina

[11:37 PM] **You:** Kya soche ho

[11:37 PM] **Aashu:** kab aaj

[11:38 PM] **You:** Haa or kal ke liye bhi

[11:38 PM] **Aashu:** kal to mummy aa jayegi

[11:38 PM] **Aashu:** phir kya problem hai

[11:39 PM] **Aashu:** dal chawal chips ye sab to ban hi kayega

[11:39 PM] **You:** Cooker hai jo dal banega

[11:39 PM] **Aashu:** kyu bhai

[11:39 PM] **Aashu:** gas khatam thori hua hai

[11:39 PM] **Aashu:** cooker kal aa jayega

[11:41 PM] **You:** Accha

[11:42 PM] **You:** Badhiya hai

[11:42 PM] **Aashu:** hmm

[11:51 PM] **You:** Ok

[11:51 PM] **Aashu:** chalo tm so jao

[11:51 PM] **Aashu:** good night

[11:52 PM] **You:** Hmm soyenge thodi der me

[11:53 PM] **Aashu:** ok

[11:54 PM] **You:** Anniversary gift kuch soche ho

[11:55 PM] **Aashu:** no

[11:56 PM] **You:** Socho na

---

## June 6, 2026

[12:19 AM] **Aashu:** ok

[7:49 AM] **You:** Good morning

[7:49 AM] **You:** Aa gaye mummy papa

[8:03 AM] **Aashu:** hh

[8:03 AM] **Aashu:** gm

[8:05 AM] **You:** So rhe ho kya

[8:27 AM] **Aashu:** nhi kyu

[8:47 AM] **You:** Jage ho na puri night

[8:47 AM] **Aashu:** [Video]

[8:48 AM] **You:** He bhagwan yahi chal raha hai kya 😂😂😂

[8:49 AM] **Aashu:**
> _You: He bhagwan yahi chal raha hai kya 😂😂😂_
haa

[8:50 AM] **Aashu:** suno

[8:50 AM] **Aashu:** [Forwarded] https://youtu.be/wxBXDzPZ9aU?si=K1dI3fHNVbSoZoQM

[8:50 AM] **Aashu:** [Forwarded] https://youtu.be/EEOTq93363g?si=fATPJzlN8t3wt8L_

[8:50 AM] **Aashu:** tmko ye dono link beje hai

[8:50 AM] **Aashu:** tm kisi ko mat bejna samji

[8:51 AM] **Aashu:** ye youtube pe daal diya hai

[8:51 AM] **Aashu:** isko delete karwqyenge

[8:52 AM] **You:** Abhi mat delete karana

[8:52 AM] **You:** Rahne do na

[8:52 AM] **You:** Mummy dekhegi meri

[8:52 AM] **Aashu:** kahe bhai

[8:52 AM] **Aashu:** youtube par pura duniya kahe dekhega

[8:52 AM] **Aashu:** are mummy phir sab ko bej degi

[8:54 AM] **You:** Nahi bhejegi

[8:54 AM] **You:** Mana karenge hum

[8:54 AM] **Aashu:** okk

[8:54 AM] **Aashu:** aaj kl me dekh lo

[9:12 AM] **Aashu:** sahi hai tmko timepass mil gaya na

[9:28 AM] **You:** Mummy ko mil gya h

[9:43 AM] **Aashu:** hmm

[9:54 AM] **You:** Hasi nhi aa rahi dekh kr 😂😂😂

[10:15 AM] **Aashu:** hasi kya aayega

[10:15 AM] **Aashu:** tumhara ticket hua aaj

[10:18 AM] **You:** Noo

[10:23 AM] **Aashu:** ohh

[10:23 AM] **Aashu:** ok

[12:13 PM] **You:** _You deleted this message_

[12:20 PM] **You:** [Document] E-Ticket_NF7ALO6P63285515506.pdf

[12:26 PM] **Aashu:** kar li ticket

[12:35 PM] **You:** Hmmm

[12:35 PM] **You:** Dekho na

[12:36 PM] **Aashu:** hh dekhe

[12:36 PM] **Aashu:** nice

[12:37 PM] **Aashu:** to saman jada mat lana warna fine lag jayega

[12:43 PM] **You:** Haa ab kuch nhi lenge

[12:43 PM] **You:** Frame bhi chhod de rahe

[12:45 PM] **Aashu:**
> _You: Frame bhi chhod de rahe_
hmm chorna hi parega

[12:49 PM] **Aashu:** jab flight kar li ho to wo train ka ticket cancel karwa lena

[12:49 PM] **Aashu:** kyuki kahi galti se bhi wo coinfirm na ho jaye

[1:39 PM] **You:** [Image]

[3:35 PM] **Aashu:** courier dekh kar karna

[3:36 PM] **Aashu:** aisa time me na aaye ki humlog us time nhi rahe

[3:50 PM] **Aashu:** hello

[3:50 PM] **Aashu:** kal tm tirupati ja payegi ki nahi

[3:56 PM] **You:**
> _Aashu: aisa time me na aaye ki humlog us time nhi rahe_
Kar diye hain ab

[3:56 PM] **You:**
> _Aashu: kal tm tirupati ja payegi ki nahi_
Kal kitne baje

[3:56 PM] **Aashu:**
> _You: Kar diye hain ab_
yaar to ye sochna chaiye na ab kya bole hum

[3:56 PM] **Aashu:**
> _You: Kal kitne baje_
kal raat me 8 baje

[3:57 PM] **You:**
> _Aashu: kal raat me 8 baje_
Fir chutti milega kaise jaaoge

[3:57 PM] **Aashu:** hum nahi jayenge

[3:58 PM] **Aashu:** mummy papa jaa rahe

[3:58 PM] **Aashu:** to tm jayegi ya nahi wohi puch rahe

[4:01 PM] **You:** Mera continue ho jayega na

[4:02 PM] **You:** 4 baj jayega mujhe to pahuchne me hi

[5:18 PM] **Aashu:** haa monday ko jayegi na

[5:24 PM] **You:** Monday ja skte h

[5:30 PM] **Aashu:** okk thik hai

[5:30 PM] **Aashu:** ticket kar de na tumhara phir

[6:39 PM] **You:** Rameshwaram se aane ke baad nahi jate

[6:40 PM] **Aashu:** nahi phir time nahi milega

[6:42 PM] **You:** Mummy kya kar Rahi hai abhi

[6:46 PM] **Aashu:** super market gayi hai lyu

[6:46 PM] **Aashu:** kyu

[6:47 PM] **You:** Akele gayi h

[6:47 PM] **Aashu:** nahi

[6:47 PM] **Aashu:** papa bhi

[6:47 PM] **You:** Kya lene

[6:47 PM] **Aashu:** aise hi kuch kuch saman lene

[7:16 PM] **You:**
> _Aashu: ticket kar de na tumhara phir_
Hmm kar dena

[7:27 PM] **Aashu:** hmm accha

[8:54 PM] **Aashu:** hello

[8:55 PM] **Aashu:** monday raat ka tirupati ka ticket kar diye hai aapka

[8:56 PM] **You:** Accha

[8:56 PM] **You:** Bahut bahut shukriya aapka 🙏🙏

[9:02 PM] **Aashu:** aaye aaye sab koi excited hai pura

[9:02 PM] **Aashu:** swati rani kal aa rahi hai

[9:31 PM] **You:** Hayyyyy😊😊😊

[9:31 PM] **You:** Koi jal raha hai kya

[9:31 PM] **You:** 🫣🫣

[9:34 PM] **Aashu:**
> _You: Koi jal raha hai kya_
na jalenge kya

[9:34 PM] **Aashu:** aao aao

[11:11 PM] **You:** Hmmm

[11:11 PM] **You:** Abhi ghar aaye hain

[11:12 PM] **Aashu:** ok aaram karo

[11:41 PM] **You:** 5 baje hi uthna h

[11:41 PM] **Aashu:** aur jldi hi uthna

[11:42 PM] **You:** Papa hain 4 baje hi uthe denge

[11:42 PM] **Aashu:**
> _You: Papa hain 4 baje hi uthe denge_
kk good

[11:43 PM] **You:** Hmm

[11:43 PM] **Aashu:** so jao phir

[11:43 PM] **Aashu:** good night

[11:43 PM] **Aashu:** aadhar card rakh lena

[11:43 PM] **Aashu:** bro

[11:43 PM] **You:** Haa soyenge papa nhi aaye hain abhi tak

[11:44 PM] **Aashu:**
> _You: Haa soyenge papa nhi aaye hain abhi tak_
oh

[11:44 PM] **You:**
> _Aashu: aadhar card rakh lena_
Rakh liye hain

[11:44 PM] **Aashu:** okk

[11:44 PM] **Aashu:** good girl

[11:45 PM] **You:** Haa sab so gye

[11:45 PM] **Aashu:** hh

[11:46 PM] **You:** Kahan soye ho

[11:46 PM] **Aashu:** apne room me hum aur mummy

[11:47 PM] **You:** Accha

[11:47 PM] **Aashu:** hmm

[11:53 PM] **You:** _You deleted this message_

---

## June 7, 2026

[7:19 AM] **Aashu:** good morning

[7:20 AM] **Aashu:** kya delete ki

[7:21 AM] **You:** Raat ka message tha

[7:22 AM] **Aashu:** kya

[7:23 AM] **You:** [Image]

[7:23 AM] **Aashu:** wahh

[7:23 AM] **Aashu:** tez ho gayi hai

[7:23 AM] **Aashu:** aao aao

[7:24 AM] **Aashu:** happy journey

[7:24 AM] **You:** Hmm hmm wo to phle se hi the but dikhta nahi wo alag baat hai

[7:24 AM] **You:** 🫣🫣

[7:24 AM] **You:** Ticket bhi hum khud hi Kate hain

[7:28 AM] **Aashu:**
> _You: Ticket bhi hum khud hi Kate hain_
wahh

[7:28 AM] **Aashu:** badiya

[7:28 AM] **Aashu:** tm boli papa katwaye

[7:29 AM] **Aashu:**
> _You: Hmm hmm wo to phle se hi the but dikhta nahi wo alag baat hai_
😆😆 choro ispe kya bole rahne do

[7:29 AM] **You:** Bol raha tha wo agent flight ka ticket kaat dete hain mai boli khud kar lungi mai faltu me wo commission lega

[7:30 AM] **Aashu:** hmm okok

[7:30 AM] **You:**
> _Aashu: 😆😆 choro ispe kya bole rahne do_
Paise mujhe papa de diye hain jyda hasna kyu aa raha h ispe

[7:30 AM] **Aashu:** kuch nhiq

[7:30 AM] **Aashu:** kya khayi ho

[7:30 AM] **You:** Thik h has lo

[7:30 AM] **You:** Bye

[7:31 AM] **Aashu:** are gussa kahe kar rahi

[7:31 AM] **Aashu:** pura excited hona aaj mere se milne ke liye

[7:35 AM] **Aashu:** ab kaha chal gayi bhai

[7:36 AM] **You:**
> _Aashu: pura excited hona aaj mere se milne ke liye_
Aane se phle gussa dila rahe ho

[7:37 AM] **You:** [Image]

[7:37 AM] **Aashu:** accha

[7:39 AM] **Aashu:**
> _You: Image_
wahh mast

[7:49 AM] **Aashu:** kuch khayi ho

[7:49 AM] **You:** Haa aam kha ke chale hain last last me mummy khila hi di

[7:50 AM] **Aashu:**
> _You: Haa aam kha ke chale hain last last me mummy khila hi di_
good

[7:50 AM] **You:** Or chocolate shake de di thi yarr jabardasti leak kar gaya fek diye sara

[7:51 AM] **Aashu:** hmm ok

[7:51 AM] **Aashu:** koi nhi

[7:51 AM] **Aashu:** liquid cheez me thora problem hai hi

[7:51 AM] **You:** Huu

[7:52 AM] **You:** Chammach bhi tha usme ghar ka wo bhi frk diye😜

[7:52 AM] **Aashu:** accha koi nhi

[7:54 AM] **You:** [Image] Krishna bhai gadi bhej diya apna isi se aaye the

[7:55 AM] **You:** Masst gadi hai

[8:02 AM] **Aashu:**
> _You: Image: Krishna bhai gadi bhej diya apna isi se aaye the_
are wahh mast

[8:02 AM] **Aashu:** pura mazza aa reha tmko na

[8:12 AM] **You:** Haa maza to kar ke aa rahe hain

[8:12 AM] **You:** Baith gaye flight me

[8:13 AM] **You:** Sabse last ka seat diya hai ☹️

[8:13 AM] **Aashu:** jaa koi nahi hota hai

[9:48 AM] **You:** Reached mumbai

[9:48 AM] **Aashu:** yeah i know

[9:49 AM] **Aashu:** saw your snap just now

[9:49 AM] **You:** Ohh

[9:50 AM] **Aashu:** mumbai ghum lo

[9:50 AM] **You:** Haa 2 gahnte me hi na

[9:51 AM] **You:** Kahne ko ho jayega Mumbai ghume hue hain 😅

[9:51 AM] **Aashu:** yess

[9:53 AM] **You:** Mere welcome ka kya arrangement hai 😄😄

[9:54 AM] **Aashu:** ye sab kya hota hai

[9:54 AM] **You:** Ohh ye nahi pata

[9:55 AM] **You:** Itne knowledgeable person ko ye nahi nahi pata

[9:55 AM] **You:** Ohhh

[9:55 AM] **Aashu:**
> _You: Itne knowledgeable person ko ye nahi nahi pata_
niche tent lagwa diye hai

[9:55 AM] **Aashu:** boj hai aaj sab ko

[9:55 AM] **Aashu:** 20kg mutton banwa rahe

[9:56 AM] **You:** 20kg me kya hoga mera

[9:59 AM] **Aashu:**
> _You: 20kg me kya hoga mera_
accha

[10:14 AM] __[Call]__

[10:18 AM] __[Call]__

[11:04 AM] **You:** Kya gazab airport h Mumbai ka

[11:05 AM] **Aashu:**
> _You: Kya gazab airport h Mumbai ka_
are tm banglore ka terminal 2 nahi gayi ho

[11:05 AM] **Aashu:** are are bro

[11:06 AM] **Aashu:** tumhara banglore me terminal 2 pe aa reha aaj

[11:06 AM] **Aashu:** chalo tmko chance mil gaya terminal 2 ka

[11:06 AM] **Aashu:** wo dekhna kitna bhayanak hai pura bamboo se bana hai video bana lena pura accha se

[11:12 AM] **You:** Hahahaha 😂

[11:14 AM] **Aashu:**
> _You: Hahahaha 😂_
sahi me majak nhi

[11:16 AM] **You:** Accha Okok

[11:50 AM] **You:** [album message]

[11:50 AM] **You:** [Image]

[11:50 AM] **You:** [Image]

[11:50 AM] **You:** Dekho anniversary special 😍

[11:50 AM] **Aashu:** wahh bhai

[11:50 AM] **Aashu:** gajab

[11:51 AM] **You:** [Image]

[11:53 AM] **Aashu:**
> _You: Image_
kaha hai ye log abhi

[11:54 AM] **You:** Mausa masi abhi gaye hue hain delhi

[11:54 AM] **Aashu:** accha

[11:54 AM] **Aashu:** enjoy

[11:55 AM] **Aashu:** tumhara to pura ghumna ho jaa reha

[11:55 AM] **Aashu:** abhi terminal 2 bhi ghumegi usme tmko ek ghanta lg jayega

[11:56 AM] **You:** Naa

[11:56 AM] **You:** Utna nahi ghumenge

[11:57 AM] **You:** Exit kar jayenge

[11:57 AM] **Aashu:** okok

[11:57 AM] **Aashu:**
> _You: Exit kar jayenge_
accha

[12:06 PM] **You:** Haa

[12:06 PM] **Aashu:** baith gayi

[12:06 PM] **Aashu:** ab to wapas urna hai

[12:06 PM] **You:** Haaa

[12:06 PM] **Aashu:** tumhara hi sahi hai pura ghumte ghumte aa rahi

[12:06 PM] **You:** Udenge ab

[12:07 PM] **You:** Chilling mode activated 😎

[12:07 PM] **Aashu:**
> _You: Chilling mode activated 😎_
hmm hmm

[12:07 PM] **Aashu:** pura khus ho kya baat hai

[12:08 PM] **Aashu:** tm aa rahi to mummy kuch status nhi lagayi

[12:08 PM] **You:** Mana kar ke aaye hain

[12:08 PM] **You:** Gahr me abhi sabko nahi batana hai na ki hum wapas aa gaye

[12:08 PM] **Aashu:**
> _You: Mana kar ke aaye hain_
humko lag hi reha

[12:08 PM] **You:** Sab dekhega to mummy se hi puchega na

[12:08 PM] **Aashu:**
> _You: Gahr me abhi sabko nahi batana hai na ki hum wapas aa gaye_
ohh ok

[12:08 PM] **Aashu:** to snap jo bej rahi

[12:09 PM] **You:** Naa selected log ko hi

[12:09 PM] **Aashu:** okk

[12:09 PM] **You:** Baat hua tha badi mummy se

[12:09 PM] **Aashu:** pura teen panch kar rahi

[12:09 PM] **Aashu:**
> _You: Baat hua tha badi mummy se_
kya boli wo

[12:09 PM] **You:** Puch rahi hu mai aapki baat hui thi

[12:10 PM] **Aashu:**
> _You: Puch rahi hu mai aapki baat hui thi_
mera nhi hua na

[12:10 PM] **You:** Ohh

[12:10 PM] **Aashu:** hum busy the jab wo call ki thi

[12:10 PM] **You:** Ok

[12:10 PM] **Aashu:** hh

[12:10 PM] **Aashu:** tmko kya boli

[12:11 PM] **You:** Mere se baat nahi hua hai

[12:11 PM] **You:** Fua priyanka di ye log puch rhi thi kab aa rahi

[12:11 PM] **Aashu:** o

[12:11 PM] **You:** Mai boli mummy ke sath but mera ticket nahi h hoga tab aayega

[12:11 PM] **You:** Aayenge

[12:12 PM] **Aashu:** accha aisa 😆

[12:12 PM] **You:** Monu bhaiya Sonu Bhaiya sab puch rha tha

[12:13 PM] **You:** Sab ko kuch kuch idea ho gaya hai ki hum nahi jayenge

[12:13 PM] **Aashu:**
> _You: Sab ko kuch kuch idea ho gaya hai ki hum nahi jayenge_
kaise

[12:13 PM] **Aashu:**
> _You: Monu bhaiya Sonu Bhaiya sab puch rha tha_
ohh

[12:13 PM] **You:** [Image]

[12:15 PM] **Aashu:**
> _You: Image_
ye kon fhua wale hai

[12:15 PM] **You:** Haa

[12:15 PM] **Aashu:** jao bhai tumhare bina kaam kaise hoga

[12:15 PM] **Aashu:** lava kon bujenga

[12:16 PM] **You:** Hai na

[12:16 PM] **You:** Manisha di priyanka di

[12:17 PM] **Aashu:** jana chaiye lekin

[12:17 PM] **You:**
> _Aashu: jana chaiye lekin_
Ab bolo mat

[12:17 PM] **Aashu:** tumhare shadi me itna sab koi aaya tha

[12:17 PM] **You:** Bahut mushkil se khud ko manipulate kiye hain

[12:17 PM] **Aashu:** nhi gayi tm wo tumhara perspective hai

[12:17 PM] **Aashu:** lekin humko to laga tha ki jayegi

[12:17 PM] **You:**
> _Aashu: nhi gayi tm wo tumhara perspective hai_
Bhaiya nhi aaya tha

[12:18 PM] **Aashu:**
> _You: Bhaiya nhi aaya tha_
yaar use competition nhi hai na tumhara

[12:18 PM] **Aashu:** unka to sach me promotion ka tha

[12:18 PM] **Aashu:** but tumhara waisa kuch thori tha

[12:18 PM] **You:** Mera apna issue tha

[12:19 PM] **Aashu:** aur shadi ek baar hi hota aur mostly isi bahane sab koi ek dusre se milte mazza aata

[12:19 PM] **Aashu:**
> _You: Mera apna issue tha_
kon sa issue

[12:19 PM] **You:**
> _Aashu: aur shadi ek baar hi hota aur mostly isi bahane sab koi ek dusre se milte mazza aata_
Yaar ab mat bolo ye sun sun ke hi mai kitna manage ki hu khud ko

[12:19 PM] **You:** Mummy continue bol rhi thi jab se gaye the

[12:19 PM] **You:** Papa bhi bole

[12:20 PM] **You:** Fua bhi boli h

[12:20 PM] **Aashu:**
> _You: Yaar ab mat bolo ye sun sun ke hi mai kitna manage ki hu khud ko_
hh okk nhi gayi isme tumhara hi loss hai mereko thori koi wo hai

[12:20 PM] **You:** Hmm ok

[12:20 PM] **Aashu:** ab ankit ke shadi se pehle thori log sab ek sath hoenge

[12:20 PM] **You:** Usse phle maybe shivam ka ho jaye

[12:21 PM] **Aashu:** isme lohra me itna log sab bhai behan rehta to jada mazza aata

[12:21 PM] **Aashu:**
> _You: Usse phle maybe shivam ka ho jaye_
accha hh uska hoga

[12:21 PM] **You:**
> _Aashu: accha hh uska hoga_
Hmm uncle papa se puch rhe the shadi ke liye kya kare

[12:22 PM] **Aashu:**
> _You: Hmm uncle papa se puch rhe the shadi ke liye kya kare_
shadi to karna hi hai na

[12:22 PM] **Aashu:** isme puchna kya

[12:22 PM] **You:** Means abhi age ke according time hai itna bhi nahi hua hai

[12:22 PM] **Aashu:** tm nhi gayi to priyanka di manisha di zindgi bhar bolegi

[12:22 PM] **You:**
> _Aashu: tm nhi gayi to priyanka di manisha di zindgi bhar bolegi_
Bolegi to jaroor

[12:23 PM] **Aashu:**
> _You: Means abhi age ke according time hai itna bhi nahi hua hai_
hh ho hi gaya hai

[12:23 PM] **You:** Wo bhi bahut jyada bolegi

[12:23 PM] **You:** Like tana bhar bhar ke degi

[12:23 PM] **Aashu:**
> _You: Bolegi to jaroor_
wohi jaisa unka nature hai aur jaisa tone hai unlog ka

[12:23 PM] **You:** Mummy ko bhi

[12:23 PM] **Aashu:**
> _You: Like tana bhar bhar ke degi_
hh

[12:23 PM] **Aashu:** mummy bechari ko tm fasha di

[12:23 PM] **Aashu:** galat ki

[12:24 PM] **You:** Chlo by ab fly kar rahe ab nahi sunna mujhe

[12:24 PM] **You:** TATA

[12:24 PM] **Aashu:** okk aao phir samne baith kar

[12:24 PM] **Aashu:** sunayenge

[12:24 PM] **Aashu:** happy journey

[12:24 PM] **Aashu:** aa jao ab jldi

[12:24 PM] **You:**
> _Aashu: aa jao ab jldi_
Kyu raha nhi ja Raha 🫣🫣

[12:25 PM] **You:** Mere bina

[12:25 PM] **Aashu:** ab aa rahi ho to thora excitment rahega

[12:25 PM] **You:** Accha

[12:25 PM] **You:** Aisa kya

[12:25 PM] **You:** Ye sab feeling hoti h

[12:26 PM] **Aashu:** ph flight mode me daal do

[12:26 PM] **Aashu:** warna blast kar jayega

[12:26 PM] **You:** Jab tak chal raha chala lete hain

[12:26 PM] **Aashu:**
> _You: Jab tak chal raha chala lete hain_
blast karega tab samaj aayega

[12:26 PM] **You:** Ohhhh

[12:26 PM] **You:** Fir aag lag jayega

[12:31 PM] **You:** [Video] Jaa dhunaa ho gaya

[12:31 PM] **You:** 😜😜

[12:32 PM] **Aashu:**
> _You: Video: Jaa dhunaa ho gaya_
kisi ka blast kiya kxa

[12:33 PM] **You:** Haa mer hi😂

[12:33 PM] **Aashu:** humko bhi fashayegi

[12:33 PM] **Aashu:** chalo band karo net

[12:34 PM] **You:** Fasne ka dar hai mere marne se jyada waah. Bhai waah

[12:35 PM] **You:** Abhi depart hua nahi h

[12:35 PM] **You:** Run way pe h

[12:35 PM] **Aashu:** jada late ho reha

[12:35 PM] **You:** 1 hour 35 minutes lega

[12:36 PM] **You:** Wo wala flight before 15 minutes hi land ho gaya

[12:39 PM] **Aashu:**
> _You: Wo wala flight before 15 minutes hi land ho gaya_
aaye

[1:06 PM] **Aashu:** [Image] tumhara flight ko pura track kar rahe 50 min aur dikha reha

[1:53 PM] **You:** Aa gaye lo

[2:02 PM] **Aashu:** yes

[2:02 PM] **Aashu:** skandiri aapartment dalna

[2:02 PM] **Aashu:** konadaspura

[2:03 PM] **Aashu:** apna live location bejo to for next 2 hours

[2:04 PM] **Aashu:** aao jldi mutton bana hai

[2:04 PM] **You:**
> _Aashu: skandiri aapartment dalna_
I already have an idea

[2:04 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAECAwQGBwUI/8QAQBAAAQMCAwMHCAUNAAAAAAAAAQACAwQRBQYhEjFBBxMUUVNhcSIyNFJykaGxgYKSwdEVFyMzQkNWYpWi0vDx/8QAGgEAAwADAQAAAAAAAAAAAAAAAAECAwQFBv/EACkRAAIBAwQABAcBAAAAAAAAAAABAgMEEQUSITEUIkFhBhMyUYGRsdH/2gAMAwEAAhEDEQA/APozmYuyZ9kJzMXZM+yFcRbBiLRgiP7tnuTo8PZt9yuogC10eHs2+5R0aHs2q8iALPRoezCdGh7MK8iALPRYfU+JVyCngLth7Nd4NzqqlBFxobHgepAF7oVP2f8AcU6HB6rvtu/FVRThxa14IefcVeUlcFuOCONtmg236klFcRAzCREVEBERABazmzOWHZcIhlD6mtcNoU8VrgcC4nRo+PctmXzBieIS1s1TiNSS+adxmd4ncPAaDwC0r25dCK29s7mh6ZC/qSdV+WPfvk6hS8rEZmaKvB3xw8XRVAkcPqlrfmuh4TiVJi1DHWYfM2ank3OGljxBG8HuK+V6OvkkqAyQNs7dbguq8i9bKzG66gDj0eWnM5b1Pa5rbjxD9fALVtb2pKoqdTnJ1dW0S2hbO4tuNva+/wCzr6Ii6544i9nNd1OCzlgPF2O8FnMO00OHEXSZSJRESGYSKkXJAAJJ4AK8aecC+wbI3CwWhxUlU6990170ZDBIFhxPivnrOeX5Mv41NSPYehylz6Z/B0ZPm+Lb2P0HivoMk8N68jNWX4MwYNNRzENm8+Ga2scg3Hw4EdRK1bu38RDjtdHW0fUXp9fMvplw/wDfwfOENJDC/bY3yuFzuXYOR/AZaannxmqYWOqWCOnadDzd7l31iBbuF+K07IOW3Y3mN9NXxObT0JLquM8XBxAjPiQb9zSu8tAa0BoAA0AHBaWnWzb+bP06O58R6nGMPB0fXl/1IlERdk8WFk03o8fshYyyab0eP2QkxouIiJFHG+V/O9bhlb+QcFndTSMYHVk8Zs8lwuGNP7IAIJtr8b8zxWgxnAcRp55pZmz1LBNBVwykiZpAIc1437x3r3s7SGHlaxF8kNNOBVDaiqyGxvbsjRxdoBbjw0IXuz5sx6KiiosEly3hVHACIWxVcUj2Am58p7jrv1AG9ZE8YwjXfmbyzZuSfOVVmCnqsNxh/OYnRs51kxADpYwbEO6yL7/vuTumK4pTYWIDVMqnNmc1jXQwOkG052y1txxJt71xbkZlnn5QqmaokMsz6ed8sl77ROpJI33PFdkxSkmrqGhbAGudHWUs7ruAsxkrXOOvUAVM+M4MlN5XJ6UTTI2Mta5pkbtBjxsvt3tOoQBpAIcwg7vLGu78R71rFRl+oqM6vxGV074X1FPPBNFJA0QMja0OjcXMMli4PNmGxEhB2dSvMhyWW5dw6kdhtCZ4MvS0jhaPSsc2LW/WS0+V3b1iz7GTBttHhlBhtTVVFLTiOauqGiZ0QLy+Q6Xd1Aa38SeKz2t2r7Ba62/ZINlqzctS02NxS0FLTwUd8PkkEbmtBkidPzriOJ2XRa8foXnU2VK2hwmlZR0FE2oOFmmqmks/SSGaJxB4OOyJLbV230OhKaljhIcsyeZPJuT6uGOspaVxcZamOSSMtALbM2b3N/5x8VYGLUJxHoQmeZud5jaEL+b53Z2ub27bO1bhfu36LwMsZfrsPxCGaaJsVLHJWOYwvi2mNlbARpGA0EuZISGi1/G69eZtZUZliNVh9ScPpXg0745IebdI5tjNIC8O8m5AAB4nUkWe54FhHrLJp/R4vZHyWMsmn9Hi9kfJUyUXEREijmueMoYXmaoZVVtRPhuJtaI3zshMrJgNxLRY37/notU/NVhv8Uv/AKXJ/kuyFodvAPio5tnqN9yFOS6ZLpxfLRqOSss4blulnjwqSarq6puxNWSs5sBnqtbvA/2+5bk0BrQOoKkAAaADwRLcx7USN+imx61Dd6qTiDCIiokIiIALJp/R4vZHyWI/UbI3u0CzwLAAbgkxoIiJFHnopsUsVOGGSEU2KhAwP1g8D9yruqQASpsOpUuiWSiIqJCIiAI1Dmub5zdQsyN4kYHN/wCLEUseYn7Q80+cPvQ0NGYiAggEG4KKSjCREVEA7lQiKJFolu9VIiqPRL7CIiYgiIgAiIgCkxtO8IiIA//Z: Live location: 13.199928, 77.7200501 — https://maps.google.com/?q=13.199928,77.7200501

[2:04 PM] **Aashu:** puea welcome hoga acche se

[2:04 PM] **Aashu:** kaisa hsi terminal 2

[2:04 PM] **Aashu:** snsp nhi aaya

[2:04 PM] **You:** Abhi flight me hi hai

[2:05 PM] **Aashu:** tumhari bari mummy ph ki thi

[2:05 PM] **Aashu:** baat hua

[2:05 PM] **You:** Accha

[2:05 PM] **Aashu:** boli swati hai na

[2:05 PM] **You:** Kya boli

[2:05 PM] **Aashu:** bole haa wo to rajkot me haj mummy pass

[2:05 PM] **Aashu:** humko bhi boli hai

[2:05 PM] **Aashu:** hum bole hh aayenge

[2:05 PM] **Aashu:** tumhara bol diye ki wo mummy ke sath hi jayegi shayad

[2:44 PM] **You:** Ok

[2:45 PM] **Aashu:** cab par baith kar msg karna

[2:46 PM] **You:** Baith gYe

[2:46 PM] **Aashu:** wahh

[2:46 PM] **Aashu:** kise uber

[2:47 PM] **Aashu:** ya local wala tmko buddhu bana diya

[2:47 PM] **You:** Rapido

[2:47 PM] **Aashu:**
> _You: Rapido_
okk

[2:47 PM] **Aashu:** phir to kam laga hoga 600 ke approx

[2:47 PM] **You:** Mai buddhu banungi kya

[2:47 PM] **You:** Hmmm

[2:47 PM] **You:** 585

[2:47 PM] **Aashu:** nahi wo to nahi banegi

[2:47 PM] **Aashu:**
> _You: 585_
wahh gajab

[2:48 PM] **Aashu:** airport kaisa laga

[2:50 PM] **You:** Thik hai jyda ghume nhi

[2:50 PM] **You:** Direct exit

[2:50 PM] **Aashu:** ohh

[2:51 PM] **Aashu:** but accha hai

[2:51 PM] **Aashu:** hum ghume hai 2 baar

[2:51 PM] **You:** Accha

[2:51 PM] **You:** Bag leke kaha hi ghumte

[2:54 PM] **Aashu:** haa wo to hai

[2:55 PM] **You:** Uber abhi bahut mahanga dikha raha tha

[2:55 PM] **You:** 1k almost

[2:55 PM] **Aashu:** accha

[2:56 PM] **Aashu:** 3:30 tak aa jayegi

[2:56 PM] **Aashu:** aayegi niche to call karna

[2:57 PM] **You:** Location hai n

[2:57 PM] **You:** Dekhte raho

[2:57 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAIDBAUGBwEI/8QAORAAAgEDAgMFBQYFBQEAAAAAAQIDAAQRBSEGEjETIkFRYRRCcZGhBxUjMoGxYnKSwdElM1KC4aL/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/8QAKREAAgECAwcEAwAAAAAAAAAAAAECAxEEBTESEyEiQVFhBhQy0UJx8P/aAAwDAQACEQMRAD8A+luSUdJVPxT/ANqEAYXEvMVJ5VHdGPOpFHAJMz7DwC/4qlBKiPLzs/UDLrjwHpTAu6VTWWN/yyKfgaqUhiouMipUpNXAo0r1hg15VJIUpSgBSlKAFKUoAqqeZQR41bxGTvuiqysxO5wfL+1QkNsEYhED42BXlJNE5YkUCSSIgY742+v+a0WK7lVmU/70Df0837UieBcrGyKT7vT6V7G8hxkI6n3lP9v/AGpXCdpEyADfbfy8aBlStL4t+0HTdAuWs4onvr5PzxxsFWM+TN4H0APris/xDJ93aBqd7bryy21tLMoBIGVQkZH6V8xXtw8UTzOTJKxyWY5LMTuSaxYvESpWjDVnfyTLKeNcqlb4x6dzsNh9rVtLcKuo6VLawnbtIpu25fUjlU4+GT6V0a0uYby1iuLWVJYJVDI6HIYGvk7T7155THIB0yCK7T9iF7NJZ6rYuxMNu8csYPu8/NkD0ymfiTWahiJynsTNub5RQo0PcYfglqjptKUrceWFKUoAUpSgDRtc4zka8aHS1jNtHkGVhntG8CP4QfnVinGmsqdzZv8AzQt/ZhVPg7Qk1e9eS6Umxt8cy+Ej9QvwA3PxFbw/DWknZLCBEYcr8g5cjy29cfKulJ04ctjHFVJ81zW9O40hL/6xapAvjcW5OF/mHXHqCaz1jxToFxE0sOu2TRqMkSTqpUeZBwcetahxzwultZG708o0cU8SexSgsJyWULHnqeYsAQfnjIq5veFeXVhZ3HFVwly0T3KJJbM3ZxqdyH5goxkdMfCs1eaVt3G/95Jxc46q5skvEPDerafd27axYNBJG0UoNwqnlYYJ3PQg7HpXztfW8UV1c2YniukiYoJYmysi+DA+RGDXVG0q1bRrvVJ+L7xbS0CtIbiykV1DYKkKzc3eyMEDf51j+OOFltrwW19qEs18lk89ncPGc3LBstETk4CgDGT1kJztiudiKU66+LTX6O9keaPB1tmouSWvjz9nMYLaK25mQY23JPhXefsq4em0XQ5Li9Qx3l8wkaNtiiAdxSPPck+XNjwrSPsh0CDWdXk1C75XtrLlaOM+/KdwSPJRg/EjyrtzDc1ThKDS3sjq+ocxTfs6Wi1+iNK9rytx5UUpSgBSlKALDRLH7osYbKKHmRfzShhlmPVjWTLqGClgGPQZ3rH2Oq2eqRQLZTNJ7Tai5jk5cAqTy/oc+HhVnbcSaVJoN/q9sJTZ2XaCYrGA3cAOQM7gghh5gitLd+LK1w4I94ntLmayE1nEZp7W6hu0iBAMgQjmUZ8SvNj1xWP1bXdD1C7t7i7vLizSO2uLd4p7SWN/xQmT3lGMch+dbQLiI6lJYgt26RLOcju8rMwG/n3TWKteJtMuuHZtbgeZ7GEkN3MPsQBsT0IIYehBpDNFubXQL3TruO44pjkvJrZYVksoeaLAgMSF1PPvh2OxB722MA1leIoZ+LbvTm03t2s7CNwbm6iMTXErAAcoKrnYEkgBd9umK26Se30uS2h7JIxeXbQRLDGADIVdyW+IQ7+dSe8j+9IrJ1f2oQNchVwV5QwTqcb7007O4mrqxyZ+GbzSFI+65okDFueIc4BPjlckVdWOvavZqphv52jOcLN+IDjb3t9vQ11ntwPzJIvxUn9qsJ7HTtRVhfwW8zFjjnALAdBg9R0q+NZWs48CqdOUpbW1xZqllx5cIQL+xjkHi8Dcp/pP+az9lxfo11gPcG2c+7cLyfX8v1qyveBtPly1nPcWp8BzdonyO/1rAX3BeqwAm3MF2vkrcjH9Dt9adqM/BG9WPk6RDLFPGJIXSRD0ZCCD+tTwPKuMSW99pMpeSK7sHHvjmQH/ALDY/OsrY8XavbKAZ47pB0EyZOP5lx9c1F4brF3JLEL8kdR5RStJh4+XkHb6bIH8ezlBH1ApVft5die+h3MinCtxZXOrS6ZerAt5ZmGJGQ4gmY9919Ce9j/kT51Z3fCkOn6Vqmnx6sUttVtY9Ph9sxlZgpROXlABymBjr3RWI4Z0niTTOItIikgvESNYzeXRvpJoJlMTdpzK7kBxIVACgdCehFW1noerPqWhTXWhXkMqX0VzvqElxBHGCeYSiSQ4kUYZSvUkfCoEjbdS4etdNttbudNltdKguLAQPIEKiLDOWk+IVtvUVjNX0W00XRNVtpNciisdTiiSFrzHdkRccwKAAr2aJ4bcnWtN1rQuKLjVb1xpV9LaN2yG1M8zwuS/4e/tILKy9TgBc45TtWb4403VbfX4dQmsYtT0gW3LHaSTOtvZOEVG5wAVK7s2SFyOYE9BQBuOoWOpalaaXOs+m+1Wt6LxGTnaKRDE6Dfrn8TORttV1a2Ez6xb6pNLCWFibZkjDYLGQNkE+GBVHg9LWz4fstNtr0XhsIIonmHR8oGDKfFSDtjyx4VmhjG3SkM9rxlVhhgCPUV7SgZS9nizkIFP8Jx+1VaiW8qgST1qLmNIn3WBBwQeoNYi+4Y0e8JaSyjjc+/D+Gf/AJxn9aydTVvOiNRoUop6mmzcAwFz2GoXCJ5OisfntSt1pV++n3K9zDsUaUpWMuFQnhiuIJYLmJJoJVKSRuMq6nYgip0oAsNE0iz0SwFpYI4jByWkfndtsDLeOAAB5AVkK8pTbuBIMa8JJ615Si7AUpUXdUxzZ38gTSAlSoLNGxwrrnyzvUnZUXLHAp2YXJZPnSrG4vHjfAjGCM7nelTVOTIuaL2lKVWSFKUoAUpSgC2vLhoSgUKc+dVYHMkYY4z6UpU2uUXUqVSg7wLn8xJH6A0pSWjH1KjKrDDAEeoqKxIrcyqAf2pSldhYp9kskspcZIbH0FKUqy7I2R//2Q==: Live location: 13.1850668, 77.6988971 — https://maps.google.com/?q=13.1850668,77.6988971

[2:57 PM] **Aashu:** dekh rahe wo end ho jaysga

[2:57 PM] **Aashu:** ok good good

[2:58 PM] **Aashu:** matlab hum location dekhte rahe call nahi karegi kya😆

[2:58 PM] **Aashu:** aao full welcome kit ke sath welcome hoga

[2:58 PM] **You:** Naa naa nahi chahiye

[2:58 PM] **You:** Mazak kiye the

[2:58 PM] **You:** Normal hi thik hai

[2:58 PM] **You:**
> _Aashu: matlab hum location dekhte rahe call nahi karegi kya😆_
Or kya

[2:59 PM] **Aashu:**
> _You: Normal hi thik hai_
to normal hi hai kuch hoga bhi nahi😆

[2:59 PM] **Aashu:** mutton party haj bus niche

[2:59 PM] **Aashu:** chal reha haj wo

[3:00 PM] **You:** Hum apna chicken biryani kha ke aa rahe hain

[3:00 PM] **Aashu:** kon sa chicken biryani

[3:00 PM] **You:** Air india

[3:00 PM] **Aashu:** kaha mila chicken biryani

[3:00 PM] **Aashu:** gajab

[3:00 PM] **Aashu:** biryani diya tmko

[3:00 PM] **You:** Haaa

[3:01 PM] **Aashu:** kaisa tha taste

[3:01 PM] **You:** Badhiya

[3:02 PM] **You:** [Image]

[3:06 PM] **Aashu:** hum to nahi khaye hai

[3:06 PM] **Aashu:** biryani kabhi

[3:06 PM] **Aashu:** flight par

[3:07 PM] **You:** Accha tha iska rajma or chicken biryani

[3:07 PM] **Aashu:** rajma bhi tha

[3:07 PM] **You:** Haa

[3:08 PM] **Aashu:** pauch gayi

[3:09 PM] **You:** You can track

[3:10 PM] **Aashu:** pura form
me jo

[3:10 PM] **Aashu:** ho

[3:10 PM] **You:** 😛😛

[3:25 PM] **You:** ??

[3:25 PM] **Aashu:** kya

[3:26 PM] **You:** Utar skte ho niche

[3:26 PM] **Aashu:** aayegi tab na

[3:26 PM] **Aashu:** abhi time hai

[3:27 PM] **You:** Kitna time hai

[3:27 PM] **Aashu:** 15 min dikha reha

[3:28 PM] **You:** Niche hain

[3:28 PM] **Aashu:** hum bhi niche hi hai

[3:28 PM] **Aashu:** tm ghar bhul gayi kya

[3:28 PM] **Aashu:** apna

[3:28 PM] **Aashu:** c block hai

[5:03 PM] **Aashu:** [Video]

---

## June 8, 2026

[2:23 PM] **You:** Kab tak aaoge

[4:47 PM] **Aashu:** dekhte hai

[6:25 PM] **You:** To aao na ab kab aaoge

[8:11 PM] **Aashu:** [Forwarded] Dear Passenger,

Your trip with Greenline Travels is scheduled. Please check the details below to track your vehicle for Bangalore to Tirupathi Package.

PNR: 5523360
Vehicle Number: KA 51 AF 3114
Driver Details: Driver not assigned
Contact Number: 9845047994 08041139854

Live Tracking Link: http://trkg.in/BITLAA/OZ21PG

Please review the above details before the journey.

Greenline Travels
Your Travel Partner

[8:11 PM] **Aashu:** [Forwarded] Dear Passenger,

This is a Reminder for your journey with Greenline Travels.

Bus Journey details
From: Bangalore To Tirupathi Package, 
Journey Date: 08/06/2026,

PNR: 5523360, 
Seat No: 7U,
Reporting Time: 09:50 PM,

Boarding: K R Puram Ganesh Temple, 
Service No: Hassan-Tirupathi PKG, 
Bus No: KA 51 AF 3114,

Address: near GANESH TEMPLE (MIDDLE OF ROAD), 
Landmark: Ganesh Temple, 
Driver details*: -,

Greenline Travels
Your Travel Partner

[9:11 PM] **Aashu:** jaisa hoga humko inform karte rehna

[9:12 PM] **Aashu:** jada confused mat hona jada dikkat ho driver ko call kar ke puchna

[9:12 PM] **You:** Okok

[9:12 PM] **Aashu:** chalo happy journey

[9:13 PM] **You:** Huuu ji sukriya 🤗

[9:13 PM] **You:** Kab ja rahe ho party me or kahan

[9:14 PM] **Aashu:**
> _You: Kab ja rahe ho party me or kahan_
ek dhabha hai khana woha ka accha hai

[9:14 PM] **Aashu:** wohi jaa rahe

[9:32 PM] **You:** Seat details bhejna

[9:32 PM] **Aashu:** papa ke pass hai

[9:32 PM] **Aashu:** u1 u4 u7 hai

[9:33 PM] **You:** Ok

[10:12 PM] **Aashu:** baithi

[10:12 PM] **You:** Bus hi nahi aaya h abhi

[10:52 PM] **Aashu:** baithi

[10:52 PM] **You:** Haa baith gaye

[10:52 PM] **Aashu:** chalo good

[10:55 PM] **You:** Hmm

---

## June 9, 2026

[3:20 AM] **You:** Pahuch gaye tirupati

[4:49 AM] **Aashu:** nikli

[4:49 AM] **Aashu:** suno puja kar ke niklegi mobile milega to msg karna

[5:06 AM] **You:** Haa abhi nikal gaye hain

[5:15 AM] **You:** 5581

[10:21 AM] **You:** So hi rhe ho kya

[10:21 AM] **Aashu:** nahi

[10:21 AM] **Aashu:** uth gaye

[10:21 AM] **Aashu:** tmlog ka abhi tak ph submit nahi hua hai

[10:22 AM] **You:** Nahii

[10:22 AM] **You:** Line me hi hai

[10:22 AM] **You:** Abhi tak hall bhi nahi mila hai

[10:22 AM] **Aashu:**
> _You: Image: I wish you a very Happy anniversary! Mummy and pita ji 💓🎉💕May God bless your marriage with abundant health and endless joy💫🥳❤️_
ye wala photo bejna

[10:22 AM] **Aashu:** tab to din bhar lag jayega

[10:22 AM] **Aashu:** tab rush bahut hai

[10:22 AM] **Aashu:** raat me darshan hoga phir

[10:23 AM] **You:**
> _Aashu: tab rush bahut hai_
Hmmm

[10:23 AM] **You:** Thak gaye abhi hi hun

[10:23 AM] **You:** Hum

[10:23 AM] **Aashu:**
> _You: Thak gaye abhi hi hun_
😅😅

[10:24 AM] **Aashu:** tm to humse bhi jldi thak jati

[10:24 AM] **You:** [Image]

[10:24 AM] **Aashu:** phir amarnath kaise gayi thi doubt hi hota humko

[10:24 AM] **You:** Chale gaye the

[10:24 AM] **You:** Thak thak ke hi

[10:24 AM] **You:** Tab na last me ro gaye

[10:24 AM] **Aashu:** hh

[10:24 AM] **Aashu:** yeha royegi nhi

[10:25 AM] **Aashu:** uthna thakan nhi hoga

[10:25 AM] **Aashu:** mummy thik hai

[10:25 AM] **You:** Haa mummy to humse aage aage hai

[10:25 AM] **Aashu:** aage rahegi na tab na jldi hoga darshan

[10:26 AM] **You:** [album message]

[10:26 AM] **You:** [Image]

[10:26 AM] **You:** [Image]

[10:26 AM] **You:** [Image]

[10:26 AM] **You:** [Image]

[10:26 AM] **You:** [album message]

[10:26 AM] **You:** [Image]

[10:26 AM] **You:** Pura photo ho raha h🫣😜😜

[10:27 AM] **Aashu:** hh papa paresan kar denge

[10:27 AM] **Aashu:** photo lekar

[10:27 AM] **You:** Nhii thik h

[10:27 AM] **You:** Mujhe maza aa rha

[10:27 AM] **You:** 😂😂

[10:27 AM] **Aashu:**
> _You: Nhii thik h_
hh tumhare liye to thik hi hai

[10:28 AM] **You:** [Image]

[10:28 AM] **You:** Abhi itna jana h

[10:30 AM] **Aashu:** are abhi time lagega

[10:30 AM] **Aashu:** 10 baje tak hall me aa jate the

[10:30 AM] **Aashu:** hall bhi nhi aaya mtlb rush hai

[10:30 AM] **Aashu:** to tm log ka darshan ek do baje tak nhi hoga

[10:30 AM] **Aashu:** shaam ho jayega

[10:30 AM] **You:** Haa sham hi hoga

[10:33 AM] **Aashu:** hh

[10:33 AM] **You:** Kahan office me ho ya ghar hi

[10:35 AM] **Aashu:** ghar

[10:35 AM] **Aashu:** office jayenge abhi 12 baje

[10:39 AM] **You:** Late kyu Aaj

[11:01 AM] **Aashu:** meeting me hi hai

[11:39 AM] **You:** Okk

[12:16 PM] **Aashu:** bro

[12:17 PM] **Aashu:** abhi tak hall me nahi gayi ho

[12:25 PM] **You:** Abhi ek hall dikha hai

[12:25 PM] **Aashu:** ohh

[12:25 PM] **Aashu:** bahut late ho reha phir to

[12:25 PM] **You:** Gol gol ghum rhe hain uske charo taraf

[12:25 PM] **You:** Gate mil hi nhi Raha

[12:25 PM] **Aashu:** mazza aa reha

[12:26 PM] **Aashu:** garmi hai ya nahi

[12:26 PM] **You:** Hai garmi

[12:28 PM] **You:** [Image]

[12:31 PM] **Aashu:**
> _You: Image_
ohh

[12:31 PM] **Aashu:** hall abhi tak nhi aaya

[12:31 PM] **You:** Dhakka mukki ho gaya raha

[12:32 PM] **Aashu:**
> _You: Dhakka mukki ho gaya raha_
hmm thora hota hai

[12:32 PM] **You:** [Video] Dikh raha hai but aaya n

[12:33 PM] **Aashu:**
> _You: Video: Dikh raha hai but aaya n_
accha

[12:43 PM] **You:** Mil gya hall

[12:50 PM] **Aashu:** good

[2:54 PM] **Aashu:** kaha

[2:54 PM] **Aashu:** ho gaya darshan

[3:06 PM] **You:** Abhi kahan

[3:07 PM] **You:** Abhi to ek hi hall se nikle hain

[3:07 PM] **You:** Raat hoga aaj

[3:28 PM] **Aashu:** haa raat ho jayega

[3:28 PM] **Aashu:**
> _You: Abhi to ek hi hall se nikle hain_
acha

[3:28 PM] **Aashu:** abhi tak ph nahi liya hai ph lene ke baad bhi 4 se 6 ghanta lagega

---

## June 10, 2026

[12:58 AM] **Aashu:** hello

[12:59 AM] **Aashu:** jab ph haath me aaye aur mera msg dekho to humko call karna turant ok

[2:27 AM] **You:** Khana nahi banega ab aane ke bads

[2:27 AM] **You:** Baad

[2:27 AM] **You:** Kuch arrangement kar ke rakhna

[2:27 AM] **Aashu:** 😅😅

[2:27 AM] **You:** Bahut jyada pair me drd ho rha h

[2:28 AM] **Aashu:** okk

[2:28 AM] **You:** Sir drd ka to dawai liye hain to thik h

[2:28 AM] **Aashu:** live location bej do apna

[2:28 AM] **Aashu:** next 8 hours ke liye

[2:29 AM] **You:** [Video]

[2:29 AM] **You:** Laddu le rhe h

[2:29 AM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBQECBwYI/8QAPxAAAgEDAwEEBwYDBQkAAAAAAQIDAAQRBRIhMQYTQVEiYXGBkaGxFCMyQlLBB1PRFWJygpIWMzRDY3OT4vH/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/8QALBEAAgEDAwIEBQUAAAAAAAAAAAECAxEhBBIxBUETFCIyBkJRYdEzcYGh8f/aAAwDAQACEQMRAD8A+lUhA5bk+VNAwOKw7bELEEgc8VkEMARyDyKSVhRhGOEZooopkgqvub/DFLcA44Lnp7vOpk793BI/6VJ+VUsSZMUZ5BZVPrGeflUoojJ2wjZFknclQ8rHgt4fHp7qkixZY2eZ8bQTtT+tWQAAAAAA6AUu6/3DAfmwvxOKNwttjFtCkMY2ooYj0iByadRRUSYUqeCOdcSLnHQjqPYabRQBVvYTqxEZR18CxwfpRVpRUtzI7EVc1zctGdyKiOMfhP1zTYb0vIiupQc/h9IHy9leYur+9s7jX7vbb3tpaJbzSsZGQuO5Bbu1AIGRk8nH1qRrF/Pbx9p1jtYfsemwlTILh0lkJhV+MdPxdQalZENzPWqQwypyPVWa892ilntbW6ms3lSa0kS72IxBlRPxqf1ZTPvxWE1KSfVdRvLeUy2OnWe1Y+97uOWVwJCWJ44TZyem41HaT3FzqJxZyevC/E4/evA9oe3NhoV8sEcT3t3EcvGjBVTjozc4PPQA1O1btc6aFrkghtZrixt47iN4WcxtvYqAcgHgjPHBrg15O0MLysTJITksxyWY9SaxazUSopRjyzvdD6ZS10pVaz9Me31Ox6d/Fu2kuFTUtKltoTx3sM3fbfWRtU49mT6q6JFcwX1taz2kqTQTEOjochhjOflXydp9688pjkA6ZBFdQ/hr2mm0rTb6GURS2ttIkqxuzB/vCQwTAI/LnB8T66p0mpnOp4czb1npGno6fzOnwlyjtlYBz0BPsGag6xqEWlWd1dXTboLdclRwzseAo9tcxXX+0PaK+cQXslnAvJFvuVYh4Z2+keeM+Zrpxi2eTlUUcHXM846HyNZrlehdsdT0vURZdoDLLBuCyd8PvYs+OevuNdRRskjIbHiOhB6GiUXEIzUjeitd6/qHxoqJMq5ez9g9jqVovfxwX0SQyBWHoKsewbcjyHjmtrrSLS9j1uF2nCamcTkMMr90qejxxwo655zVFpd1qK2+j3k2p3M7TajJYyRuECNGrSoCQADu+7Dbs9SfDipHZ3UL651RbC4nYvpSSrev/OctthJ9qAt7cVOzK7p9i3udZ0i0vLiG/wBU02CbcN0M1yisAVGAQT4jn31X6ZoWlf7PtpmnztPpk8bffJMHL7mxkMODt2gD1KBTNalEi6Dl9zDUoieenoPUPXb7VJ9eurGxa6UQ2STRm3kiTLsz+k2/qo2gYHHJz4UWBv6m0/ZuPUIL5b67vb03kS20ru0aELHISMAJgc5+NcI7Q6LcaNqVxpmopl4+jY4kT8rj1H5HI8K7Xf3epyW+vXTX89rPYafDdJDAyGMS90ztng5BK464x7jVD/EPRnvLaZri9muJ7bTTqCPKF4ZXUOowBhWB6eBCnzzj1mndaN1yjt9D6mtFV2T9ksP7ff8AJx2G3httzKMccknwrtPYPsNNH2cn/tO7vbRtSCtNbRBFIRc7AxZSQeSSOOuD0OebdlNPi1M6lcTKWhs7QzJg8d5vQDPuYn2j1V2PU9S1mbVtYFgJ82E8ccSLJEkWNiMe8DHcd24jPTgY5zVGg07/AFpfwdH4j6nFvyVLhc/g0/iQJJ+zt6I85hvI5ZAP0FNo+dUuhWQWaKzuoGmt5WCWkltbBC6sciVp1GRjGCOvPqr22to3eSSQWr3SlTFPblcCWM9Rk4GR4GvKnsZeTWzP2Z1qSOxlzm3lkdNp8VbbnJ9orqxatY8hJeq6KbtAEGkSlhZLbyJD9jiiZWkSTA7zn8WM7gS3UkV0jSEeJLeGXPewWcEUuf1hefqK8jpvY6HQLiGe8dL/AFMnNvapkRgj8zHrgez417GwtruGEmWWIzyHfI+0nLH3jilJq2BwTTu0TyAeoFFRrdriWCOTvIhvUNjuz4/5qKrLFK+bDkt7ZRGn2aARxyGVVEYwrkklgPA5YnPrNQtN05rWO8eedZ7y8ffNMkXdrwoVQq5OAAB1J5z51Y0UXHZGjRRuIxJHG/dsHTeoO1hwCM9Dyeaharp9jdpB9tsrW4WNwF72INtDHHGfXjirCkXvFuzfoIf4EH9qBSWGLEEM0t4ssEJEoCSDuxiVNmMN+ocsMGla1pdvqWmXlrJshae3a378ICyKfAerPOKkp/xsvrjT6tWbs4t3+FF7ZE8Rb/crdN0jQtKtri20+xtYre4YvKmzcHOc85zx5DoPCm3sWmXFwL24sre4uoBuSRoQzjHIAJHn09dR6ZbrvmjXzYE+wc/UD41XGXZGbzU6ss8snR3ad2puH2Pj0iylBn1ZqFJab7p59KvjbSOPvO62sre1TkZ9dW1L477kc4wDirDVZ9yguZjpM/osbm8kG6SabkkeAGOn0qfZ6jJdWFzMUCGNTjB6nGaqtYiluNRumjUskIG4+Qx/9qbpKbdHH/VmAPsLAH5ZrTOEVST7nOp1qkq8o/Ln+sFzEgjjRF6KABRW9FZjphRSe+84pfhWe+Hikg/yGiwXG0q6QyWsyDqyED4Ud8P0yf6DR36/pk/8bf0osJ2asLVw9zC69HiY/NcfWi/z3GB4kUiORIoLGR3VVA7sknA/D/ValmeMbcEtu6bVLZ+FDVyv3Rab5Ex2cZRSd2SMnmiCJVvHKDAjQL7zyfkFqQsgZ2UBsr1ypA9x8aXaggzFh6RkJJ8+mPlilZIFTimrIfRRSWuYF4aeIH1uKZY2lyeQvJn+2XJR2Ad2zg9Rk8Vf2myCx05ZHCgtuO44/Kx+pFVT6S2furiOQf3VY/QGr2yAabKghIIxCuQRzwT19QWtVecXFKLOVo6U41JOa5/0f9qt/wCfF/rFFPorKdXIVHluPTMUC97KOvOFX/EfD2dazeMwh2RkiSQ7FI6jPU+4ZPupkUaRIEjUKo6AUCd27IjxRySqe+nckMQVT0Rx5ePzpn2SA/jjEn/cJf65rNv/AM3/ABmmsdoz1oBRQi4UIsLKAAki4AHn6P702WQRrls9cYFIvS32Z22gBMPyf0nP7U24UtH6IyQc4zQxO6vYgzSbpywLR5HBPGKbBsuZpyxkOCCBvIGMeWcdQajzIyBVKlR15OaZpuVunB6OgI9x/wDYVCLzYyU5PxNrJf2S3/kRZ8ygpqqqDCqFHkBitqKmbUkuDV2CqSxAHmaixPJ31xsC43jkn+6tMuNpjcSEBSCMt0qNYMG348QjH1EqOPgB8apdR3wN8pErdN5xj3H+tFZopeLIntRrPxdWx8yw+Wf2qRRRV5WuWJhP306+AIPypj/l9tFFNgjLAMpDDIIwRSrIk2cBJyTGuT7qKKQvmG4qJeSGKeF1wTtYc+7+lFFAT4KyPV7iSYIViAJxkA58PXU6KBrppDLcT4VgAqkKMFVPOB5miigyuTbSbNBp9st6AEPC5/EeeasI4UjXaihV8hRRVXMsmuEVFYRttHlRRRVlkM//2Q==: Live location: 13.6848936, 79.3463796 — https://maps.google.com/?q=13.6848936,79.3463796

[2:30 AM] **Aashu:**
> _You: Video_
wahh pauch gayi

[2:33 AM] **You:**
> _Aashu: wahh pauch gayi_
Nhi

[2:33 AM] **You:** Abhi line me hi hai

[2:33 AM] **Aashu:** hh to lagega phir 2 ghanta

[2:39 AM] **You:** Naa

[2:40 AM] **You:** Patience lavel ab bahut high ho gaya hai mera

[3:11 AM] **Aashu:** hmm

[3:11 AM] **Aashu:** bus par baithegi to msg kar dena

[3:17 AM] **You:** Abhi niche ja rahe hain

[3:18 AM] **Aashu:** mil gaya laddu

[3:18 AM] **You:** Haa

[3:18 AM] **Aashu:** okk

[3:18 AM] **Aashu:** suno hoskote utarna bus wala ko bolna yahi utare yeha se tmko ghar aur pass parega ok

[3:19 AM] **You:** Thik hai

[6:29 AM] **You:** Baith gaye hain humlog bus me

[10:05 AM] **Aashu:** hello

[10:32 AM] **Aashu:** apna

[10:32 AM] **Aashu:** live location bejo to

[10:33 AM] **Aashu:** wapas se bejo

[10:33 AM] **Aashu:** naya

[10:33 AM] **Aashu:** uska time khatam ho gaya hai

[10:33 AM] **You:** Live location: 13.0724012, 77.7874814 — https://maps.google.com/?q=13.0724012,77.7874814

[10:34 AM] **Aashu:** 5 min me aa jayega

[10:34 AM] **Aashu:** toll tax paar hoga na uske baad 2 min lagta ok

[10:41 AM] **You:** Ho gya rapido kar liye aa rhe

[10:41 AM] **Aashu:** hh pata hai muje ok

[10:42 AM] **Aashu:** aao aao

[1:23 PM] **Aashu:** [Forwarded] [Document] 001.pdf

[2:03 PM] **You:**
> _Aashu: Document: 001.pdf_
Mujhe bhi aaya h

[2:11 PM] **Aashu:**
> _You: Mujhe bhi aaya h_
wahh kya reply kare

[2:22 PM] **You:** Nothing react kar ke chhod do

[2:32 PM] **Aashu:** kon sa reaction kare rone wala

[2:33 PM] **Aashu:** kyuki hum to jaa nahi payenge

[3:04 PM] **You:** Rone wala kyu kroge

[6:50 PM] **You:** Kya

[6:50 PM] **You:** Barish me fas gaye

[6:50 PM] **You:** Kab tak aaoge

[6:50 PM] **Aashu:** baarish ho reha kya

[6:51 PM] **Aashu:** pata nahi

[6:51 PM] **Aashu:** hum kaam kar rahe yaar

[6:51 PM] **Aashu:** bahut kaam hai

[6:51 PM] **Aashu:** 9 baje tak aayenge

[6:54 PM] **You:** Ohh

[6:54 PM] **You:** Accha acha

[7:00 PM] **Aashu:** udhar pani par reha kya

[7:21 PM] **You:** Abhi to band h

[7:22 PM] **You:** Thoda thoda ho rha h

[7:25 PM] **Aashu:** okk got it

---

## June 11, 2026

[10:56 AM] **You:** [Forwarded] [Image]

[10:56 AM] **Aashu:**
> _You: Image_
hmm ok

[11:38 AM] **You:** [Forwarded] Kahan pahuncha

[11:39 AM] **Aashu:**
> _You: Kahan pahuncha_
nhi dikh reha

[11:39 AM] **Aashu:** isko aaram se dekhte

[11:39 AM] **Aashu:** galat bata reha ye

[11:39 AM] **You:** [Image]

[11:40 AM] **Aashu:**
> _You: Image_
mtlb

[11:44 AM] **Aashu:** [Image]

[11:45 AM] **Aashu:** aaj hi aana hai

[11:45 AM] **You:** Aaj fail ho gaya

[11:46 AM] **You:**
> _You: Image_
Ye wahi msg aaya h

[11:46 AM] **Aashu:**
> _You: Ye wahi msg aaya h_
tmko call kiya to uthayi nahi tm

[11:46 AM] **You:** Nhi kiya call

[11:49 AM] **Aashu:**
> _You: Aaj fail ho gaya_
nahi

[11:49 AM] **Aashu:** tm nhi samaj paa rahi hum batate hai

[11:49 AM] **Aashu:** call aaywga active rahna

[11:54 AM] **Aashu:** Track your parcel here: https://speedposttrack.io/tracking-result?d=eyJ0IjoiQ0cyMDQ3MTE0OTFJTiIsImMiOiJzcGVlZHBvc3QifQ==

[12:03 PM] **You:** 👍🏼

[3:18 PM] **Aashu:** _This message was deleted_

---

## June 12, 2026

[10:31 PM] **You:** Photo bhejna jo wo aadmi click Kiya tha

[10:33 PM] **Aashu:** [Forwarded] [Image]

[10:33 PM] **Aashu:** [Forwarded] [Image]

[10:33 PM] **Aashu:** [Forwarded] [Image]

[10:33 PM] **Aashu:** [Forwarded] [Image]

[10:33 PM] **Aashu:** [Forwarded] [Image]

---

## June 13, 2026

[11:22 AM] **Aashu:** kya

[11:22 AM] **Aashu:** 😅

[11:23 AM] **You:** Kya

[11:23 AM] **Aashu:** mazza aa reha

[11:23 AM] **You:** Bahut

[11:24 AM] **Aashu:** muh kahe bana rahi

[11:24 AM] **You:** Abhi kya karna h batana fir mai uske according kapde pahnungi

[11:24 AM] **Aashu:** football khelna hai

[11:25 AM] **Aashu:** half pant tshirt pehan lo

[11:25 AM] **You:** Wo hai nahi kharid ke la do

[11:25 AM] **Aashu:**
> _You: Wo hai nahi kharid ke la do_
tumhare pass kuch hai 😅

[11:25 AM] **You:** Bahut kuchh hai

[11:26 AM] **Aashu:** good night

[11:26 AM] **Aashu:** so jao ab

[11:26 AM] **You:** Baat karo na fir mai nahane jaungi

[11:26 AM] **Aashu:** abhi khane chalte

[11:27 AM] **Aashu:** suit pehan lona

[11:27 AM] **You:** Kahi ghumne nahi jana h na fir mai normal hi pahnungi

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[1:36 PM] **Aashu:** [Image]

[7:08 PM] **Aashu:** [Document] IMG_4358.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4357.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4359.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4356.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4352.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4355.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4353.HEIC

[7:08 PM] **Aashu:** [Document] IMG_4354.HEIC

[10:04 PM] **Aashu:** kya hua

[10:04 PM] **You:** Nind nhi aa raha

[10:04 PM] **Aashu:** hmm

[10:05 PM] **Aashu:** akbaki lag reha humko bhi

[10:05 PM] **Aashu:** beech me ekdum

[10:05 PM] **You:** Fan kam kar do na

[10:05 PM] **Aashu:** nahi thik hai

[10:05 PM] **Aashu:** humko garmi lag reha bahut

[10:05 PM] **You:** Mummy bhi isi blanket me h

[10:06 PM] **Aashu:**
> _You: Mummy bhi isi blanket me h_
hh

[10:06 PM] **You:** Ok

---

## June 14, 2026

[10:31 AM] **You:** Ab kiska wait ho Raha hai

[10:32 AM] **Aashu:** hum bole chalne to bole samay katna hai yahi baitho

[10:32 AM] **Aashu:** aadha ghanta

[10:32 AM] **Aashu:** inke sath ghumne jane me yahi hai ki itna harbarayenge ki sab kuch jldi ho jayega

[10:32 AM] **Aashu:** phir aise hi samay kato

[10:33 AM] **You:** Kato fir

[10:53 AM] **Aashu:**
> _You: Kato fir_
humko kam sunao samhi

[10:53 AM] **Aashu:** jo baat hai direct unse bolo

[5:01 PM] **Aashu:** Dear Swati kumari,
🧳Get set ready for your journey with Jabbar Travels

🚍 Your Bus has been Scheduled Below are the vehicle Details.

Journey Details for travel on 14/06/2026 🎫
PNR: 6321424
Trip: Rameswaram To Bangalore	
Seat Number(s): U1,U2,U3,U4

Boarding Details 🗺️
Pickup point: Rameswaram
Pickup point Address: Rameswaram Bus Stop opp Near Ramchandran Residency
Departure time: 08:00 PM
Boarding Contact: -
Pickup URL: -

Your Bus Details 🚌
Bus Number: NL 01 B 3752
Driver Details: Ajithkumar K,9585510157,Suresha K O,
Conductor Details: Gladwin Rameswaram,7418662558

Please Reach your Boarding Point 15 Minutes before departure time for hassle-free boarding.

Regards,
Jabbar Travels

---

## June 15, 2026

[2:18 PM] **Aashu:** [Image]

[2:18 PM] **Aashu:** [Image]

[3:29 PM] **You:** Photo bhejo na sara

[3:36 PM] **You:** [Forwarded] Jivan mein tumko mirchi nahin denge

[3:40 PM] **You:** [Forwarded] Koi baat nahin ab Aisa kabhi bhul mat karna plastic mein bandhkar bhejna

[3:40 PM] **You:** [Forwarded] Aadarsh ji gussa bhi kar rahe the

[4:01 PM] **You:**
> _You: Photo bhejo na sara_
??

[4:03 PM] **Aashu:** good night

[4:04 PM] **Aashu:** [Document] IMG_4442.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4441.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4443.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4439.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4440.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4436.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4438.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4437.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4435.MOV

[4:04 PM] **Aashu:** [Document] IMG_4433.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4432.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4429.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4434.HEIC

[4:04 PM] **Aashu:** [Document] IMG_4431.HEIC

[4:05 PM] **Aashu:** [Document] IMG_4430.HEIC

[4:05 PM] **Aashu:** [Document] IMG_4428.HEIC

[4:05 PM] **Aashu:** [Document] IMG_4424.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4425.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4427.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4426.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4423.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4421.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4420.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4422.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4418.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4417.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4419.HEIC

[4:06 PM] **Aashu:** [Document] IMG_4406.MOV

[4:07 PM] **Aashu:** [Document] IMG_4411.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4414.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4412.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4415.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4416.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4413.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4408.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4410.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4409.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4405.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4403.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4400.HEIC

[4:07 PM] **Aashu:** [Document] IMG_4407.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4404.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4402.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4399.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4398.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4394.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4393.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4395.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4396.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4397.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4392.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4391.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4381.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4384.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4383.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4390.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4388.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4373.HEIC

[4:10 PM] **Aashu:** [Document] IMG_4377.HEIC

[4:11 PM] **Aashu:** [Document] IMG_4385.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4387.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4389.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4378.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4382.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4372.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4379.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4380.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4371.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4375.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4376.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4374.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4367.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4366.HEIC

[4:14 PM] **Aashu:** [Document] IMG_4370.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4369.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4365.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4364.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4368.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4362.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4361.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4363.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4360.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4356.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4359.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4357.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4358.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4353.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4355.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4354.HEIC

[4:15 PM] **Aashu:** [Document] IMG_4352.HEIC

---

## June 16, 2026

[12:36 PM] **You:** Mere laptop ka charger liye ho kya

[12:37 PM] **You:** Nahi h yahan

[12:59 PM] **Aashu:** shayad le lo aakar babu

[12:59 PM] **Aashu:** meri

---

## June 18, 2026

[5:49 PM] **Aashu:** mera click kiya hua photo dp lagayi hai

[5:49 PM] **Aashu:** accha click kiye hai na

[5:55 PM] **You:** Haa bas yahi ek accha hai

[6:50 PM] **You:** [Image] Ye ek packet or order karna h or dudh bhi

[6:51 PM] **You:** Fast fast

[7:02 PM] **Aashu:** kaf diys

[7:11 PM] **Aashu:** le lo

[10:39 PM] **You:** Khana kha lijiye sahab

[10:50 PM] **Aashu:** ok mam

---

## June 20, 2026

[7:27 PM] **Aashu:** Dear Residents,

We are pleased to share that all 4 borewells are now operational with 7.5 HP motors.
If all four borewells are operated for 4 hours, they are expected to provide approximately 90,000 to 1,10,000 litres of water, which is equivalent to around 7 to 8.5 water tankers (13,000 litres each).
Considering the current tanker cost of ₹1,400 per tanker, this translates to an estimated saving of:
• ₹2.94 lakh to ₹3.57 lakh per month
• ₹35.28 lakh to ₹42.84 lakh per year
These figures are based on the estimated borewell yield and are subject to the actual sustainable output and operating schedule.
This is a significant step towards improving our water availability, reducing dependence on external water tankers, and optimizing maintenance costs for the community. The actual water yield and sustainable operating duration of each borewell will continue to be monitored over the coming days, and the operating schedule will be optimized based on the yield.
We will continue to keep residents informed with regular updates on borewell performance and overall water management.

We sincerely thank the BDA officials, volunteers, and everyone who contributed to making this possible.
Regards,

Naveen Holla U
Skandagiri Residents Welfare Association

---

## June 22, 2026

[6:54 PM] **You:** Maggi thanda ho rha h

[6:54 PM] **You:** Kab se bana hua h

[7:30 PM] **Aashu:** accha

[7:30 PM] **Aashu:** kha lenge aate hai

---

## June 23, 2026

[2:56 PM] **Aashu:** aa gaya light

---

## June 24, 2026

[1:26 PM] **You:** Kab aana h

[1:41 PM] **Aashu:** aayenge raat me

---

## June 26, 2026

[4:15 PM] **Aashu:** hello

[4:15 PM] **Aashu:** ek bakchodi ho gaya

[4:15 PM] **Aashu:** aaj bda hi band hai

[5:11 PM] **Aashu:** kaha ho bhai

[5:22 PM] **You:**
> _Aashu: aayenge raat me_
Okk

[5:22 PM] **You:**
> _Aashu: kaha ho bhai_
Ghar me

[5:26 PM] **Aashu:** reply nhi kar rahi

[5:26 PM] **Aashu:** mera pain itna ho reha na

[5:26 PM] **Aashu:** kya bataye

[5:27 PM] **You:**
> _Aashu: reply nhi kar rahi_
Phone pass me nhi tha

[5:28 PM] **You:**
> _Aashu: mera pain itna ho reha na_
Ab abhi hum kya kar skte wahan

[5:31 PM] **Aashu:**
> _You: Ab abhi hum kya kar skte wahan_
kya bole humko lag reha ab dikhana hi parega

[5:31 PM] **Aashu:** suno na raat me dinner par jayenge chalegi tm

[5:36 PM] **You:** Kon ja Raha hai

[6:10 PM] **Aashu:** hum anupam abhishek isha

[6:20 PM] **You:** Okok badhiya

[6:20 PM] **Aashu:** tm chalegi

[6:20 PM] **You:** Mujhe bola h??

[6:22 PM] **Aashu:** hh

[6:37 PM] **You:** Okk

[6:38 PM] **Aashu:** chalegi

[6:38 PM] **You:** Hmm chal lenge

[6:40 PM] **Aashu:** okkk

[6:40 PM] **Aashu:** ek do ladka aur rahega

[6:44 PM] **You:** Ok

[6:44 PM] **You:** What you want

[6:44 PM] **You:** I have to go or not

[6:44 PM] **Aashu:** tm comfortable ho to chal sakti ho

[6:45 PM] **You:** Meko idea hai nahi na kaise log hain

[6:45 PM] **You:** But koi n chal lenge

[6:45 PM] **You:** Kab Jana h

[6:45 PM] **Aashu:** dekhte hai

[6:45 PM] **Aashu:** bola hai chalenge raat me

[6:49 PM] **You:** Ok

[9:17 PM] **Aashu:** hello

[9:25 PM] **Aashu:** suno na

[9:26 PM] **Aashu:** ready ho jao

[9:26 PM] **You:** Hmm

[9:27 PM] **Aashu:** hum aa jayenge

[9:27 PM] **Aashu:** 15 min me

[9:27 PM] **You:** Ok

---

## June 27, 2026

[2:41 AM] **You:** Chalna nahi h

[2:41 AM] **Aashu:** chodhuary jaise aata hai

[2:41 AM] **Aashu:** chalte hai

[2:42 AM] **You:** Ok

[4:18 AM] __[Call]__

[4:19 AM] __[Call]__

[4:21 AM] __[Call]__

[4:23 AM] __[Call]__

[4:25 AM] **Aashu:** hello

[4:26 AM] **Aashu:** kya bakchodi hai yaar

[4:26 AM] **Aashu:** tmko thora bhi responsibility nhi hai na

[4:26 AM] **Aashu:** aadha ghanta se knock kar rahe hum

[4:27 AM] **Aashu:** aaj ke baad mera key touch mat karna samji

[4:27 AM] **Aashu:** ekdum careless ho tm samji tmse life me kuch nhi hoga aise hi rah jayegi tm

[5:26 PM] **You:** Bhuk I laga h

[5:49 PM] __[Call]__

[5:50 PM] **You:** Bolo

[5:50 PM] **Aashu:** gate

[5:50 PM] **Aashu:** kholo

[5:50 PM] **Aashu:** bolo kya

[6:54 PM] __[Call]__

[6:55 PM] __[Call]__

[6:55 PM] __[Call]__

---

## July 1, 2026

[2:25 PM] **Aashu:** [Forwarded] [Video]

[2:25 PM] **Aashu:** [Forwarded] [Image]

[2:25 PM] **Aashu:** [Forwarded] [Image]

[2:25 PM] **Aashu:** [Forwarded] [Image]

[2:25 PM] **Aashu:** [Forwarded] [Video]

---

## July 2, 2026

[12:08 AM] **Aashu:** Dear Residents,

The countdown has begun for our Independence Day (15th August) and Ganesha Festival (14th September) celebrations!

The BDA Konadasapura Phase 2 Cultural Committee requests all residents to come together to discuss and plan for these special occasions and make this year's celebrations bigger, better, and more memorable.

📅 Meeting: Saturday, 4th July 2026
🕚 Time: 11:00 AM

Agenda:

1. Celebration plans and activities
2. Volunteer identification and allocation of responsibilities

We request all residents to join the meeting and share their ideas, suggestions, and support to make these events a grand success.

As part of the funds collected during previous Ganesha festival celebrations, Approximately ₹58,000 remains available. These funds can be utilized for this year's Ganesha Festival celebrations.

Thank you!

[12:46 AM] **You:** Please thoda Dhire bolo na

[12:46 AM] **You:** Nind nhi aa raha mujhe

---

## July 5, 2026

[11:48 AM] **Aashu:** bolo

[11:48 AM] **Aashu:** meeting me hai

[11:50 AM] **You:** Chicken aaj hi banna hai na

[11:50 AM] **You:** 12 baj chuke hain

[11:50 AM] **You:** Bhukh bhi lagta h

[4:44 PM] **Aashu:** पाठशाला जारी है - रोज उठना जीवन नहीं है,,,, उद्देश्य लेकर उठना जीवन है 🌹🌹🌹🌹

[10:04 PM] **Aashu:** https://www.instagram.com/reel/DZpSo22PbbJ/?igsh=dzRpeXY0dzdsdXFk

---

## July 6, 2026

[8:38 PM] **You:** Kheer khaoge

[8:41 PM] **Aashu:** bus kheer khayenge

[8:41 PM] **Aashu:** khana nahi

[8:56 PM] **You:** ok

---

## July 7, 2026

[9:53 PM] **Aashu:** [Forwarded] [Image]

[9:53 PM] **Aashu:** [Forwarded] [Image]

[9:56 PM] **Aashu:** [Forwarded] [Image]

[9:57 PM] **Aashu:** [Forwarded] [Image]

[9:57 PM] **Aashu:** [Forwarded] [Image]

[9:58 PM] **Aashu:** [Forwarded] [Image]

---

## July 11, 2026

[8:05 PM] **Aashu:** [Forwarded] [Document] Adarsh & Swati.pdf

---

## July 13, 2026

[4:31 PM] **Aashu:** [Forwarded] Important Update: Plumbing Works

Dear Residents,

Two plumbing teams are working from today to address water-related issues:
•⁠  ⁠Team 1: Resolving issues inside flats
•⁠  ⁠Team 2: Working on external pipe repairs (series issue)

👉 Check if your issue is listed: https://skandagiri-water-complaints.pages.dev/
•⁠  ⁠If yes, it'll be attended to.
•⁠  ⁠If not, please raise it at the mygate to get it added.

Please connect with your POCs:
•⁠  ⁠If unavailable today, inform them, and they'll check this week.
•⁠  ⁠POCs will share updates.

Thanks,
Naveen Holla

they are working series issues in A block today , next they will take E block

[5:34 PM] **Aashu:** [Forwarded] [Video]

---

## July 16, 2026

[11:10 AM] **Aashu:** [Forwarded] [Image] Ratha Yatra will start from SLV by 4pm.

We ll keep you upto date with the latest.

---

## July 21, 2026

[4:19 PM] **Aashu:** traffic me fash gaye

[4:20 PM] **Aashu:** ek truck kharab ho gaya yaar bridge par

[4:20 PM] **You:** Jaa

[4:20 PM] **Aashu:** [Image]

[4:20 PM] **You:** Kitna time lagega

[4:20 PM] **Aashu:** 10 min se yahi hai

[4:20 PM] **Aashu:** [Image]

[4:20 PM] **You:** Ohh

[4:20 PM] **Aashu:** aadha ghanta yeha se dikha deha

[4:21 PM] **Aashu:** aur ye time kam nahi ho reha

[4:21 PM] **Aashu:** truck kharab ho gaya hai bridge par

[4:21 PM] **Aashu:** to gadi jaa hi nahi paa reha

[4:21 PM] **You:** Tab to or badhte jayega

---

## July 22, 2026

[2:50 PM] **Aashu:** mila bhs

[2:50 PM] **Aashu:** bus

[2:50 PM] **You:** Haa ab pahuchne wale hain

[2:51 PM] **Aashu:** wahh

[2:51 PM] **Aashu:** jldi hi

[2:52 PM] **You:** Haa wahan se to 5km hi h na

[3:23 PM] **Aashu:** pauch gayi

[3:23 PM] **You:** Hmmm

[3:26 PM] **Aashu:** problem bhi hua

[3:26 PM] **Aashu:** bus wala kitna liya

[3:32 PM] **You:** Thoda hua

[3:32 PM] **You:** 30

[3:32 PM] **Aashu:** ok

[4:18 PM] **Aashu:** nikal gayi

[4:22 PM] **You:** Nahii

[4:22 PM] **You:** Abhi Book nahi diya hai

[4:22 PM] **You:** Jo aake dega wo traffic me fas gaya h 5 minutes me aa raha h fir dega

[4:28 PM] **Aashu:**
> _You: Jo aake dega wo traffic me fas gaya h 5 minutes me aa raha h fir dega_
jaa ok

[4:37 PM] **You:** Nikal gaye

[4:37 PM] **Aashu:** ok

[4:37 PM] **Aashu:** live location bej do

[4:38 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQACAwQGBwEI/8QAQRAAAgEDAwIDBAYFCgcAAAAAAQIDBAURAAYSITETQVEHImFxFDKBkbHBFSMzodEkJUJDUmJygpLhNFNjdKKys//EABsBAAIDAQEBAAAAAAAAAAAAAAABAgMFBgQH/8QALBEAAgECAwUHBQAAAAAAAAAAAAECAxEEEjEFFCFBUQYTIjJhgdEVQkNxof/aAAwDAQACEQMRAD8A61Veza1qKSTbUcdBcrdUwzQVDPI4YLjkrAkjBGew0b33aFv9pWijq4oHjq4agl1J6I2SMDXHt4e0O53fblZazYYaLx4EqJZo65nemTxVUM6qMqcke6euCOmuwbsu8tg2NPdOENwengiZ2aXwllzxBYNg989B55A0paoFowbuug/TsN2tkUvhPXUzRI5QsASwOSB18tS32wNetsUFpSqEEkNRBLzlRsHwmwQB3GePTWCvG8r9PZK+Y7TgiMlCXljFxzPFA4x4hiGHA889PXW/2DG8Wz9tJNUJXMKNf1idQy+9gDOOwwOvpqxu5BKxruLGbmsuV5ZxxGsWns/WXaV6tFbVIzVtfNXwVEakGnkYgow88gjrjuCdXdy1u4KOviisu2aKvpnjBEstakLc+uVCkeXTr8dZHa1berx7YmN6pI7JLQ20xPQiZpDUxs3R1IHEgEgkj0A9cRsSDy7EqH9ntn2rJXwmCGZDWuqN+vhWQuUX0JOOvw06m2HR0N/tN2sMSW2ejmZZ0dpHE8DLgr1J6juNZ+o33uKZtxR27acVVBaTJFUypcTgYByAOnIgZJC9R88adZL7U7S9iVmuatFeJQQoUTlBxd2woOMsynC4x6+Q0Aaau27eKPcVxu+2qq2qLmqCso7hG7xl0GFkUqQQcYyMf7Qw7Pr6b2f3KwwXGEV9e8ry1YiKovitmQKoOcccgdfPQO4763daprbHX7PhgNfIIYC9yBBkIyEOAcMfIHQ72O7oue4Nz1IvVbXyVclLJUCJKlGpowJAnFoQuY2HlknIOfMaANLX+ze1Qx0Eu3Kf9HXK31EU8NS8jurhD7ysvI9CM9ho1PY4qj2hSXqaSOSlls5tj0rRklszcySe3HBxjR2rZ4qRyrHkB9bHx1BAWWrWN2LFCyBj3IIBH4aABGzbTJt6zm2S1NLWU0MzikaXIeOAnKxtkHJHUZ+Wlo/TqvFxgdHby+Ofz0tFwscWuG0663W+DbN0vdlo6KoRS1NaqH+W1yocjPbLHj3z1IPftrTTwrvzam57F4BtVNRzQ09K8sJSVFREcCSMnPcEA+YIIHTWl3FtW0X64CsuUVSZYYxC3g1LxCVASwVwpGQCxP269tlho7HQ1hojUvJVFWmlqZ2mkfiOKgsxzgDoNRckuA7HNaqxbye+3Jai5Usck1rFPPVmhYUrQnChUfGTIMk4xjrrouz7fT2Ww2OhppmqIIKZeMvEguW5MWx3AJbt5aG7glYGUF24CPOM9B00ds+IaS1gggLSxjGDke5q2UcqTK1K7Mzu3YFPujdk10uNdItL9AFPToFcSU04bIkXsMD0PfJ+B1kJ7pVbc3xS3PcF1iv1yt1IaSGOkjMQwc+9M57Nhj0Abyzjz69uC5/QLDcqyEjxqemklQMD1ZVJH4a+Ya2oeOJ5nJklY5LMclmJ6knWfjMRKklGGrOi2JsunjXKpWfhjy6m99nW8qfb9FdKC6U8pjuFbLVmpjPPw/EVVwy9CQMZyOvXtrT2nZVNXeyej26byrtHKaqmrqdCVV+ZZTg9x7xGuI0FY80pSQDtkEa7V7D7hM1FdaFld4IHjlTGPdL8sj5e5n5k6qwuKnKfd1D2bY2Ph6OH3nDcEtVqWRtW/wB5utpl3fuC2zUFtqFqkhooeDVEq/VZycY+zyJ9c66FGlKJJGhSBZJTycxgAufiR307xh5pIP8AIT+GvPFhyCehHqpGtI5UmIBBBAIPkdUKhhFXZOepRugJ9V/PV8EEAjqDqjX+7MG/6ZP+kg6EDHPP4MrjtyIbr8hpajuEBknDLnHHy+3S1JJEW2mTNl46jj1ZicfdjVarCCnPGIocgZ4geY02OtZAQYc5JOQ3qdMqKkzqqiJlw2SSR6HVSjPNxRJuNjK7kfCVh78Yj/661UJWFqXkfdWFRnHwOsze7fVVUVUsUeTKCF6jWnE8ZqTJMp4YwBxLfgPnq+qrxXuVU9WWKtqSuoaikqGJhnjaJxgjKsMH9x182360TWm41FurRyaM9HxgSJ5OPn+45Hlr6P8ApFEe4X7Yz/DWY9oVjob9YpGpjEtypVMlOQcF/WP/ADY+/Gs3E0O9hwTujoNi7S3Otln5Ja+nr8nBYaeKn5Mgx6kny13b2S2Sez2OaoqIGWqrXDspIBRAPdU/HqT/AJseWsV7JNuQ3q4S3KsXnR0WPDQ9pJSMjPwUYPzK+muyUUqxUeWZc57ZxqvAYf8ALLXkaHaLaSb3OlotfgsLLKzMBEMqcHL/AO2ncpv+XH/rP8NRRM7vM0JjKl+58+g1Lmf0j+8/w1pHKDnkWNeUjKo+J1RqJlmki4K5T3l5cehyPLV0xq5VpEUsPtxqOo/a0/8Aj/I6EDHUzCWBGK9eI7j4aWvKTpAF/ssy/cTpaQwUY5l+tA4HbOVP56YxKkh1ZMDPvDy0OtW5RcN7VdraenajLtFTIuOYkg48+X+Il8fCLPnodtm8V95uC09VO8qSw1DzeLTLEIgknBDGwA5Dvnv8x5yjJ8yDiuQfinimBMbggd/hr3xY84LgH0PTQbZl9jvlTcqVZaYc1M9G0CLyjhJZACD3YYV+o/rAOuntcrrSbX3HXy3BqqajqJaeFWgiAARwM9FGSQfPppuXQSiF0YHsRnPrp2qbXqNam+zV9vlpKO3UEFUIp40Dklp+RBUnIIjUYz5HpoRRbgmk2TcK0mjmu9DNHFK9NGvBw7oRxHb6rlfmp0ZgyhW22mgtkDQ0NLHDEztIVHX3j3PXVzgAcqWU/wB1iPw1TlviU4v1TWUM1LS22minjgmCq7MfE6ZUnIYhQATqhQX2ebaMtX9JpprpS10FFPLCoMbh54xyUduscmPnn00JpKyHLNJ5pO7DyvKueM0gz365/HUi1NQP65j81X+Go7o0lFebTSQnMVY84kVkBJCxFlA6ZHUajglnm3DU25iqwx2+CoAKDIdpJVY579kXRdCsy2K2cf0kPzXXj1crMjERkocgAEZ1KaCTyZD88jTTQz46GL7Sf4afhDxEcVwkjLjwUOWz+0I/LS1VqqaeOXDBMkZ90k/lpaXAd2EZKSlp6SDw6eFIaEtPEBGzeGcNkqB1zhm9c5PrrI1u4rFTLb4ILfNUTPKaaKL6DUQlUlP64qWQZ6ZYrnrjWwuLKadoWLqsytGzRtxZQQckHyOsHTbaiaNKGK+3VYIJFmVRFDxV0bkrKMdDy6k+fbVdK7jdkptJhqi3Tt7xKWpH0hKWEGlp6t7fPHDHkqpTmVwBlVHXzHw03cW47RQRXK2QW2aqnNVHHUQGmkSF5JXXPKQjiCQcjJwemoZNg0twpUaoulwJmeWWpOEUTiRlLDiBhc8QMjRO47Rhraqt/nGsit1fOlTV0SBCski8ezkclB4LkA+XlqQinurclqpK8UMlunqLnV1FPSqk9NJEk6rNkcXI4txLsR1wde3/AHHY6eqr6Sot1bUXKSPh4Zt838oMRJTqFwVDHIYeR02v2LRXa9pc6mvreAn8f6OeLAMGzxVyOQXIzjyycYzqjcPZtbbvcayvetmSWaeWTD00MnEv0YEspLAf0cn3fLQBa3JuGGNKGnitCVW4q4U8stCwYmIqrSqGYDiSrKcDIPn2GjFna3bpsAr6i3In6QCrUxOcnnC5ABIxniynB+A0Gv2y4LnRUs9sqKuludBStSJNFKVlqEVcBGcEdenc5HU5BGiexa6SstrRR2v9G2+ljjhhhKkFZBy8RevUgDgc+rEZOMkBBKWwWqWmhp5KJGihZnjBdsqSMEg5zpzwRUNQk8FPGo8JKcsMlvDTJVck9hyJ+/RHTZEWRCrjKnvoQ2iE1kAYLzBJ9OuNWNCyTAstM6Fw/wBXHTvqwFrBD1eMMF8hknTaEmSTiMv76OTjyUnS1JTyeLCj/wBoaWkMB1c4Zmalp6iRAuEaOndlJ+BAxjtqhbopYo38SmrFdzj/AIaToPX6us/vq51ds2qJLeJVqDRKwnSIuIQsAbJwD3IC9egzny1HTXmpqN6Q0pSphoXpZuEclO682UxHxCSowMOy48sderAa5mfaCvTzJUk0nLm/t9uZ7NzhJpuXT+nT4JI5YVeEgxkdPL7NSaqWz9hL/wBzP/8AV9WXBK4Vip9Rro4u6TPK+Aym/ZEejMP/ACOo6T3ZKhfSTP3jT6XIVwTkhz10yP3a6Yf2lVvxGpkegqX3Z6hPRg33jUnJhUkMxIdcjJ7Ed/y1H9Wv+Dx/vB06rB4K4JUo2cjyHY6AJ9Q1E4iAABaRvqqO509VKoRyLH1bVagA5SGTJqAcOT+Xw0AyARNUPKs5xUAZVfLHw1ZpKjkjLKcOnfOp2iVpEcj3l7HVS4U/L9cigkdWHrp3uK1uIqWUIJAil05niR2xpasU0qSRAphfIj00tJjRnaSJZrdUNJ1+jsKdR5FR0GfjjA+zT4YkaCpnYZaCIuo8j8D8Omlpa+e42lD6oo5VZ+n7NelJ9xe4ZtA/m6FySWkBlY/3mJY/vJ1c0tLXfw8qMp6kMH15v8f5DTG6XBPjGR+/S0tTIiqOlVTHzyw/dqwQCCCMg6WloYI903ivItgciMZ0tLSGO0tLS0ABq5FjqCqDA740tLS1atCp6n//2Q==: Live location: 12.956953, 77.7025156 — https://maps.google.com/?q=12.956953,77.7025156

[4:47 PM] **Aashu:** bus jo mila kaha tak ka gai

[4:47 PM] **Aashu:** hai

[4:48 PM] **You:** Kadugudi

[4:48 PM] **Aashu:** ok

[4:50 PM] **You:** Bhuk lag gaya

[4:50 PM] **You:** 😜

[4:50 PM] **Aashu:** hmm

[4:50 PM] **Aashu:** kitna book di

[4:50 PM] **You:** 2

[4:54 PM] **You:** [Forwarded] [Document] DataMites Placement Brochure.pdf

[5:00 PM] **Aashu:**
> _You: Document: DataMites Placement Brochure.pdf_
ok good

[5:15 PM] **Aashu:** traffic nahi hai na

[5:15 PM] **You:** 🙃🫠

[5:38 PM] **Aashu:** wapas bej do

[5:39 PM] **Aashu:** kitna time lagega

[5:39 PM] **Aashu:** mera meeting rahega phir

[5:39 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAMEBQYHAgEI/8QANxAAAgEDAwIEBQIEBgMBAAAAAQIDBAURAAYSITETQVFhBxQiMnFCgVKRscEVM3Kh0fEXJEOS/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwQFBv/EACYRAAICAAUCBwEAAAAAAAAAAAABAhEDBAUhMRJBBhMUMlGBwdH/2gAMAwEAAhEDEQA/AN1ktu3t5rQXSegp6ySSmjYGQkSxRyKJFVgD0+7PXVM+IO7NrUrUFuktNDeLbQ0ySrUQ1yq0ClxF4cJXLM+MEryXKjz0tsyivU2/rZc6mxVVokgtfyl4qJ2QLXTgKFK8WIbBGeXp09M1yn2LUwfC1bhTbfjh3vHWf4hGkUKLIjfM4CADoE8Prx7e2mI1uro7Da7fBba1LbRWyJ0NNBK6xIGRuQKgkZIbr+dKVMdtoa5r5WRUcFU8Xyvz0jqhMRbkE5EgEZAOsi3Lbtw3rcl23EdntPTu1LTJTXOmiqJo4lVvFMURfB+rj1yD9XTzw2Oxtw1Ni2xHNSzLSU9ZVxtbj4c8tHSzkBGxJlSV6+4BHbBwAaZuPcVt2tcKFjbJ6y73OHiDTFFJii65Z3YKAC/Tr56dbQ3TQ7kkq0pVqaWspyGno6pFDqD0DqVJDKSD1BP7apu7tuyU132vDBYKjc1jtNvkpKemcowFT9IVpuRA4lVHXBA8hqN+FO3bxaPiBdrxcLM1ropKOSJ4hDHFGsjSowSIIxVwAuOYC5A6jJ6gGwxq61X1vyHE4yOuOmvZpFLouTy5jyOmsldmQOkR6KR9Zx3x6Z9NItVzT44kHByPCTOD/vqXSxdSJSf/ACJP9J/ppEtFCoaSoK4HZmHXUXNJKSRJ4rY75boPyNV3cu4Ke2WmqnSFp6aCUQ1kkEgR4FIxyQNgOeXTAOe+NNQsTmV+/wBdJcLtPLI2URikYHYLn+56/wAvTVj+HNu5zT3KQHimYYc+Z/Uf6D+eq3R21rotPLZp0raKoyUqouqqB35D9LD+E9c9NavbqZaShhgQghV7gAZJ6k9NaMaajDpiU4UG5dTHOjRo1jNRhe7N93TdNjqa/btPc6WGzxNPUrQXBMMksTGOR5EOcxsuWj69znsSLtc91rb4LFSJQtf73WW5Kx/Bkjp4CgVeUpd8BQSSR/bXC/DedbY1lTdl2XbjLwahWGESMnbgZuPIrjpj003qvhJRV8Usdzvt0rEWiWgo+aRA00SurqDhQH6qB9Xln2w7I0dT/EOzRWVqqa2VUF0WuW3Nbpp1iKTMOQLScuIjwCQ/bS8tbUbt+HlNcdt1oss9VOAzVNSUDBJCrxrMoOOXE4ZQe2uP/FtqG3KyjrK+rnrpqiOt/wAQCIjxyRLxj4IBxCquRx9Ce3TE5uvZ9r3LLZEuvKSmoPEHy/BeEwaPj9QGMEYyCOx7aLCiu7ZN+sG7Kba+6LobnHcKN6qkqv1xSIfri5Hqy4OQT11Kbt3LattFYaiSoq61l5LTREAgeRY/pH+/tpXbmxktF5pLhV3q4XU2+nalt8dUqD5eNsZyygF2wMZPl+2sIulxlrp6q5VRLzTsZm6+Z7D8DoB7DWTN5mWDFKPLO3oumQz2JJ4vtjyabRfFKkE6irsLJD5vHUCVx+zKP660W1XKO+0EdVbZV+Tk7OD9XuMeR9jr5Xo6+SSoVJAuG7YHbWkfC+/vaKu5QM2YJaczBM//AEVlUY9yG/2HprPlc1iSxFhz3s6eq6NlsPLSzGX26eUabu+80lisVwnZHkipIhJJHF9zknCgnyBPdvL9tZrdLoaeWmobtc7BRSoIbzQ1lJC7U6SglRFLgnkjKzYfoemfTUxUXSG33MPXT13zc3h+M9NTeNDB4pxGknXJ5fwgE9f31Ztl7SWx3ea5WyRKGiqeXzFvjUSQyuPtljbvH3P09R7DXbaUEeMTcmc7MsVVTXC43quSip6i7pGBBb5XaFkAyZWyFBds98ZA8+p1dURUGFGB6a5lRmcOjYcDHUdCNIySSOwjEZ5LhnAPl7HVDfUWpUOdGkxPGR1YKfRuhGjUaJWKaNcPJxPFQWc9cDTYyPI5EnSEd+AJBPpn006FZ3OWmik4EiMKcEfqP/GlYo1BD5ZmI7sdctNEUwGDZGAF6n+Q15FKogXkcMoAZfPOgBfXzlvfbsm3b5PSPGfk5Sz0z+TRk/b+Vzg/sfPX0RHIxk4OoBI5DBzge+oDe1hiv1tkgnB6ITFKO8Mg7NjzHkfbOs2Zy/nRpcrg62kaj6HG6n7Xs/79HzjDSQwuXRevue2rltmM2uy1t1lulJZ6uriMVtqKpwAxVgzHiVbKnABOO351BWqlga4gXpaint1PIErZkiLrAckAOR9qllIJ1e6a80lXd6Sew11jS6wNPaTa6uoPGph8YmNo2AJBYcT2IbPsNZ9Oyrb86f0djxHqcYx9Hg96b/F+hQWiuvO4bW1XLc6K/LGOVzpII6q31iKjBagN0RX4kqOmRyAwc51q9ot1PaLVSW6j5/L0sSxIXOWIHmT6nufzphsyzS2DbsNvneLxBJLM0cGfCi8SRn8NM9eK8sD8eXbU1rpzlex5CMaDXiqFLEDqxyTr3RqBIMaNGjQAhxGTFGT6u+ev/ellAVQFGAOgGk6fqHPq5/rj+2ldNggAAJIAydNXASYO+OXIuT6LjH/GnWmyoZJGY/bz6++Ow0ITFIRxVpJOjN1OfIeQ1U93XmokeO22vkaif+HuF9fb2/c+Wpy5VLtTyPHGZEXPCMMFMzDyyew99Z1u+5R22eoprxGtDBdqSSnhusTMZIJeADeLH3CA4wy9AMeurcNb2yubtUhrIlRZalJ7MsJoDGHrp4qyFadqjmVK1bsSVjC4+lR9RY+erZ8LLRBT2WS500XyUdwdpBRwHNMrK7L48IYclV1CkDtgj21FbO2/UT3y217beobVSQ0rxVUtNNHJT3FSB4fBV+4Zw4ZgCMY6+WnEk99KbS2RJXJ3JiIkaM4mxjycdj+fTSuggEYPUa4jj8MkKx4eSny/GqiZ3o0aNABo0aNACVN/kqfXJ/mdK68RQqhR2AwNeSOEXk3/AHoA5mYgBU+9ug9vfTerdYovBVgihSzuT9qDuTpRm8FHnm+4jt6e2qpuW4c4a+3xUsdZWrGs8kMlR4CuM5Kc+wwoz16ds9M6nGNshJ0Qdbc5b5dJooqZZ7c0L0/y0h4q0JxzLHpgnHfy6a82tt2tt+5yYFmuVsdFo5RVyg1FtjGX8MFvpkiboDj6sce+BqPsFwsN6jFtkFTSvchGRQ3DMDzKGziOT7ZUb0B6j861eg8JYuEfFX/UuMHPbt+2PwNXYklHZIqw4t7tntuoKO2UUdHbaWGlpIySkMK8VXJJOB+SdONGq7Lu2jhn3DDNA6yWgKccx/7HJRgL6HkVXB/iX11mNHBYtGq/W7ppqPblou8lLKyXBIpfCVgTFG0fiO5Poigk/t66kqi4FLubdBTiWc0bVSM0vBWw4ULnBxnPfQFj7RqtR7okSx3C6V1tSCGkqDTECq5cmWbwnP2jAB658/bS1duqiiprpNQiKuShWA8oqgcXMrlcZAOMYz599AWT+jUXZ70leKtJqaSKeln8CQRN4yE8FfKuAM9HHkOudGgLJKR1Rcsfx765RWdw8gxj7V9Pf86bVkhpkDn6pW6csdF/GvPmJJUEAGJW/WO3H+IalQrOKypjRJ6uY4paVS/+ogZ1nd0r5/lEuISxNTVsbwz0dfMKOeZ2yH8KcnDZDYwQAMDrq4bvkpo7dDRSyhInkjUxhiGldmxFHnBxzfAz2ABzrNN5rSyXCipR8vTSrGtJLSXYmKGoTxVkcU9TxKZJBjbPce41bCqKpXZZdjWesuNZSf4tXXI09ilWSGguNuWOUMUdEJnUlZVALYKjqQCfe+y0bZyCso9H6H/9DSO2aKuoLT4d1nWatmmlqJRGxaOMuxYRoT14qCB/YdtSmq5SdlijsRwd4jgySRH0lHJT+DqIqts0U9yavlapdnqmqm8IKVbMcahD1yQGhjce66sFZ9Iif9IcBh5YPTXj03A86b6HHXj+lvbGlYUQse1rZV0drhq5KiqprfQihjj5tFnoqsx4kHJCgY7fz1IWyzJQ1FFOaqaeWloRQhpAMuoZTyJ9fp0tTSgT5A4pNk4Pk47jT3Sew0QNbY4BaKm3mSdoKqqkqXZUBYM83i4x6ZyNK1u3ae6w3FZFaCOuWBHQIpAETlh0885wdSVTVRU4+tvq8lHc6q287ZW3+GiWkobZVNSzFpYKvgzBSBjuDxBx17HtjtoEMafeW19tS1dGl0koYZKh5o6eShfimThuGB9pdXPXzJ8saNVi6fDjc09a8tmo7BbYGA5xKRKjSAYLpyjJVTgfT5dfXRp0BsU0ayxMjjKkaZWdAIGfu2eOT6aNGhcD7lLroIr7uu7Wu5oJqKZeBTsV4JyRlPcEEk5HqdV2gnqNsb629syOdrlYLjFzkguSJMYyVLngQo8/XOjRrRLj6RRH9NWpayaSpMchDDPfHXUho0azy5L48CNcAaSXP8OdKxnkik9yAdGjS7B3ImvcxTyKmAOQcex0rUVUvCAKQviDJI76NGp/BH5IW81E1LboJKWTwp6mvgpDMFVmjV3AYqGBHLHqD+NZ1abrXUrXG8xVGLjUW6ndpRGg4tLVJG7AAYJwMjOcEnHTpo0aT5BcGibOvtxqtvwyVdR48wlnjMjIoLBZXUZwAM4A8tGjRpDP/9k=: Live location: 12.9911619, 77.7557988 — https://maps.google.com/?q=12.9911619,77.7557988

[5:39 PM] **You:** Abhi 1km or h kadugudi

[5:49 PM] **Aashu:** dusra bus par baithegi to bata dena

[5:49 PM] **Aashu:** aur bus number bhi

[5:52 PM] **You:** Baith gaye

[5:52 PM] **Aashu:** kya hai bus number

[5:52 PM] **You:** No nhi pata

[5:52 PM] **You:** Nahi dekhe

[5:52 PM] **Aashu:** jaa

[5:52 PM] **Aashu:** safal market boli hona

[5:53 PM] **You:** Hmmm

[5:53 PM] **Aashu:** bridge utri

[5:53 PM] **Aashu:** ya us par hi ho

[5:54 PM] **You:** Utar gaye

[5:54 PM] **Aashu:** ok

[5:54 PM] **Aashu:** safal market se aa jayegi na

[5:54 PM] **You:** Haa 6 baje nikla jana

[5:54 PM] **You:** 10 minutes lagega mujhe

[5:55 PM] **Aashu:** khud nahi aa jayegi

[5:55 PM] **Aashu:** woha se

[5:55 PM] **You:** Nahii

[5:55 PM] **Aashu:** abhi to pura light hai

[5:55 PM] **You:** Already bahut chal liye hain aaj

[5:57 PM] **You:** Or period jaisa lag raha hai

[5:57 PM] **You:** Pet me Dard raha halka halka

[5:59 PM] **Aashu:** jaa

[5:59 PM] **Aashu:** okk

[9:31 PM] __[Call]__

---

## July 23, 2026

[9:24 AM] **You:** [Forwarded] Please log in to your LMS account using the link below:

https://learn.datamites.com/home

[10:45 AM] **Aashu:** ok

---

## July 25, 2026

[5:35 PM] **You:** https://www.myntra.com/mailers/topwear/snitch/snitch-men-typography-printed-round-neck-pure-cotton-oversized-t-shirt/37327053/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=wAEoegHQFI7HbhUg&shared=true

[5:36 PM] **Aashu:** THE BEAR HOUSE Men Self Design Textured Knitted Slim Fit Polo T-shirt https://www.myntra.com/mailers/topwear/the-bear-house/the-bear-house-men-self-design-textured-knitted-slim-fit-polo-t-shirt/34029085/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=81SYnGmFNiO31fma&shared=true

[5:38 PM] **You:** https://www.myntra.com/mailers/topwear/u.s.-polo-assn./u.s.-polo-assn.-polo-collar-brand-logo-pure-cotton-t-shirt/41011690/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=wAEoegHQFI7HbhUg&shared=true

[5:41 PM] **Aashu:** RARE RABBIT Men Plain Spread Collar Half Sleeve Cotton Regular Fit Polo T-Shirt https://www.myntra.com/mailers/topwear/rare-rabbit/rare-rabbit-men-plain-spread-collar-half-sleeve-cotton-regular-fit-polo-t-shirt/23669104/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=81SYnGmFNiO31fma&shared=true

[6:39 PM] **You:** Dono bana de

[6:39 PM] **You:** Yaa ek hi

[6:57 PM] **Aashu:** teeno bana do

---

## July 26, 2026

[4:34 PM] **You:** _You deleted this message_

---

## July 29, 2026

[4:50 PM] **You:** Banana
Jaggery 
Tomato 
Chilli 
Aalu
Chana
Maida 
Sezwan chatni
Milk and dahi

---

## July 31, 2026

[10:39 PM] **Aashu:** hello

[10:39 PM] **Aashu:** chola bana lo

[10:39 PM] **Aashu:** chaat khayenge

[10:39 PM] **Aashu:** aa rahe hai aadha ghanta me

[10:40 PM] **You:** Ohh

[10:40 PM] **You:** Bahar kya khaye

[10:40 PM] **Aashu:**
> _You: Bahar kya khaye_
kuch nhi do teen cheez

[10:41 PM] **You:** Okk

[10:42 PM] **Aashu:** kuch soya chaap panner tawa

[10:43 PM] **Aashu:** phir ye bola khana. nahi khayenge ywha choriye

[10:43 PM] **You:** Hmmm ok

[11:46 PM] **Aashu:** adraj208@gmail.com

---

## August 1, 2026

[1:47 AM] **You:** Kahan ho

[1:47 AM] **Aashu:** niche

[1:47 AM] **Aashu:** ghum rahe

[1:47 AM] **You:** Okk

[1:47 AM] **You:** Rukega wo ya nahi

[1:47 AM] **Aashu:** dekhte hai

[1:48 AM] **Aashu:** shayad chal jaye

[1:48 AM] **You:** Accha

[7:20 PM] **Aashu:** [Forwarded] https://www.facebook.com/share/v/1UmWafZ5Bf/

---

## August 3, 2026

[1:11 PM] **Aashu:** ek baar baithna to bolna

[1:11 PM] **You:** Ok

[1:15 PM] **Aashu:** nhi aaya

[1:16 PM] **You:** Nahii

[1:17 PM] **Aashu:** bus hi nhi aaya

[1:18 PM] **You:** Aaya baith gaye

[1:18 PM] **Aashu:** ok jayega na ye direct

[1:18 PM] **Aashu:** ticket kaha ka li

[1:18 PM] **You:** Ek aaya tha kadugudi ka

[1:18 PM] **You:** NHi baithe uspe

[1:18 PM] **You:** Ye direct h

[1:18 PM] **Aashu:** okk cool

[1:18 PM] **You:** Marathahalli

[1:19 PM] **Aashu:** good

[1:19 PM] **You:** 28 only

[1:19 PM] **Aashu:**
> _You: 28 only_
good good very good

[1:19 PM] **Aashu:** rush hai

[1:19 PM] **You:** [Image] Nhii

[1:19 PM] **Aashu:** 1 ghanta me pauch jayegi

[1:19 PM] **Aashu:**
> _You: Image: Nhii_
good

[1:20 PM] **Aashu:** exact 2:30 me enter kar jayegi class me

[1:20 PM] **You:** Haa ye badhiya h bus

[1:22 PM] **Aashu:** ok

[2:06 PM] **You:** Pahuch gaye

[2:44 PM] **Aashu:** wahh

[2:44 PM] **Aashu:** class start

[3:06 PM] **You:** Yes almost

[3:08 PM] **Aashu:** ok batana feedback dena

[3:08 PM] **Aashu:** ya abhi padh lo ghar aakar hi batana aise

[3:48 PM] **You:** Hmm Okok

[4:37 PM] **Aashu:** nikli

[4:42 PM] **You:** Haa nikal gYe

[4:43 PM] **Aashu:** bus mila

[4:43 PM] **You:** Haa

[4:43 PM] **You:** Baith gaye

[4:43 PM] **You:** Kadugudi

[4:43 PM] **Aashu:** mera 6 baje se meeting hai ek 😢

[4:43 PM] **Aashu:** wo release ka Kt call gai

[4:43 PM] **Aashu:** hai

[4:43 PM] **Aashu:** lekin hum dekhte hai aa jayenge

[4:44 PM] **Aashu:** live location bej do do ghante ke liye

[4:44 PM] **You:** Kitne der ke liye hoga meeting

[4:44 PM] **Aashu:** 6-7 ek ghanta

[4:44 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAIDBAUBBgcI/8QAPBAAAgEDAgIGBggFBQEAAAAAAQIDAAQRBRIhMQYTIkFhkRQyUXGB0QcjQlJiobHBFRZyguFDU4OS8PH/xAAaAQEBAAMBAQAAAAAAAAAAAAABAAIDBAUG/8QAKhEAAgECBQIEBwAAAAAAAAAAAAECETEDBAUhQRIiE1FhgQYUIzKRsdH/2gAMAwEAAhEDEQA/APShJPO2Y/8AX50LHG5Ia3C/1KKVib78Z/sPzpabtvbxu8KSK+V4iZY0iKDDAMvAFh3VIkjDTRYPAoeJG493t99IuIhGFbOQZgx8M8KWh7Fqf7T5H9xSBi6Xq4ojknZIpJIHLPh76dueCo33XU/nj96xerutJR+HPlxolPWWjEcymR5ZoEfpluF0h+8hHkRUE3czcQ+AfYKLeVjdRb2J4kcT4Vipb0NCzEZSUUSnXN6QeTxEfn/mlWLbrSI+wY8uFYuOzc2zd2SvmP8AFJtJERZI2dQVkYAE+NZcG/kTqi7ooyOe7b5g1Ht2zYxN/tyjPn/mpM7ekSrDGeypDOw7vYKiRwyi2uVTZ1e45yTkYrJWMXct6KRE2+NG+8AaKwMxPVv3TP8AED5U4oIUAnJ9tRj6OP8AX2/8p+dOwFCDsl6wf1A4pBDeoDNpJ4YP50hVCQkgk7ZRzJPDd8jT9yAbeUHvU/pUaHMltKF4syqw/wCo/cVImTHXcpU8iMVqPSHptpvRy1ignD3N8ycLeLGQOWWJ9UcPf4VtEcrvsJMQDccZya8u6lqEl5Nc6jcdqadjM3vPHHuHAe4VyZvHeDFKN2e3ommwz2JJ4j7Y39anR7X6Tk6xVutJdIeRaK4DsPgVX9a37SdStdStYLywlEsDMCGHDGDxBHcfA15ls7+SS4CSBcNyx3V036JLuVNXvrEMepltzNt9jKyrke8N+Qrky+Zm8RRnydWsaBlcLLvNZTtcbqrdfydpvuEKv9x1b86RHEhu7hXRW5MMjPdTk/1tk/4kz+WabjbN1C/+5F+Y416/B8y7meuS3Yq8PVJngyjgfKs2pVnuFBBUtuyO/IqTz51X6b2LmeL2fsT86OB5JNgT6MqnmhKn4GikS2e6RmjmeMMckD20VFuOieEfaA+GKUJBIrdS6lgPKoa6kv2oJR7ip/enBqVr10cDyhLiSNpUhb1mRSAxA8MjzqoVTLWu9S1xI0pxy5AfCkWKBTE3HJjBHaPd/wDadW8tpRMsNxFIYnMUmxg3VuACVbHqkAg4Ptpu1kTZbFZYyOr4kOCMHGDnlxxTwWwqKIiWRUIQA5GFGePj51566bdH36Pa7cWbIfRJSZLZu5oyfV968j8D316GM8S3R+sQgrg4OcEHv86o+m2hQdINKeGTG7b9VIOcb/ZYeHcR3gmuXNYHjxorqx6uj6j8hjVf2vZ/32POMNpDC+9F7Xdk8q6v9FWhy2sUurXcbIbqMLbgjBMeclviQMeAz31q3QLo8dY6StbajBILeyJa7iC5JYMQIz7yDnwU13O7IdoMQSoqnbjG3ge4Vx5LLOX1Jex7HxNqEfCeTwOaN/tL3Jlmd9ogPLG3y4VFiJENox5pIYz8cj5Vm0uY4o3RyQwcgLjJrDBvQ532Mv1nWKGHHmD869ah8irFjVeo6vWD7JEz/wC8qnIyuoZSCD3iq64uE/iMJBxsJVieVCFjlnawyW6s6ktkgncfbRTlrIiCVXdVxI2ATjhRS6gqFaqsxIVWJHMAE4rWtVs9Qu/pD05bC79BeDR5XM0luJl7U6jbtJHHhz8K3S7Qwyi4iH9QqbFL1kasjHaeNPUYqJxpLu7i6O6xpOJ73U9Y1+7gmNpHh3gj2LO6KWwvZXaAW+0KdguQ/RWw0WSK5t2sukttZiGYBZEgMvWx7hk4whA7/Vrr4jjEgcRxhwCAwQZAPPj44FQNW0nTL+2ufT9MsbrrMPJ10CvvKghScjiQCQD3ZNPWXQRdQaSyhvLvqd7RRSzKmPXKqSBWk2HpNhpfQ7XV1G/n1LVru0S6624d4p1nGXURk7V2A5GAMba3qx0yw0V4bbSrK3s7Z5DI0cKBVLkBSce7HlUK16KaHpF/Df2ViVljkzEjTO0UG71jHGTtQnPcKqlQ03odqLQO38K02G71TULi91K4lubgxBYY7lo1yQrdrOQBjHAmr7obfu/QPSdS1m4lfZZtd3E8zEttBZs5PHly+FWUvQrSRDaJZyX2nm1jlhWS1n2u8cj73RiQcgtx9oPI1i+6PaS3Ra30Hr5xYwrFGyhwzzRxkHYxxyOBnGKk42QycpOsnUpejXSbUZNL6QT69ttZ7W3/AIpCscYJS1kjZkBXgHZSrA5PE88VP/nCzjaWK4fUC1pZx3N5cpZ/VRq0XWbjxOMjPZGTnhx50XfQDSz6YdG6vSEvdPmsJ47eAbXEmMORkcVwfeCag9Lui8ln0T6XnT2kupdTit0SGOE7o1jSOLuJLcF3efvq7Ww3RYQa/pU0V7Kb2W1S0RJZ1uoHtzsfgjhSASCeAx38OdLh1vR5bCa+TU7WG0WQW8r3AeExucEKwcAqTw5iq3VeiGrapeXN/f3enfxRRbC0hiVxblLeXrNsmcntFu4HGO+ibonq1/qTapfLYx3Fzq1ndTW0c7SJHBAjAdoqNzknPId3spqgoyLrX0rdFNLvFgmla8YxrJ1trAsiYYZAyWBz4GiqT6Q+hvSDVemF/fWekPe2s3VmOWO4hTgI1Ugh2BzkHuxjFFZJRoDcqnYyAQQRkHgRVayNBOImkdYWOQVNWdQr50kxAo3zE8B9331pRtkYhuEt3kgkcnacqeZwe6nldLpJEw4xwIPA0zp7CMtAyhZAfOnH+rvkYcpVKn3jjSwQxNhUs34AZBPxxUid4Zoym4sD9wZ/So93wtE/BIR8Bn/FTN8p5RY97CoiN1CMeMMsh9sjf5p5I3X1I4Y/cM/Kl5nP2Yx/cT+1ITrZGcM4XacdlfDPfUIvq5D60zf2gCkSoUCkSy5LAZ3Y7/ClCONWBZiW7tzUXH+mPxighSRKjbhuLcslif1pykvuCnYAW8TioZivD686KPw8P2quVidRVdExKnfehSCR3UVUKo/PK7S9RDwcjJY9w8KHs1EO2M4kB3Bzzz405PD1jI6ttdDwPh3inqqlTzIdzC7xpKBidRk476Tag3REssmSh4IowB41OqDco1tL18Q7J9YUp12Bqm4i5iVYLgKOTjn7Dj5mp0R3RIfaoNRZmWSOZlPZaMMPgTmn7M5tYvBceXCh2FXHqaaFWctlwTz2sRnypbuqDLsFHiabNwoGQrlfvbeFQmYYEjycAtk9o88e+nCAcZGccRWHcKVBz2jj8qA46wpxyAD/AO8qCBztUnGcDOKZu8yWbFc8QD8M08rBiyj7JwfLP71QdJLK4u+jkrW2q3GnzQQuUZLgQRs3ADe2MgAjnw50oGy3gs42gjZom3FRniedFcc6QWLXN1DLBcJYo0IO2/6RhpJOJ7YIdhtPIYPdyorZ0epr6vQ7bRRRWo2hTVy2yFjgHuwaKKiZW2iqyOWAJCP+i/M0/YbpIyhdgqnkvCiis/MwXBMSGNDlVG72nifOmNRkKQ4GO1wOaKKxVzJ2CINOoZ5HGDkbcfKnfR1LZZpCcYzuI/Siilgg9Gi70B9/Gtc+kZ1teiomWKKQRXlqwikXKN9cvBh3jjyooqjdFKxwr+fbvTry+S30fQtstw8p32e7BPMDJ5cOVFFFb6Gip//Z: Live location: 12.9567432, 77.7054935 — https://maps.google.com/?q=12.9567432,77.7054935

[4:44 PM] **You:**
> _Aashu: 6-7 ek ghanta_
Oh

[5:26 PM] **Aashu:** abhi jaha tm ho

[5:26 PM] **Aashu:** wohi mera office hai😅

[5:27 PM] **Aashu:** yeha se dekhna teen km lamba line rahega traffic ka 😅😅

[5:27 PM] **You:** Haa h

[5:27 PM] **You:** ☹️

[5:51 PM] **Aashu:** live location bej do phir

[5:52 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABAUABgIDBwEI/8QAOxAAAgIBAwIFAgMGBAUFAAAAAQIDBBEABSESMQYTQVFhFCJxkaEHFTIzgbEjUnLRFheCksElQkNT8P/EABoBAAEFAQAAAAAAAAAAAAAAAAEAAgMEBQb/xAAuEQABAwIDBgYCAwEAAAAAAAABAAIRAyEEEjEFEyJBUbEUgZHB0fBxoQbx8uH/2gAMAwEAAhEDEQA/AOsWxPS3etZXc7Nyw2x251lkKnDYjIZekDAJ7Dtxxo/dt7uVI1lryiR12Ce70HDBpFMXS5Hr3b9dMKdWpQcvT2yjA56gWghUHBxkduAcDj41KVfbaLSGpRqUXkRozLFWVWAPyRyMgHHbgaZmCyAYsDEpTu129sliYV91nvAbRNaHn9DgOJIgJcKBxgscduDrPeLt3ZHvRwX5buNsktq9gK5hkV1QOMAfaQxbB4+w49dE7LstfbLcttDUeaSEwBa1QQRhCQWJXqbqJwvrjA4A0fTrVKKSx0aVSskv8xYogofjGD7j40i4JSesfuFWd+Wfad03mSDcbNiZPDzyJLMysynzO4wBwcZ/r7a6TkiYjPBOlG3bPtcFMrDtdCNJ4+mRVrqAynGVPHI4HHbgaadR6ur109aFCkWSTzVJrz2a/wCzCi1Kw9admrxiVMZUPZVTjPHYnXm52N2Xcb9ChPef6KnE8colhUl26z5kpfHUOAMDjg+va4CtWFZa4rQfTqQVi8sdAIPUCF7cEA/jpFNXq31Rtwp1bbxRlkM8QYryMj8PjRAlRuoOgAHkB6T98kpt397lvbqlCOSKWisLRxxSwpCGaNXYydR6mUliuRxheOdO/GZmWptprxo0/wC8qxSOR+hSersWAOPxwdM7e27fesRWblGrYnjx0SSRBmXByOT7HnRMsccvT50ccnS4kXrUN0sOxGexHvoJ4oOhwJ1VW3GK7Sfcd4tvDRsWUr0o46DeczMZcAlnVB1Hr6QSMKOedL/3hupFvb2uWazx7pVrq/mJLLGkigsvVjB9+RxnV2swQ268le1DHPBIOl45FDKw+QdaKu17dUQJV26lCoZXwkCj7l/hbt3GTg9+dJNdh3E8Jt/a5h4vmt0/E16CvTnuqvlAzNMgYkQoOc4yeM5+dTXU5aVOWVpJadWSRsdTtEpLYGOTj2AH9NTQVd+Ae5xIdqlnqPc6IFKyRkQtj5IH/nVX8Ub7JsO1w/SEDcLgJR+4ijHGQD6nVKr7J4g3eA7nFXtWU5ImZ8s34ZOT/TRbRkSSiKPJ2q6nJAEch06H/I69SvLICIS59O2capvgTxJZs202fdZWlWXKwSyHLxP6DPcg9tPvEM9iGptklSv9RaXcYgkPV09TdLjBJ7DPc6aaZDoQ3QzDoVcOgqo4wNVbxf4123w0RDMHs3mHUK8WMgehYnhR+vxrDa7Qr+HJ9yEyDebMyQ25J4SzrN1BTEI15PSDhVzg8EnknXAdy3Ga7LZ3G2xlsTkyuT6k+nwBwPgDVfGVzRaMupXWbD2czH1HGqeFuvn/AEurVf2uxtOoubLJHD6tDZEjD/pKr/fVu2S/V3Wt9TQlE0EsciqRwc+xHcHjtr5mp35JLCpIFw3bA7a6L+yzc70HiNNqoPFH+8MnzJULiIopYsFyMkqMfl7ar4XF1DUyVLytPa2xsMzDHEYa2XUdfVd2ruHgjYHOVGtmqlX3Xcxak2zzai2TuMlYWBBhVjSBJCQmeWPV6nHJ9tbI943KeeLbFkrJe+ukqPaERKlEiEvUEzwxDKO+BydamVchnCs/UuGIdSFJU4YHBHcfj8a1edI4BrwPID2Y/aP11TPDzyxbhFDYEE8r79bV5DFjBFdj1Lknp7e/YnTLxzttW1sk9m5Upz2EMKJK0Cl1XzV4DHJxyePk6UXhLMSJVg8m63PVGnwFzqaI2ynX2+BoaVStVh6yeiCMIuffAA51NCUVyb9o1eVo9nuFT5YrCq2OyuhOfzz+mrL4Z8d7PU8OVYLjSRWK0QjMaxk9eBjII45+cabbzRj6JxYg+p22cgzwj+JT/wDYnzpB/wAs6dopPR3aT6V/uUGIOSP9WR/bUgc0iCoi1zTLVU/DKvu/jqCxEnlqbRtsB2RQ3Wf6emr/ABXaSxR29zKxxSXw9YyFseYzN0fw/BPfjQtTaK9GKWhsaO0Dfbbuty0mP/jXHYe+NZeIKUN7b9vpScQzXkiPT6AxyDjSJDroBuXXVNN0TZPMLbqpr2L9iKqGR3DSTKf8Mjp7MP8APx6AnGuG+NfDr+Hd7nplCaUhZq0h5DJn+HPuucH+h9ddInksbtJQtXoysm13qlJuMB7JsJ5rj4wqYPsx0H4h2p/Ek1+hctUoNx/eLLX8+zJ5sadWECxAY6SnORxySfXFTF4bfMgahbOx9p+Ar5iOF1j8+S4/DUhhfrRefk9tdW/Zv4Nsz7TJvEtdPPmK/SLLI8JEY5Lq6ZKEnGDg8D2bVN8KbI25eJa1LcIGFeK0sFxM4w2WHlkjtnobt6A66nvMleuN+We1NX3SqFTaIVnYHpES+X5a5+/qfqDd89jqngMOSd67yW7/ACPabWs8JR53PcBN9s2SnT2qePdZAssl36oyrPIDFK3TGvTKcMSRgZ9Sx99NW2Gh9ClUQSqkcpnWRZXEokOcv5merqOSCc8g47aXePIIZ/DfXeRR5Vis7EtgIDNGHJOe2M/hpNvk1dW3957ssO6QdI2mJJ2BZfKUx+WoP39UnUD3z2PGtXVcaYbaFbKeyUKZiNeqweKZ7Ks0ru3mMhRmJJOSVJ7++e+irdOK7WevahMkLlSVyRnBDDkfIGqbvP70/e9zbqhmWVcbyhUnB6UC+Tn2Mq5x7E6xmvR2Nso2rUojh3W5NZVrVhoYFjCkRhyO+UVSFyBnJ9NKEsw0hX5XcZ+319tTST9n1l7XhSs8s3nOss8fV1FvtWZwoyef4QO/ONTTSITwZEpqRkYPbSyTZKzO5SSxFG5y8UczKje+VBxpprXMZAmYlVmz2JxkaCJQ8yJWqLBWUJ1YRQPTRMcaxx9CjAxjI4OhkYyWRJMpiVBhQ3qx9tGaJQQNqOWIBorMuSQoVjkc/roeT6yI5kUtgY60+7j++jbfLV195AfyydZ+eq/zFZP9Q4/McaIKBCr+21a1GxdsUEWKa5IJLDqeXYDuf1/Mn10UskiBRG5Toz08A4z7Z01lrwWAGZFY+jjg/mNBy7dIvMEgYf5ZP9x/toggWQdmcZJlCpNNFnp7HuFPB/FTx+uiodzyyCZB1LwpAwR+AP8A40LKrw/zo2Qe55H568IDDBAIOnQCmyQnUNpJRiOTn/L2P5azcB89YDZ9xnVeMQ/9pKn4Ot0dq3Ae4lT2Pf8A/f103L0Tg/qmzRzZ+21KB7cHU0Cu8RAf4sbq3tjU0IKMhHJYjIHUwRj3VjgjWwuoQsSOkDOdekAjBGRoW2kMcbuzLAiL1yPjgKPf300kC5TgCbBE8OoyOCOx1r8hB/B1R/6Tgfl21R9y8df4pXb6MLRqeHsgsT84BGNH7D4wg3G1FXvRLVnY4SRCfLYnjBHprOZtbCvqbsOv+lpP2RimU94WW/aszRSebG7v1qmTjp5PGtqTRucBh1f5Twfy15L5zRSLXeKKYcAyxlwpz6gEZ4+RpNtlq/ZkvHc7G3CtUmkhfpqOpIVQerqMhC9/Y9tXnVMrg0jX8Kg2nmaXA6flNYkZut436AWOBjI9u2s/MkT+ZHkf5k5/TvpDc31YNj3CWi7+dBTazALEDJ1qBwwB7jOPY8j304ubpTrLuUkruFoKHnwnYFerj3403xFMk3+3+E7w9QAW+2+QsrNhPpnKMCT9vyM61Jt8TwqW6kkIyWU4P+2gd93bb6k062GnZaa9Vh4oGdUyMhSw7Ej+47aMkv168V2UzuYqcwglDR5IYhCMe4+9dO39O4DtPvsU3cVLEt1++4WqSjPH/AVlH/af9v7aGLdLdMgZG9mGNM9yvDbqNuzNGxFeNnA9HPoAfk4Ggq27p/w/Lc3qNI5azmG3HEhdVcMF4HJwQVI+DonENY7K48pQGHc9uZo5x5rVqalm/sNYRfXWRRklTzFhnLROFyRkr6djqaRxVEauHqEhhKx0afQp9qp+OppF8P2QmfvtJE/+kL1D9dWsEEZByNJN+rRMk6Ww30NpQkjqMmFh/C/4e+ocXSdWoPpt1IU2Eqto12VHaAhVXbrdBfCMjyTSCzChr+WE4LMtjp5/CVv+350L46nqT36Em2EfSfSKsZVSowHcdjz3GsL3h7eKNeWqlRrNeWRJRLApfq6QwGMdhhz3HtomjsFqSOrPvsf0dCqvlgMMSS5dm6QvfJLEemuUyYiq3wu7gwOR1B69IXWZ8NRd4reSJJ1GhHTrOivFCSaaOs5fEj1IZJAwyOojn+2hztbyVd5oyyIF3GSZ+pMkojoEGQfXOeNb6ylYJ79rrgZ8MUQFiijAVekA5/LQ29SWV8P3LtOV+tEWyjKGRisbBipU4PIDAj1zrrKga1nFcgetlyVMuc/hsCfS6XP4fmm225WlgqV7ctN6sUxuTShmbGeGH2rwDjk/lyR4k2vcJV3uOp9H5G6RKnmzyshiYJ0n7Qp6sj5HroS1v81fctz3ETM+2GCWCsmftMsSBwQO2WJkH/QNY9e47davJ0x3fo9tqyT/AFU7ZZlEpbHByWweT7DvqhNE8IB6Ej8HoOYlX4rjiJHUA/kdTyMLX4qNivDv1Oma0371YGNXdll63jRCqp0/eMKDkHjnPblnum07k7brWqim1a9ajtGaSVgydIjDL0hTn+Xwc+utG77rajpbzNtRELwwVnDSOzYVgx+1eQD2/H+g1u3jxP8Au+1ZgdKhlpxJJOrylWlYrkrEMe3YnuSB86J3UuL3GP8AVu/skBVhoY0T/wAbft7plvVBt4SrEshSotgSz9JZZG6eUC4HH3dJJ4/h0uteHZgNxjpWAYLiwuwsyuziVHGTnB4KAD8VGl+7TzfX+Ib8ixywU6KGACR0ZFZHP2kHgn1Pfto7efE0W3blfhRYSKXR5qSzESS5UMRGuD2Ujv3PHzp76lBxc6pbl3HsVGynXaGtp359j7hA+NvAP/E+8LfF818RCIqYurOCTnv86mrH4bkMlvfsuzKt/C5OcDyYjx+epoHZ2FxBNVzLknmURtLFYcCkx9gByCXxjABTKE+qHH9tZzW5o4my3mKeOlwCP99TU1sFYwKnhu5LFuz7cpH0vlmVVPJQ57D4+NeUpDu262nugOtZzHFHj7V+ce/zqamo1KE2lj8mJmhZ0wOwPH5a9pn6qqFmAZXXoYe4IxqamkbhLQoJfC23jZqO0kzGtTkWZCWHUzBiT1HHOckHj1OiLW0wTT3ZGeUNfgWvLgjhVEmCvHf7z3z6ampqi1jQBA5DsVec9xJk8z3C12PD9VqV6IyT4tQRwueoZURqQpHHf8c61S7axmgsQ37cE1uNEsNEUHm4XhjlThscZXH6DE1NQVuESPtz8lT0eIwb/wCR8BFXNjrXV3VZXmA3CJYZelh9qqCB08d+fXOtF3bf/VDNXuWqptsBOsRXDlQADypIOABkEcD351NTUlYQ0kaz7lR0DLgDpHsEwo1I6Ut2SJnJtT+e/URw3Qq4HxhB+upqamrtMQ317qjUMu9Oy//Z: Live location: 12.9851897, 77.7483758 — https://maps.google.com/?q=12.9851897,77.7483758

[6:07 PM] **You:** Aaj to bus hi nhi aa raha

[6:07 PM] **You:** Kadugudi me

[6:07 PM] **Aashu:** tm kadugudi metro me ho

[6:08 PM] **Aashu:** do kadugudi hai swati

[6:08 PM] **Aashu:** hopefam se turn lekar right aayi ya nahi

[6:09 PM] **Aashu:** tm galat jagah utar gayi ho

[6:10 PM] **Aashu:** ye bus hopefam tak hi tha lagta hai

[6:11 PM] **You:** Baith gayi

[6:11 PM] **You:** Aa rahe ab

[6:11 PM] **Aashu:** okk

[6:11 PM] **Aashu:** aao

[6:11 PM] **Aashu:** _This message was deleted_

[6:11 PM] **Aashu:** hum meeting me hai

[6:11 PM] **Aashu:** lekin try karenge ki aa jaye

[6:11 PM] **You:** Nahi aaoge

[6:12 PM] **Aashu:** aayenge

[6:12 PM] **Aashu:** 1 se 2 min wait karna

[6:12 PM] **You:** Okk

---

## August 4, 2026

[1:15 PM] **You:** Wo bus nikal gaya tha

[1:16 PM] **You:** Mujhe kadugudi jana pad raha

[1:16 PM] **You:** ☹️

[1:36 PM] **Aashu:** kaise nikal gaya

[1:36 PM] **Aashu:** 1:06 me chor diye the

[1:36 PM] **You:** Phle hi chala gaya tha

[1:36 PM] **You:** Aaj lete ho jayenge

[1:40 PM] **Aashu:**
> _You: Aaj lete ho jayenge_
jaa

[1:40 PM] **Aashu:** pehle kaise chala gaya

[1:41 PM] **Aashu:** pehle nhi jayega

[1:41 PM] **Aashu:** jayega to late hi jayega

[1:51 PM] **You:** Fir show hi nhi kar Raha tha map me

[2:09 PM] **Aashu:** pauchi

[2:10 PM] **You:** Hnn

[2:10 PM] **You:** Just pahuche

[2:11 PM] **Aashu:** good girl

[2:21 PM] **You:** Hmmm

[2:21 PM] **You:** App pahuch gye Ghar

[2:31 PM] **Aashu:** haa 2 baje hi

[2:31 PM] **Aashu:** class start hua

[2:34 PM] **You:** Nhiii

[4:05 PM] **Aashu:** jaa abhi tak nhi hua

[4:34 PM] **You:** Ho gaya

[4:41 PM] **Aashu:** good

[4:42 PM] **Aashu:** baith gayi bhai jaan bus me

[4:47 PM] **You:** Haa

[4:48 PM] **Aashu:** kaha ka bus li

[4:48 PM] **Aashu:** location bej do

[4:50 PM] **You:** Kadugudi ka

[4:50 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAAAAQCAwUBBwYI/8QAPBAAAgEDAwEFBAgEBQUAAAAAAQIDAAQRBRIhMRMiQVFhBjJxoQcUI0JykbHBM4HR8BUkQ4KyNFJjouH/xAAaAQEBAQEBAQEAAAAAAAAAAAABAAMEAgUG/8QAKxEAAgECBQMDBAMBAAAAAAAAAAECAxEEEiExQQXR4VFh8DKBkbETocHx/9oADAMBAAIRAxEAPwD9N0UUVCVtJsfDjCno3h8D5VIsAwU9SCRXSAQQRkHwqhokjmhKDbliMA8dD4fypAYooqEkiRjLsFHqaBJ0Ur9b38W8bynzxgfnVttL20W4jawJBHkabBctrh5Fcd1QZdgo8ycVyORJASjBgDg4osNyuRd6Mp6MCKUst7RlN+3aeQBk/wB9aeYYake9HesqkKJOemf78fzrCOzienwxgQr4tIT57yP0oo7IfeeQnz3EfpRRmfqNvYruLp7bSLucKpntoZG2t03KpPPpxWbZe0MlzpVjOYY47x7qG1uoGB+zLdSvPQggg88GrV7a+sJLZiqzXunKdzHjtGQg5+X5VVfezss15o9xbTRxS2zQi6U52zJHyCOPeBzj0JrOrKrJqdPZr99jpoxpRThU3T/Xf9mimr2Zv1tiZhumMCytCwjaQZygbz4Ppxis7RddS/isUuhKlzLNJGr9gyxOyl+6G6Z2jP8AI+NUHQ9Qk1e3nnFrIYb43JuXuHLvGS2EEe3C4DAdcd31NN2+jz29ho0Tywk2N49zIQTgqRKMLxyftB5eNeYzryle2nleT3KGHjC19fD8FcntEk2p6TBp4kaC5umieZ4CEkUI5Oxjwe8o58fCvmta+kLStMiQRQjUtSZNx2L2caHnG7JODjHAyfhmntTstU0n2ftZU+pGHQYpbiKXtWLTKsLhO5twDyuRnzrwG5lNvbl/ebzPiT4muaeJrU9932X+3PtdN6XhsXeUvpj/AHq9/tY9esvpe/y7C/0jZOIjteCTehkxxlSAQufIk19rpGuxS6TY30ys8t7bC5aO0iZwuPebxwM4GM5r8yWF480pSQDpkEV6j9FwvtQttQswIp7G2ClY57h4lieUnvAKDu9w8cck46mvNPFVs2W93Y6OpdIwsKP89JWSeuv259z1S713T4pYgGuZ8W63oMEDSDsm3ANkeHBPnVer65bWUNy9q0lxN9T+sL2ULSKgIOx2I6A4/IZ6VXpOi3FtCY5JrcsNJg087WY/aIHyenu98fPiqX0PUra1mhtRayrdWEVrKzyMnZOiFNwwp3AhunHT146nUxGXVb+2x+dVPDqW+3vv81NHSNQa+CiV4zILO2nZFjKkNIGyc5wQdvTHGPWrb9SFSReqH+/niqNH0mbT5pJJniYNZWtuAhJO6IPuPI6d4Y/anpk7SJ18xWlJyik57+exhXUXJqG3g4J4sAmRBkZ5IFFK211HHCFfII9KK0cLO1jFSvyUTtOujapeNmGd7eR0C8GIBDtAPgR6eNZMOq3jeyYse3k/xksLJZSx34K7xLnrkRd7PmK2rm5iubWe3mhnEc0bRsUK5AIxxz60rHa6amox32y5EyWotBnkbf8AuwB72MjPkayq0aspXjpx9u/odNGtSjG0vW/z29RZNdnsvZ3RpHNvLK+nR3DvczNvlIQZAABOTnljxz41o2erXF/qRitrSH6mtpDdO0khD4kDkKBjH3epIpRtO0/sreO31C+tljs0sXKqMyxL0BLJweTyMdT6YbtLXS7eOZFuWkE1pFZuJJFGUjDAdAOTvOf2rzCniE0nt4Pc6mHcW0tX37GLLqZ1azv9OMNk8kunSSq0crSIijCspJGCcPwy8GvC9T0y4sJBa6jEVZ4klUnpIjDKsD5H5EEeFfoWx0+2hljmkvr2722zWSrI0YAibacYVRzlRzWF7cexsepezcLwS3E2pWEHZWxYp3wDkI20DJI7o9cGsKuGr1Fee6Pr9L6nQwlTIvplvv8Ak8Jht4rbcyDHmSfCvWvo5sNS0TTdYnNvbydtZwXzxyyFCI/tSqjAPJAJ9M4rB+jD2TT2kuJ726kljsrUqF7PGZJCM4yQcYGD0z3hjpXstvottDbzxdpORPZx2TkspOxFZQRwO93znw6cVlh8PVbVRaf8Z3dc6lSSeEjqtL/lMztb9oxpitcJFbmEW6XDI8p7WRTk4CqDtwPFuCfhmqr2aQavfqJH2jWbNANx4BhjyPhTVx7P298t5ALu9t4Jo1t544yn2gVdqtkqSDjrjAOKam0+1e7ndjcNPJdRXZAZeXRFUeHAwoz8q65Uq8283zfx81PzkatCCWXfyvPzQu0S4+s2ty21l23lxH3pGf3ZWXIz0HHQcDwpsjBNV2NpHZRSJCXIkmknbcQcM7liBwOMk4q18Z9a3ytU1m3RyTknNuOxk3adnOwyQD3hiirL++W3nCGPecZzjpRXRGU7LQwajfcWcSRvseMhsZ95en51zceMo/PAwM5/KtKAR3NxI+0Mm1QNw+NduII43gKIoPaAcDFelKV7MMq4M0tj3ldfxIR+orhkQdTj4jFampcJE3k/9/pTlOYMh87vhI96Mg+ooEcROQiZ8wBW3PCpDuCQ2PCqbe3hljJkhjYlvFBTmLIYOmaVZaXA0OnwCCJnMhVScFj1PWnAuOjOPg5/rWjHZW7mTMQGGwMEjHA8qglhE4Yh5VwxHDZ6H1zQmkrIZZpPM3diBQHO4swPUMxOfzo7NBjCgY6Y4p9tNb7lwf8AcgP6YqB0+cdJIm+II/rTmR5ysT93pJIvwcj964drtzIxb1bJ+dMmzuh9yNvwv/UVAwXC9bd/5EH96boLMr25Zmcl2JyS1FcZ9hw6up8itFK9iNLS1wjn8I/9RV11zJbj/wAmfkaoCxxg9jd7c8kDDDPwrq8yI8kzybeQFiIFZ83NFtYlqgzbceBpsHIB86TvpN9swCOORyVx4imbc5gjPmo/SjgVuSkGY2HmDVNgc24Pqavb3T8KX0//AKZfiauC5LIfel/H+wotv4Z/G/8AyNEH+r+M0W38M/jf/kaiLaKKKBCiiiojJ1OImdeM939zRWlJEsjZYDPTpRStFYGrsg/bOhXs0AIxy/8A8rqicKBmPgepqH1uM+6JG/Chrn1sl9iQSlsZw2F4q1LQLlJTbybnQgDOAmM4/nU7I7rWP0GPy4qLG5kUjs4kB47zE/pUNMObcg/dbH708ByNt7p+FL6dzaIfMn9TTNL2KGO0iU9cZ/PmjgeScH+p+M0W38L/AHMfma7CpXfkYyxIqNt/DIPUMw+dRF1FFFAhRRRUQUUUVEFLtxfofOMj5iiilAxikrDiS4HgH/c0UVLYnuO0UUUCFUw8Szjw3A/IUUUkXUUUUEFFFFRBRRRUR//Z: Live location: 12.9561973, 77.7126305 — https://maps.google.com/?q=12.9561973,77.7126305

[4:51 PM] **Aashu:** do kadugudi hai

[4:51 PM] **Aashu:** [Image]

[4:51 PM] **You:**
> _Aashu: Image_
Suddenly itna gyan kyu

[5:56 PM] **You:** Kahan

---

## August 5, 2026

[1:18 PM] __[Call]__

[5:44 PM] **Aashu:** hello

[5:45 PM] **Aashu:** location bejo na

[5:46 PM] **You:** Aaj bahut jyada traffic h

[5:46 PM] **Aashu:** dusre taraf se aayi ho

[5:46 PM] **Aashu:** location bejo

[5:46 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQFBgIDBwEI/8QAQRAAAgIBAwIFAQMJBQYHAAAAAQIDBBEABRIhMQYTIkFRYRRxkQcVM0JScoGhsSMyNmKyFiQ0Y3N0g5SztLXB4f/EABoBAAIDAQEAAAAAAAAAAAAAAAECAAMEBQb/xAAvEQABAwIDBQcEAwAAAAAAAAABAAIRAyEEMUEFElFhkRMUMqHB0fAicYHxBjOx/9oADAMBAAIRAxEAPwDuXilWtU9vhkqRWQNySPypmHGXAcdeh+Pg6j69uTZl3WGOpHWsfbKyxVI1MsUIkGA6hcE5wx4gDqB9+pyzWVtn8zeI+aQlreK8zpLzAJ9HEg56kYz76xpVtqtbXKkVYqk0/GwJ5y0pdGxy8wsSSMAgg9PodaWuAbBFl1MPWaKAD2kifUHj6flKtu27eXHCq+VJJfjrx2bFNo+cbISfQSOoII6H40NuV+SQUC9Zrg3F6QtGHp5YgExbhnHLHp+Pf6amaVHb5FRIW+1NFMLAZ7TSuHAwCSWJ6A4x20nutSlZ2trFM1CJ7az+bJZeJWl6R5WRclG6AAgEH466gc0mIUFSk527ueQz0/WSSTdb6RWa0s8H2iPcDVRoqpZ2QQo/pQHHLr1JOAM/TWqluU1+7s1iyiieP84RN6OPLgQoJXJwTgZGdMbfsFevV8q7IpnktvaZ4bbhoWKhcCTIZvSMEnvk6kdmp7QYY5triLR12kKSOZeOZOrkF+jA4znqPx0S5gyHyE76tFgO60nnAi4I81GR7pOdu2KUpFyubdJZlynTmsKMMD2GSemtm0T2zJsS3DUlbcIZJ34VwnACNCqjqexJ6++dMwbPslOWMgrlUeGJZbrMERhgoilsAfd9Ppp21tVOevUhaOSNaoAgaGZ43RePHAdTnBHTvpS5mQHy6pfUoCwbYzeBzjXSR0SFCR932oJbKiO09qq4RQBxEkiD+QGq9t9+axNtW6TOVj2dIqtrr0MkmY5c/ukRtq4Q7dFQoV6+3wGOCGTmq8i3dizHJJPdidLzUttjq3qvk1hSutJLaBmwGZv7zE5yP4dsajXtBMC3z0UpYim1zwGmCbcgbHqLKv7ZBblteHJYJkrWbte9ckd4+ZHmyRPjGR1wVH3DTdLcLW5yUmbyIbT7baYzpECVZJo0PHPYHqcZ+PjU5VNOyKd6tGSIY2igco8fFDxyAGxkelev0+/WdPb6VZongrBWjjkiXLscK7BmHU+5AOoaom4v+1ZUxLc3tuJ0GpdbzHTrXdt3WKnsGyjco5LliWjDKZScHBXoD8kfPvo1Ztvp1qFOKrXizBEvGMSMZCq+ygnJwOwGjSl7CZhZ31sO5xcWTJOseSj/ABFQbcI6aiv50ccjM3liMyrlCoK+Z6fc5z9PjUdU2WWn9mkn26O5XjWWNKoaN2rcnBAy5APp79ememQdSW737MSVhtrw+ZIzjEqHqVAPUnACAZLHv2xnURWMdC/YFJ69j84GF68mSI1WR5WDOAcsc8sHPXIAxjTs3t2FooGp2MAjlnxjObZ/7zWdPZNxgsbfElWlEsDLIlmJVzF1bkhbILDiQgHHB7k+2k4Nl3aDZpKDQWHkkw3WzGEMoHuuesRxk9mP7OpWC9uW5Xkq1bMFOSJZhNIsIlR2VwilcnOCc569OJH11E0d3tUoaEViQVaK1PRM1dpmyBhiOI/Vbpg4HHHzpwXngtDXV3T4ZsYvz+QJ4qT3HarUyubFCk8jyeZHKqRqazCQ4LHOWUrgn37gjr0gPEHizZPB1e3tOzxPZuODlQwKRHgFXkT8ADpgnp10ze36XbPBtRoZlR49ueUcovNZ5FHpTiOiDo2c9gMex1we5O0UTyuTJITksxyWYnqTrm4/E1KADG5ldHZuzziS41z9DTkJv9+VtF0Kv49pQtX8nYa9Xyqxrl+lgOcrh2XCkkYb3ySx10zw/ulKrtTc3SOAqbkKRsrKsUjtxQYJx2Jx2GcZwDr5noXHmlKSAdsgjXW/yP113KHcKjyIhqOJosxq5/tQVfoe+PLUjuATkjtqnCY19R/ZVrzqtO1MBhxh+1bIaDfM+/HzV+k265NeNhIWineZphekcACEoeMRQnl0yAVIx0JznUZN4eNgbUj7ZXq1YOAkJeM+Z28xmIOeq8gD6icnPHvq5QwpDWigTkY40WNeRySAMdT86Wh/4SHl3Rwp/HH/AN66YrOGS8sNoVGH6PX35/YaLVQgrUaq1qSOYlYt85J7nPbT8WeHUEE+x1lo1QbmSsj6jn3cjRo0aiRRNmylmAxWaUUoB5KHCyKG+cEa98yj9lmhWvBH5xBlVq44yHPUtgYOsGr2E7wk/VSDrUzcP0isn76kf11aOSUVHgRKerTLGEWstBQihFWLC8Vz2Ax0H01hcGVhWWnVZIyXjBRWCkDORkdD76T9Eg/VYfjoEaDsOP3dNSLyp2rpmU1Yo1b8dmrZrQGO3B/b4jUFyemScdx1wfbXzr4i2Wxsu5WNs3BMvH2bGBKn6rj6H+RyPbX0COYbkJZAw6A59tV78oWzN4g2VmRFa/VBkgYLhm+U+44/HGsWNwxrNkZhdvYm1e6Vtyp4HWPLmuFw14q/JkGPkk67x+Sbw6do2Vr1yFVv3Dy9S+uKPsF+hPUkfXB7aoX5K9mi3HdDuduFpqdMjy06YeXuM5/ZGDj5I+NdjSaAZBksxKSTxx0H4Z1mwGHP9rvwul/Itpie50shn7e6lNJp+htgfquxH9dYFqWMvKzfvM2s9vaNo5liIKczj7tdPJeTTgORnRrXWOYI89+IB1s0qKNGjRqKJdppGldYYwwToSWxn6ax8+Z5fLSII4XkeZ/pjWdNGWIlxh3YsRrxPXfkb9hAv49dFBapIC/6SpA5+QcH+mtLVPiCVP3ZQf66k9GpKkKo7ru0O1U4prJLc3CgDufk/wABqUrxTWIFmh8po2zxPPuM4+NRm50ft1SONVjLJKrAuOyhwSPwGp3bgBVRUlEeMjgMYHU+2rCYCraJKi9s2VNprvBQoiGJnaQrGwILHuep0hvke9iGwaSxrHgcB5beYO2fVnj8/wANW2STyImeZwwHbAwT9NRdiZ5vVMwCDqEz0H3/ADpW8Aned4y4yUhtTWnpINw4PP7si4X+fvpsxoe6L+GmIKs0w5dIk9iwyT/DWdmkIYvM5u+D6gTjI+mNNISbpUTvV9dm2Lc9z4l/sdZ5lj8wqGYD0g4PbONK7r4j3Xbdx26qmyvZXcPTB5N5eZcRc3DK64XGD15dhnprf4i2d992DcdngmSKSyyx8pc44LKCw6e/FSNObvs9u34s2XcIzEatGO2zEtgmSRVVBjBPbl10Lao30Vb8S/lT2zw3uI2/dKW6C4IkkkSOGKTyywzxLCQAkfTpo0hvf5OL3iPxNvW427Fqmj2VSBUaPDxrFGobqCRkhvw7aNMAzVAl82XUZGKoSqliPYe+lK8wiMhmSRC7E5KnGNOghlDKwZSAQynIIPuNe4/pnGqpViUrus1qWRTlQoUH+emtGjQKKgl6Fx8O3+o6kduVGopzVSPV3H1Oo9v0so/5j/6jrL1LSLPL5VdFd5mdgFVAT1+g6Ek6sNwqxmieRZXygCwr/dAGAf8ANprb6wbE8q/VFPt9fv1qrVvOmw2DCmCSDkP7gD6djqV0CYsEQNSg9BnSUjzWoAEi4q+PUW9s/GnT269tIxcGd46tiR/Kk8l+JBEbYBwenwwP8dKExS9PP2/r35vn78nUtqt1N52dbgY75tLZZu1yPJyT9dWUjBIPtouQavNGjRpUypskt6SPcvI3K1WjobPWsQxxcceYVlOTkHI9A6dj+GsLVmxT3Led4iklkspsMVoRs2U5EzHGP2RjOPv1Y91lqUtrt7iUiNVK2ZRDEj+bEoOF+CBlsAnHU6TrWo33eOKbbHq7kldvKFmKPk0IIDKjRswwCR6T86cKuFE3bm91Nq3GXzrSRGkssc08sLuJeajkgQ/3SD93Tp30/chuLvL7eN43ERQ7f53MMnN5DI3Unjjp8AAYA1tgo14UtLW2/ba9ZjidUSPBA64f2AHfB/DTq+Y8ryJHBJL+id1CswGc8SR7ZPY6Kiq9zdr0+zRWq1idbSbRFfnEJjijWR1J5sWBLZKn0gY6fUayvvNHc37cY7Ey2P8AZ5LAAb0qxEx6D4BGQPqdTbbdV3DyT+b9rsCvHxhLJGwRB0CqB7Aj7hryy1KKCCzPSqzo7R7fGY0RgEkcJw9xxGeq6iEJW5atzy7w35zmorttWKSIIECsTGXMj8geQyOOO3Q+/ZS5f3KzV3y8L9qm9PbYbcUEQUIshiZzyBBJGVxj/wDMWS7Ro3JIpLNOlZkibgks6IfLOeij+OOnzr2XyZGsIyQSvMBFOD5X9qOq8WB6kdSMH7tCU0KueJt3vRm/aoz2B9hWDmqsiQxs4VipU5aTIYfGMgDrnU1sHS54j49Mbmcf+Xh1lPtNO/aEl3bNvllUBHeWNJH446LjHTofw1nLutWq24SCqRBFYihmmiUAyTyFE7dM8QyZbP09tQ8ApkZKQoSufFLSO55nbl9X/juNJ7buO83r62UE5iG4yV5EaWFYViWQpx4558gAGz3J+h0zLuH2W+tMbPuD2JI5RHKv2bLxowz6jKCAC4ODjv2762S3KEe8XLKeHrM9ykVWe5HDAWQmNW/b5EhWAJAPuBnRQWWwwz7xtcV+1uO4LNMXLRwSBEjwxHAAD2xjr10ar/inxP4P2vcY/t20tbltwpbE8FeMiRX7MSWBycfGjU3SUN4CxVl8bRpD4L3qKJFSKOlIqIowFAXoAPYagvE0LbLbsS1LNp5LGz3jznlMrRmNVZSjN1Xq3Xrg4Hxo0aDUXqnUNxe3tu8KIa9dE2aaLjBHwDAcSC3yR1wfqfnVt8S1a9O1utenDHXhl2+CN0hXgGX7Rw64/wApI+46NGnOaQZLb4mr1Nru749WlVWNdnVzCE4xuVlbGQuM9gPqBjtqJ2yZpnvlgij857YeMaBFz5oGcAAZ6D8NGjSjJE5qXkP+4uPY+JE/90msUq149rlsRwRLYl8SAPKFHJgL2ACe+jRqIqw7T/iXxD/1a/8A6I1CTf4T3A+530//ACCjRo0Bn0ROXVNXf8Q7d/21/wD1w6yobZJuG+eJVG5XasJniR46/lgODWiz1ZCwOOnQjRo0Qg750XKvy1VoqfiurWrIEghoRRxqP1VBYAfgNGjRq5uQWd/iK//Z: Live location: 12.9880733, 77.7323023 — https://maps.google.com/?q=12.9880733,77.7323023

[5:47 PM] **Aashu:** lafra ho gaya hai

[5:47 PM] **You:**
> _Aashu: lafra ho gaya hai_
Kya

[5:47 PM] **Aashu:** galat bus li ho swati

[5:47 PM] **Aashu:** ye office ke taraf se aa reha

[5:47 PM] **You:** Haa

[5:48 PM] **Aashu:** [Image]

[5:48 PM] **Aashu:** issue aa gaya production me

[5:49 PM] **You:** Jaa

[5:49 PM] **You:** Aaj ka leave waste hua na

[5:49 PM] **Aashu:** nahi leave apply nahi kiye hai

[5:49 PM] **Aashu:** ab nahi karenge leave apply

[5:50 PM] **You:** Fir aaj aaye to nahi na

[5:51 PM] **Aashu:** use problem nhi hai

[5:56 PM] **You:** Accha

[5:57 PM] **Aashu:** yaar aaj interview to ekdum bakchod jaisa gaya

[5:57 PM] **Aashu:** gussa me interview chor diye 5 min me hi

[5:57 PM] **You:** Kyu

[5:57 PM] **Aashu:** naukri par bhi hata diye sab

[5:57 PM] **You:** Aisa kya hua

[5:57 PM] **Aashu:** chutiya jaisa question puch rahi azure puchne lagi pura

[5:58 PM] **You:** Ohh

[5:58 PM] **You:** Waise kisse related tha

[5:58 PM] **Aashu:** hum beech me hi laptop band kar diye

[5:58 PM] **You:** Bataya hoga na jd me

[5:58 PM] **Aashu:**
> _You: Waise kisse related tha_
jd me sara mera kaam se related likha tha

[5:58 PM] **Aashu:** bakchod thi

[5:58 PM] **Aashu:** phir call bhi kiya hr hum block kar diye

[5:59 PM] **You:** Ohhh

[5:59 PM] **You:** Cool cool

[5:59 PM] **Aashu:** aaj yaar bukh lag gaya hai swati bahut tez

[5:59 PM] **You:** Jane do

[5:59 PM] **You:** Aa rhe

[5:59 PM] **Aashu:** haa ek interview aur schedule hai wo de denge uske baad nahj denge

[6:00 PM] **Aashu:** naukri se hata diye ki notice period serve kar rahe

[6:00 PM] **You:**
> _Aashu: naukri se hata diye ki notice period serve kar rahe_
Haa jo h wahi dalo na

[6:00 PM] **You:** Notice period to Krna hi h flexible to nahi h

[6:00 PM] **You:** To kya fayda

[6:00 PM] **Aashu:** hmm

[6:01 PM] **You:** Chill

[6:09 PM] **You:** Aaj bahut traffic ho raha

[6:09 PM] **You:** Yahan bhi

[6:09 PM] **You:** ☹️

[6:09 PM] **You:** Jane me bhi tha

[6:10 PM] **Aashu:** ek survey hai wednesday ko sabse jada log office jata hai

[6:10 PM] **Aashu:** isiliye har wednesday bahut traffic rahega

[6:10 PM] **You:** Isliye aaj sara banglore road pe aa gaya hai

---

## August 6, 2026

[1:27 PM] **You:** Abhi tak bus nhi aaya h 🙄

[1:35 PM] **Aashu:** chalo ruseday se sath chalna

[1:38 PM] **You:** 😏

[2:51 PM] **Aashu:** pauchi

[3:41 PM] **You:** Hmmm

[4:10 PM] **Aashu:** aa gayi

[4:15 PM] **Aashu:** MF 4 mule to ise aana

[4:16 PM] **Aashu:** 334 EH bhi mile to thik hai

[4:30 PM] **You:** Abhi niklenge

[4:41 PM] **Aashu:** baith gayi

[4:41 PM] **You:** Nhi aaya

[4:41 PM] **You:** Abhi yahi h

[4:44 PM] **You:** [Image]

[4:53 PM] **Aashu:** bejo live location

[4:58 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBQECBgcI/8QAQBAAAgEDAgIGBwUHAQkAAAAAAQIDAAQRBRIhMQYTIkFRcWFygZGhsdEHFDIzwSNCQ1JTYuEWNGOCkpOissLx/8QAGgEBAQEBAQEBAAAAAAAAAAAAAQACAwQFBv/EACcRAAICAAUDBQADAAAAAAAAAAABAhEDBBIhMQVBURMUIjJhBnHB/9oADAMBAAIRAxEAPwD6T+5WuyVPu0W2Wdblxj8UqsrBz6QVU+yqXpAbLT7nT+r0m1ubu+upVRpZeqCs0LF2LYPNU2+6rPTtWstTRZNPnFxEW2FlBG1sBsEHiMggjxBB76xqujWusTWD3aJNHZTvL1TIro7GNkwwPhuz5gUkVOm32k6mmlQrparHqdpcWTBmBCRQna0fD8Skk4I7uPfUC+1qwuYbSZdDtppNStbmOXrrgRfsbeQKULbeOS2QOFdFqmlxzyWDW90NPu7Mt93MaoQFYbSuw8MHA5Y4geVV9x0J0y5s7C1uUluILS2uLcCVVLMZipaTOODAqSCAOdQCNa1jSmtNMvLzTzPFrUCROHG1o7Z9pLSf2qZEB8Nxq6lsIJLqWaa2tzK8kcrnacl4z2GPHmO7h3Dwqo1Lo1Y6upk1K5nvnSyWzzHJ1eBx3uQh4luySDw7I4VdRB0to1mueMUarJI4G9iBzI7ieeKxK6+JpfptDbQM92zQxl5ztmbH5gC7Rn/hOKRLHbWhhYW8Y+6RkWvD8vshSo9gA9tO0a5t9R023vrCUz21yolRyMEgjvHcfRSr5WmMKxhXBy4II448PH/FPdIO1kGMQQdXKtrbq8LyTKwU9l3zvYceZyc+dS9LsbS3t7RoLO3gaASGERrgR9Y258eZ41DZDK6xgEjmwA44q2EqgAbZBju2H6VYraVRDD35M28MVtF1VtEkMe5n2JwG5mLMfaST7aYWJpXXJ/d/ymjro/5vhXCps67G5APMCilm4iH7/uBNFGmRWjzXoNeWWlWesteX9ta2dysEsawSRMYpJMxO52IgTB29jAK4PDnVppnQeay6HLp8Q025vLqeJrmWZRLCY07KyKmFG7bg+kk8Tzrq9c6PabrUEcd3AqvGwaOWJVDqQCO8EEYJ5g++n2irbWkFpDuSKAiAEnLbQMDj7q9XJy4POf8AQl6Fv5YdC6OAvLDutuy4cKGEpjdlzEGzHw7sN38TKvOhV5LDpUl5Y6dr8kWkLYsZ7gxmOTJYSBtp3LhsA8CMZHOkdJtXvk1vULWS86QWlms7RvsjSSMRsrYP5B2qXKKDuckN48nafq2sR9Dr/TbSK5tLjTILBo/u6b5oIZFXerKwO5lCuSMAkEcBSQ7ROhuo6Z0k0mZY9IhgsViMt1ZosUj4hKyIyqo3b3O7J5BR35rhtYmtej+qQaff6Vp+pzQJPFfyRznN71hyrSnbwZThscSDyxwru9FuJbG36aaxbz3t9EsEclve3sXVtM0cTkrt2qCFOO1tGc444rxG9uHiieZyZJWOSzHJZieJNeDN5mWFUYcs+/0PpeHnXLExvrHt5Or07pQIrOS3mtjA0mkPpsssTkrM+AI5HUAbQoBHZycHvrpYOiFzeQaXdaVBo1ssscTyXMcwZ4nR89YmFAXKgdlNoJLbs868l0+9eeUxyAcsgivWvsju5pLTUrHdlInjeIH90ybgR5ZXPtNYymanOfp4h6+s9HwMHL+5y2yXK/vY9RtiWkmnjTcsjHBzjgD9c0/fJ/SPsYVtDGI40jXkoAFSK9a+bbPzP1VCMt/Rf2FfrWCzf0ZPev1qRRW9EfAWxAf/AHMnw+tFPop0x8Bb8ibR+sto2PPGD50iRD96mjH8RAw8xWyrPCzrHGrozFlJbGM91aSCZJ4JZmTG7bhRyz6a2ZG3MFtqdgYL63iubaUDdFMoZT7D4Gkadp9npG2DTLWG1hkJLCJcbm8SeZOM86knMDbhxiJ4j+U+I9FYduuZRFxCsCX7hju9NAhqVtHfWU9rcAtDNG0TjPNWGD86+Z+kGjXGj6jcaZqCZePk2MCRP3XHoPwOR3V9PkZBrjftJ6Ox65oEssa4v7RWlgYc2wMlPJse/Br5+cwfU3XJ93onUfZ4umf0lz+fp8/QW0VtuZBjhxJPdXtn2VaBLptk1xdoUubjErIw4ouCEU+nix9Gcd1cZ9mOhx6rqD6jcrutLQjYpHB5cZGfVGD5keFe16amLfeech3ezu+HzrllMHTH1pcvg9/8h6ipS9lhcLd/4iag45relQEt1meQbA931zTa+lBUj8q3YVoX/ahMc1Jz7vrW9IDq80TqcqUbB9orQDdy5IyMiio7fmy+sPkKKaCyt6ybunl99Yd5nXDzyEeHD6VLlsFQoElk7TY44OOHlWG06UfhmQ+aY/Wt2jFMiMXfO+WVs88uce7lWVklQDbPIoHp+tONldDuibyYj9K0NvcrzgY+qwP602gpmDNcFdpuHI8h9KWWlZCjSkocZB/+1lonB7VvJ/08/KtdyrwIK+akVUgtkPT9LtNMs5LfTYEt43dpCq5xubmatUvJlAAjiwOAAJFRWkjJwXAPhuxWNoP4ZW9hzRoi1VGnOTbk3uybFfPGu0wBhknIfjxOfCnrqUX78cqea5+WarArj+IT5gVsM95B8hVpQamWq39q38ZV9bs/OkWksYW3HWJkbgRuHjUKsFVPNQfZVpHUWFwcTPtPA45H0UVXdUg5Io9lFVBqLub8yD1//U02lTfmQeuf/E02uZ1CiiiogpN2M28nqn5U6tXG5Sp7xihqyIlqu+zUHiDkfE1sLSHYqmFGwMZZQaNMbNtjwJ+v61LrMobvck9ivktLfdHiJQC2DtGO70Vi6soI41ZFZe0Ae2eRPnUyf+H64rS//wBkc+GD8RW42trBpEX7lELkoTIVCbgNx55pFxBAFgGOrDJuL8Tk4qxbhfqfGMj4itrYA2sQIyNoHHyrVhRR3KCPquwELIGIHtoqx1GPdMp4fh/U0VtS2MOJMl/Nh9Yn/tNNpM3CWE924j4GnVyOoUUUVEFFFFREPT+yZ0/lf/H6VMqBOkltI00RBRj2lNSEkldAyRrgjIy/+KX5BeB9IvRm0l9U1uvW7u1sC+jJNbOoZGVvwkYNQkdzm5tm8Vb5CpIAAwOAqPDbKrRyCSRwo7AJ4DhUmpgjRkVjkiit6KBE3XCMHvDr8xTqKKewdwooooEK5XpzqOoadJpp0+9kt1nnjhdVjjYEMxBPaUnPw9FFFKBkqbUrpNT1K1MivHb6NDdpuRc9aWmBY4H9i8OVQJtdvo9O6RyI6BrHQ4L2D9mOzK0cxJ5cRlF4cuFFFQEPWOkWqWuvOkNyBbxPYJ1JiQq3XOFfJxu7+GCKub7WLqH7QbPRk6v7jNp0twwK9reHwDnyHxooqIp4OkGpJ0qW2M6vaPqrWAgMSBVjERYEEANuyO849FXWlaxdXPT3XNIl6s2dpb28kQC9oM2S2T35/SiiokWHQ+8m1Po/b3d4Ved3lUkKBwWRlHAegCiiigT/2Q==: Live location: 12.9562634, 77.7148786 — https://maps.google.com/?q=12.9562634,77.7148786

[6:01 PM] **Aashu:** wapas bejo

[6:04 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAIDBAYBBQcI/8QANhAAAgEDAwEFBQcEAwEAAAAAAQIDAAQRBRIhMQYTQVFxIjJhkdEHFBVCUoGhIzNi4TRTwZL/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQMCBQQG/8QAKhEAAgIBBAECBAcAAAAAAAAAAAECEQMEBSExEjJBBhMUUSIzcYGRodH/2gAMAwEAAhEDEQA/APTKkMoI6HkUUAYAA6CigAoopEkgQgcsx6KOpoATc8x7B1c7fr/Gad4VecACo5bEgMntSD3Y05x60TZEbSzDIXkIOR+/nToQrmfjBEXx/N/qkXJMri3Q4zy5Hgvl+9R4b5+73yLuDe7tHQ/pNRdevTo+g3NySDdSDanxkbgfLr+xrSi7oTaSsreuB212fVbhGOn6ZCZljiIaRkTLcJnPtMpAPiBWgj0CS7ki0m0OgXC3F3+I2esC6C3kaGTvt/d7dzOBkAggEdeOKjau+kqdLTVbdzqC2u8X1pcmC7SIsUijiCjMzswxtPA8etWj7HdAsdJ0W4msUQq0zwobixSC9i2uwkjldSQ/tAYxjj+LSfiv0JxVsu91bGWRnR+pztcbh/qo214OvewjzU70+VbGm7hS0EiqSCVOMV50ytEdJpio2vbuPPcRRS4oYZ4kkaNSzKCTiinwBJoJAGScCkPGrnLFvQMQKwIIgc92pPmRmsjMd+h9zMh/xGf56VHeZAxywQt1Ce05+lZ7sT3MqTM21cbUBwCKcL29t7I2qfIDmtCEwTKrhDE0Qb3S35j8fjWh7X9tdN7NkQTB7m9Zdwt4sZA82J4Ufz8K3sxkuoyiw7UP5pOPkK8xalqE17Lc6jdMZJ5yZXJPifD0HA9BXj1md4Yrx7Z29k22GuySeV/hj2dK0/7ToEv991o0kduTn+lcCRlPngqoPzqxaldL2vvNPGlFp9KjIaSVePbbqMHnKr8t1efrO/kkuAkgXDdMeFb20vrC1tL6LUXKSNEX09xK8Rju8hUYOpG3g5YnjCVLR6zI8qhk5s6O77Jpo6WWfTcePa+/8l5j1WS4EV/NNoshiuzp/wCDGAR31mry91/Rmz3gl53dADyRjrXWLLTU0izjstLVUtYchY3JYkkkklicliSSSepNVzsh2cudP1FdQ1PUbDWYu42295cWaffFfgZE6+8hG7rz05q3mWMdZE/+hXTnK3SPkYr7jX3rZxcRtH8eq/OnkdXXKMGHmDSgQwyCCKiOiLfRCJQGwS+OOMVg0ZtHWNHjYgbHIGfLr/7RWLiyEspcSMueoFFHDAl0VHN0rcQI8p8wMD51ndcnpHEPVj9KKHYqaCOYguuSOhBwazFDHF/bQL8fGlR79o7wKG8dvSlUgCvOXbfs7J2d1ye0eM/c5Sz2z+DRk+76rnB/Y+NejHYIpZiAB1JqvdqtDTtTpMtrLiJR7cEpHtLIBw3p5+YJrzanT/Ohx2jq7RuP0Ge5emXD/wB/Y83w2kML70Xn4npXQvs30rvLs9+jNJf2rtEjRq8RhV1BMgbwdiMAfoJ6VTYbG6cXLFIo3s5I45EuFzGZWlEaxucjClt2TngKevSuzdj7q9i7RjRtW02WxuI7d7lPutwJrORcgFhuw6e0eFI8a8+36Z/nT9ujs/EW5xjH6PD702/7SLFpGlWGh2RtLHS4ra1MhlKQjcm44yQD06dBxWxiNpJwixZ8toB+VSablhjl/uIrfHHNdK7PkKGpLa3VS5Hd45LKSKZtYZSHljkI3HgSDOR4UuWyzju5GwDkI53LS/vEkf8AfiIH6k5FOwM77kcGFG+IfFFOLPEy5WRCPWikAslUXkhQP2rAdSMhlx61Auo9pHesXYjJkceyvoPOo5Ecm2OGLIHjj22+lPxCzYtdKTthUyt/j0HqajSO8jbWcu3/AFRcAerU4YzsAuHWKPwiTx+tOwklALeNUTzb6UdAJS3aQqbggqvuxjoPXzpnXr5dP0yWZuoGAPM1OjDjIcq3kQMVT+3/AGjstGawj1CX7tazuxkvGiEqR93tcx7cctIMqORjHGTxRFWxPhFM1aO0XXLm30+a6t7zU5Fi1GKa0W602SZkMuyTcQ6ttJYlCdo8qvX2d6BZ6VpCXkVhZW93dRqGltLuW5jkhHKFGkOVUg52j4VTV0DUdW7T2t5dW2o6c17x+IaJKlxaSho9pdkkG6F9gClwD0rq9jawWFjbWdond21vEkMSZztRQFUfICtzqKpAm5PylyPUUUVI0FFFFADT28Ltlo1J88UU7RTsDXJZSzv3l5IT5KvhU+ONIl2xqFHwpVNyBlbemWH5l+lF2KqEWqgKcjMgO1mPJNYKsJyiuVR8twOc+NZCyM7MMRBsZ8T9B/NK+7xn3gXP6mOT/qgDEzpa2zv4KM8nqfWuUdtdYm0zSi9xFbpFqbzMx1C2aWMtCFaOIJkDe7dCTjg9av8ArV+9vcJZWax3N+YzPDBPKY0Yg4ALgE/qPT8tc5lhmsO0ep2Tak8L6jdd1FpvamyaazulBOwRz7m8WYgZ/NjbxVcarkxJ2W37NLHTY21K60y2FnLEy2lzHZXDGxllMccjvHHkhSCxTjyPnV3qHotj+GaNY2RS1R4IlWQWsIii3/mKoOACcmplTk7ZtKkFFFFZGFFFFABRUC7u5UmKwruC8E48aK14sVk+iiisjCgkAEkgAckmioGt3K22nysd7EKW7uOMyO6ryyqo5JIBGB500rYM5528v7zUNROnaRdWdtLqNn3ca3sJhFzuzkQ3IJ9vaQChHjweeNh2A0yC0v5e6ttd0FbTHfaTdyd9Zuxzho3bcMhgDlGB45Fc/wC0mq2MmoTxax2i1f8ABb2Qk295ahZLNzzzHLEd6jPBjIZfj1HZuzNt+Edn7TTrzU7jU+7GVublRl1PKjI64BHJ5q8+I0SjyzeAhuQc58aKhxSvtJggUwgkDa2CfjTgu484k3RHycYqFFLJFFYVgwypBHmKzSGFImkEUTOeijNLqNcf1biKHwHtt6Dp/NNANWlxDFDiR8SEkvuBBzRU0qp6gH1FFHAiPYTtPDufGc44qTRRQxhXPPtDuJRrlqiuVEMG9CpwQWYgn5KKKKrg9ZLN6SH2a1C8uNas7Se5llt5nIdJDvBAVj0bPiBV6uLuaGUpu7xf8wP/ACiiqZ0rMYW6Jun/APDi9KkEAjBAI+NFFeZ9l10R2tIs7k3Rt5ocVGtrqU3ncswZfMjnpRRTXQvc2NRrX2prhz72/b+woopIZJooopDP/9k=: Live location: 12.9878215, 77.7539846 — https://maps.google.com/?q=12.9878215,77.7539846

[6:06 PM] **You:** Aaj fir se sir dard hone laga hai

[6:08 PM] **Aashu:** hmm khayi bhi nhi hona kuch

[6:11 PM] **You:** Nhi

[6:30 PM] **Aashu:** yaar tmko to kafi time lag reha swati

[6:30 PM] **Aashu:** mera meeting start ho jayega thore der me

[6:30 PM] **You:** Kya karu

[6:30 PM] **You:** Bahut traffic h

[6:31 PM] **Aashu:** hmm

[6:31 PM] **You:** Traffic ke bich me chal ke aaye hain 500 m

[6:31 PM] **You:** Tab yahan kadugudi se pakde hai.

[6:32 PM] **You:** Yahan bhi aisa hi h

---

## August 7, 2026

[8:54 AM] **Aashu:**
> _You: Video: हम दोनों को दूर हुए 6 महीने हो गए, लेकिन आज तक कभी ऐसा महसूस नहीं हुआ कि ये मुझसे दूर रहती है। हमारी घंटों की फोन पर बातें सारी दुनिया की दूरियाँ कम कर देती हैं। किसी की नज़र न लगे। हम दोनों हमेशा ऐसे ही साथ रहें ❤️🧿🥹 forever wali darling 💖😘

Always 😍❤️_
😂

[9:37 AM] **You:** Green frozen peas 
Soyabean 
Capsicum 
Curd
Milk

[1:59 PM] **You:** Take a look at this Solid Wood Study Table on Flipkart
https://dl.flipkart.com/s/U30ySPuuuN

[9:36 PM] **Aashu:** https://www.instagram.com/reel/Dbsut8ivS1e/?igsh=MWxvdGs2bXlzNG9xeA==

[10:11 PM] **You:** RJ kitchenware Store Appam bada Non Stick 12 Cavities Appam Patra/Appam Pan/Maker/Pan Cake Maker/ponganalu/gunta ponganalu with Lid 24 cm 
 https://amzn.in/d/067UHSuT

---

## August 10, 2026

[2:29 PM] **You:** Pahuch gaye

[2:45 PM] **Aashu:** good

[3:57 PM] **Aashu:** swati woha pani bhi par reha

[3:58 PM] **Aashu:** yeha to bahut tez barish ho reha

[4:28 PM] **You:** Abhi nikle nahi h

[4:28 PM] **You:** Dekhte hain

[4:33 PM] **You:** [Image] Yahan bhi ho raha

[4:33 PM] **You:** Chhata bhi nhi hai

[4:33 PM] **You:** Kaise nikle

[4:34 PM] **You:** 🙄

[4:34 PM] **Aashu:** hmm

[4:34 PM] **Aashu:** pani par reha

[4:34 PM] **You:** Haa

[4:34 PM] **Aashu:** aaj bahut late ho jayega yaar

[4:34 PM] **Aashu:** aaj ek chata manga dete ok

[4:34 PM] **You:** Haa

[4:41 PM] **Aashu:** niklo to batana ok

[4:41 PM] **You:** Nikle bhig k

[4:41 PM] **Aashu:** baithi bus me

[4:45 PM] **You:** Haa

[4:46 PM] **Aashu:** bej do lication

[4:47 PM] **You:** [Image]

[4:47 PM] **You:** Pura bhig gaye

[4:47 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABAACAwUGBwEI/8QAQxAAAgEDAwICBgcCCwkAAAAAAQIDAAQRBRIhBjETQQciUWFxgRQyUmKRocEj0QgVMzRCU3KCseHwFyQlc3WSorLx/8QAGgEAAwADAQAAAAAAAAAAAAAAAAECAwQGBf/EACsRAAIBAwIEBQQDAAAAAAAAAAABAgMEERIhMUGRwQVxseHwEyIjYYGh0f/aAAwDAQACEQMRAD8A+k7A5tEB7rlT8jVZjblfYSPwqytPVadPZIT8jzQNyNtzKPvZ/HmlPga10vsTI87SG+yQfwNWV/xb7/NGDfnVYRkEe2rR/wBrYn70efypU2TavZoi3yR3k4jj37grfWA8sU5kluJFEqGOJeSuQdx+VNibNxbv/WRY/DmpZYpd5eGUg/ZblT+6shtEK28Ul5ceIuT6pHJHcVLYH/dlU90JU/I1Fayl719y7W2YYA+YP+dSQMI7maI8bm3rnz45oYIKoa69We2f2Pt/EUTQ2oA/RWYd1IYfI1KKY64IHht9lx+fH608sTUUw3wtg9xxTRMXAMaFs+Z4FYXKUlsVhJgckklrI0abducjNKinhaQ5cpn3LmlWRThjfiTplyJIiBey4wQ6KwI/Chb9cXOftKKKk9W+hP2lZf1qWWGOUguuSO3NU1lGOpDXFxKiprbVbSPULXSZWdbuaAyx5HqsAxG0HPfAJx7BTtQgWExvGCFJ2sM5+FVdxpLalqj7hJEBYoYLkL/JTLKxUg+0ccew++teq500tG7FZUYxqSjUe2C0t5opEYxFgtlcNBK0mFHABJznt6wrO9WekPTdBuPotvG2oXgGXWKQKkfHG5sHk+wZoHVZ9Ss+ktSvL3TAt0l/LcPviaRIysPDhf6SlhgMcgZye1cPu5jBbtJ9Z89z5k+ZrTqXtTCSW7Or8L8Go3EpTqv7Y8l/p1vTPSlbPqok1HTZLW3bgvFL4233kbVOPhk+6t9Yavaa3YQXNskngyvMEmDLhfDON3fODjyB99fLun3rzymOQDtkEV1T0QzXVzfSWYR3tLRZZAwUkRmVMYJ8smPPxJpUruq5qMn8yjY8T8Gtqdu69usY45fzng6rHrFuuoWOnzeILq6iZ0baNhK5yuc9+Ce3kadPqdq2s/xKPEa8e2a44A2hc4wTnv8AKqLUNOubu8iuLSJzNbWTTQPtO3xVmDBM/eAI+BNe2VpetqVtqstjMbm7tryaSNgVKZ8IRRMf6J2qB8d3vrPOvUjNxS5rpsuvY5+FClKCk3yfXd9O5orZlNvy6ZiGJPXB2YHOfZTrUbkKIysYztIVgcfHHasHBazyQXq21pPh9CuYCkenvCqy4TEYyMsfrYyT588mrXVNHlj+lRaVZGIS6Q0REKbA7B19XPbdt3AefNY1cSkm1H5+i5WsItJy+fsK13quz0i6jgaJ7gvH4m+J1IHJGPypVkOstLXUdSgl0TRLg2ywKh2WLRgMC3GCByAR/oUq86tdXMZtQW3lnselQsrWVNOfHzx3OgT3XjKAY8FTkMG5B/CvFvJxwzAj2heajkhmjUs8ZCjzyP30jDKO8T/Jc10+Ecvljp5mkiIMrsQQQNgAoPVNbk0q+01Qqy2t1MyzyODuRQEAYY4GC3OR2FTlWX60cg+KEVBc2UF9Lam5kiFskc8UqMTuYSKoGOPcaw3Km6f4+O3qjPbSgqn5eG/oxur3jy67bdPuiTW+oQyxXspBBQNFIUVcHAPqNnOeMVwDVtOexu5rK5BdVJ2SFSomTJAdc+RxXetK02SCXTbi8vre4vIrl57qUE+uPBaJQvHkNufnWW6u6RvtU0yN2a0e+tFkc3H0h3kujgnG0rhc4AxnAzxwOfKr061VapRec7fpYW3r/Z0nhN9Rs6mjUtLST88vf0/jBx+C2httzIMe0k+Vdn9FkR0G2sRNazSz63KxZlHEKx7gFP3gQxYeWfdWM9HGgNrF6dQaG3uLS0dR4M8rRCVypI9YA/V9U4x5iuraTps1jDoqmS0Z7O5neVVkYLslZ+VJXkjd2Ps71jtqVRSU0vmV2yb3jl9ScXaxa24+eG10eAnp3W4rlLZLgSRzXDyRIwgKxM6M/qhu2dq/kaOh1y0nm8KFpg7q7QvJCypNtHO0nvj8/Kq6009obXR4nuIC1lePcyEFsFSJeF45P7QfnQVjpN2moWM93JaM8AmEtybl3ecujANtK4XkjjPHOOwzuKdxFRTWeHb36deacLeTk08cefn7delj0/rkeo29m1y80d1cWaTnxIWjRyqjxChPBwT+oyOa8vNci/i7ULizaVLiKwlu4VnhZBIqrkOM9xkjjvyKZbWEsVtoka3kMcthZPbM4ycOY1UMoxyAVJ5xVWmh3brcmVrKKSXS57Ev9KklaSR9uHYleBlfjz51Ddwo4xl+yKUbZycs4Xu+2CLqvqvUtN1b6PbGER+FG/rR5OSoJpV51N0xc6rqn0m3u7JU8NEw7sDlVAPZTSrRrQvfqS05xk9ChOx+nHXjODb3q7rSUfdz+FMW8RlGxZJDjnatPVpnVSBGoIz5n91e+G5+tM390AV0JzpG0lxIpCwBQeMu36CnxMkEKJJIgKjHek0USjMpJHtdjikkkQ4hTP8AYXj8e1ACeaAglirDz4zUTRwyyRhYBjOWJjwMYPtHwqa6/m8nvGKmoArNM0LTNLt3g0+0SCJpGlKqT9Y9z3oo2Vuf6B/7j++pHniTO6RAR5ZrxbqBu0qfM4oSwsIcpanmW7IjYw+W8f3s/wCNNOnx/wBZIPw/dRaujfVZT8DXkjrGhZzgCjLFhAT2AAyJcAdywoJo2Z9sH7QA8naane5W5m2Sv4cQ8qs4kREAjAC9+POqy1xJwnwKjwJvONqVXVKlqY9CBbaPdbxkyScqOM4qXwE895+Lk/rTLA5tU+Y/OiKTGuAJtihuCSnBUYO3PP8ArFSCcuxEcbHBwSfVx+PNT14AASQBk96MhgZcKWiIUZJI/wAaewyCORn2V7SpDBWtbeNWdk7AkkkmhopMb2W1LoxyOM/pRSyKbdkkkUN6yncfiK801t1qB7Cf3/rVeZPPYGaW17SW20/2QKHcLPOsdspVT7TnHvq2m5lgH3if/E0NDhL6YyMq4Hmfaf8A5TTE0TCGKG3KeqoIwSfOvbFt1pEfu4/CvJZ7YjEjxMBzg4NMsmP0QeGA2GIGTjjNTyK5hdKov2/sjHzJpUhg2nyqltiRlGGxjNEeKzfycbH3t6o/PmsT0d1fPqfXPUWg3lpbwpaTSLZSxKwMojYBwxJILAOh4x3NP6W60ute9IGtaMlvbJpdpEXt5greJKVkEbEndgjcHAwPId6bJRsmWYqSXVSOwUZ/xpr3Ci3VvEQMdpxn3jNZbROpLrVOmOo9TuYLbx9MubyGFFDBGWIZXcN3J9vb5VU9Q9d3+j+j3prX7awtJ7zUprdJ7dUbBDxuxEeDkNlQBnPfsaAOgNcL4qbSWTBztUnnjH60hMxkOI5CmBj1cc857/KszcdYLLr3RsOlCCfS9djupXlZTvURxB1C4OAckggg9vKgbXrxx6UdR6Wv7eCK0UQraXKhgTK8Svsc5Iy2W24A+rjnNAza26cOWTaWYkZxnFRaf6rzx+St/l+lZKDrDUJel+tdTaCzE+iX15a26hG2usQUqX9bJPPOMfKi+kLrqHUGsb3ULnp42dzAJ5IrWCUTAMmQATIRwSM8e2gRqZP5xF/eNRSqiz5kiV9w9U7cnI8qw131/La32v2jWcNzqdvfCw0q0hVt9wzKDl8nsO5PAA+NXPUWuahoWh6R9Jt7W96jvZ0tIoYN0cBmYHJOSSEUdznnHlngA0QdExiFlGQM7QAKIrG2Ou61bdRW+g9V2+mie+heeyudPL+G5j5eNlfnIHOasOmNdudW1nqWzuIoEj0y9FvCYwQzKUzlsk5PwxQNGipUsH2UqQzg/UN3LottrGu2GE1Gz6tuoopCMgLJbgMCPPO0fhWh9GNvHbdY6dBDlY16Vtn95Z5vEYn4s7H50qVUSEdIqP8AZ5125ALLfaoRn+zQd+Mej70Uf9X0z/0alSpAU1mo07+EHYaFa+rplnLdXNvEeRG09rudV9i5GQPLJqy1Sxhv9Z9KxnDCS1t9Pu4JEO1opY7ZmRlPkQR+ZpUqAK7oW9m1P0J9eahdMDcXV1ezybRgFmhjY/ma6P0L0/o+m6To97YaZZ295NYReJPHEFdtyAnJ95GaVKgEcu6msYrO76+6qtWki1rSdVga1mVuFBKqykdiCHOR7h787/0kTMs/QV8oUTNrVuuPICRCG4pUqAJeqxv9K/SCHtb2l/MmPtMgU5+Ve9AJv6o68G5l/wCKLyv/ACxSpUAbhf2KhVy2ecsSTSpUqQz/2Q==: Location: 12.9563197, 77.7071521 — https://maps.google.com/?q=12.9563197,77.7071521

[4:47 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAECAwQFBwYI/8QAPRAAAgEDAwEEBwUHAgcAAAAAAQIDAAQRBRIhMQYTQWEHFCJRcYGhIzJCkcEVM1Kx0eHwYnIIJDRDU4KS/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwUEBv/EADERAAEDAQUFBgYDAAAAAAAAAAEAAhEDBBITITEFQbHR8FFxgZHB8SIjYaHh4iRCUv/aAAwDAQACEQMRAD8A7y2nWOcKbswZz6uZmEX/AM5xWtYOrNKEUIBggDw4x+lUKs6ccXDD3r/I/wB6g1xJXHRrOc8AqPVbSa8dhFcokUKh+4kGUdwwb2xg5UgYz+E8iouz94PXLzTZBiVGkuAVV+7BMrb0VmUA7dyHPiXOOlaEq5u3XwkiI+f+GqL6VaahbGS7RNzlZGlRAj7lzglvHHPXp1GCKt3LqznJUZtLtNQuNYvLW5jcSONkxLOI5FEe5QAdpQ7Rkjnlh8J/Vo9S1AzavFaSF41hSGJ2kUAFjuZiFyTuIxjgEjJzWnb2cNtZXCW7SOJiZGeSQuzHaFByfJQPl76SVs2MEv8AAVb9KcohXickk9TRRRUFNVrDiDZ4oxX60+34Dp/C5+vP61HAQlzcJ4Ehh8x/alDEXDgcbgD+n9KTngIATLv7GeObwzhv8+GfyFSSNtnjcdD7Dfp9f50k6d7Gynqeh86itz39rtPBHsnyIqGJIlO7nCfc2ryy7kkKccgeJoqdXO0bgN2OcUVPFHalcWRUtodt1H55H0qHG32T1HFS2uGuIsHI3j+dQAgrLYC2oO9Xrj2bm2fw3FfzH9qLIYjkjPRXZceX+GvNWfaeW77NXd5Pbwx6laqJREQdjoWwrjnOOoPPUGtu41KzsdRuI5WmC70WRxCxjiZsbQzdOcj4ZGagy1UntkHrPkVtvstVjoIz9uYU1xAIEaW3JQjkqPun5V5ftL2z0zs/YC1m33N66nbBFjKjJwWJ4UfXyrWh12Nri/tr4SKqXptElWBu7UMFCBm6ZJbHzGcZFfOWoX0l1JcX9wS8sxMrfE+HwHA+AqmvbQ1gw9VrbI2QLVVca2TWjzldWsvS7H3iLe6NIkI4Z4bgSN8dpVf510nSNTs9YsI73Tplmt5OjDjB8QR1BHuNfJlpfySXASQLhumPCuq+hrVjYalq0M7kWK2bXkgP4TGVGR8Q30FUULW+/dqrR2nsWzts5r2UEFu7WV2CX2b5D4OhH5GkmJWWNlAJOV5OPP8ASsbStZlvdItLvU4DFem5mhFvbRM7EozAjGeMAcknFW59ZsSlkY2uJWuu8eFIoGZj3ZAcEfhIJxz7q6cam6Hg6jj7heZNnqNJbGh4exWhsdv3jn4Jx9etRRjubsoBhJBkfEdah/bVj3VnLEZ7j1lTJHHDAzvtU4YsuMjBIBz48VnaHq0mp6fp0lw0XrEttPcFFiIJ2ShQQc8cHpjnNJtZpdcnX8cwg2d4bfI0/PIr0FFJGJJVDxR7lPjkCipXD2KuQp6y1j7rUHxgIrCQ+Q8arhj+P2/9xP8AWlBTfxEgyu3A8D767Lq5nw8QVm3/AGWmn7MWVtDcQxahbxlDKCdkkbNlkJxnHQjjqBT9f0a+1G8uSptZUnkjkt5Zrh1MSrtJQRhSOSpOf9XPQVBpepm21HWhq80slmJp7iAu5O3umw6DywUIHxpuh31/b6TqFxqciyXiajgesTlUg7yKNtg8SFLEBR1NZHyHACCJ18AYnvC2/wCQ0kyDGniRMdxWxcaNPJY6jAssG651GO8QknARZI2IPHXCH6c1wntx2fbs9r9zZ4DWcjM9s3gYyfu/Fc4PyPjXaou0dzd29qlna2zXM15JZsWkdY/YjL7wcbug6Y8vOsTttb22pLJpU0NqjNcxwROsrPLHI2AsmMYAywyp5K56ZorCg9l5pz6PquzZdqr2OuA8fCdR9p+3FcMhtIYXLovPmeldU9GPY69njh1e4lSGzuSEaFwd0kAZXBH+50Uc/hyfEV43s1otxfa6kE9qGS1uY4rmKRtqlzJt7tiM4yQ2eOimu5prE1vZXkckFpHPZ3CWxJmKxYZFZW5G7owG0ck1RZ2MJJqz17LX23bnNaLPZoz108OIz7ky40a/jtQI2gniF7c3MtuZ3iWRJHZlywGcrnkYx+Qpez+jT2J0p5pLbbardhhEzEHvpVdcZHgAQc/Wqbaxc6pJo7WscQnXUJrZ17xhFJiBzu6Zxg5wR1Hzq4usyJpkbtDaQzrcyWkhkmPdqUzyoxubOOmOOfdXQ00ZvDd+p5LzLxXi6Yz/AGHPgk03Sb/TvUrmyFrdSxxTQSRtKyLh5e8Vg208joRjx8uTQ9CudLXT2uJIH9Ws54H2buWeVXGMjphTmqa6mb/9m3MIMKyWOohkVyV3I6LkdOMgkZGea0NCujLJbwOHZhpNpIWMjEHcXH3emfZ69eaGYV4Bum7yB9AipihhLtd/mR6lZHaLVNQ097CLTt4ha1SQ7f4iWzRWz63Lp5Nu2mG8RSTHICOFJzjn3HNFQrWGrVeXtrEA7lZQ2hRpUwx1EEjerJsZvAx/mf6VG1vNHIgZVJY4GGq6z3H45IIR+ZpqbTIrvNJMy8gKvH0FbUlYsBZt1odtcRqk1tcuq3hvf3iffJyVP+k5xiludNjl71lF5DM92L4SptYxyBAnAIII2joc9T8tnvXPSF/mQP1pplk3hBEMkE8v8PLzqjAp/wCVfj1B/ZYdpp0FtIkm7UJ5orl7vfKF5keMoc4UcYOccc+XFRzadBJOztdX0ULXK3ht1KBO9DBs5K7sEr0zivRwqy7y+NzNng+QH6VJSwKURCePVm9eXlLfSdLt769uohMkl3dx30igrjvEyeuM4JOcfHGM1YubO2nklmWS5huJLhLoSIVPdyLGIxgEYIKg5znr+XoiARgjIphhiPWND8VFPBpkQQlj1Zm910F5+0sbW2kjl728nmjuXu98rJ7TvGYznCjjBJwPHy4oksbcuslvPd21ws8twsqFGIMn3lwykY+WeK3jbQH/ALMfyUCqd0tujFI0LSnjAY8UxQpRAHXQSNerMl3XRWZa6fZW8cMYe8k7mO4jDO6kkTsGfPHXI4+PjU9vFBaSLLa973q2sVoO8II2RliDwBz7RzVlNOlyWLgFvDOcUCzZtw7wKynB9nP60YNFmcdaJGtWfIJ190z1y4/hi+tFO9Rm/wDLGf8A0P8AWinNJVw9XVe2TlNnxUZp4mLAGON2B8TwPrU1VlM0UG0Rq2wce11x5YqaeimTvCTvCge4HNNP/VDyQ/zpYw/WRwc+AGAKXZ9qXz+HGKEJs86QJukPy8TVY6gpGUikI9/FXTjIzjPhVW/dwI4kwO8O0k/IfrQIQU4XXAJgmHwXNHrkI+8WX/cpFRhLxekiMB4f4KY890FfKL7PBI8Pr504SlJeXu4CO3JJbxHU+QpbH7FkSWEpI+cN1z4/Kk0uDgzvyxyF8qlupP8AmIAEfKyAbscc+dP6BL6lXKhb7OfJ+7Jx8D4VNTZEDoVboagppcD3Cioo5gF2ysA68HPGfOii6iVNRUXdSN+8kI8kGP71D9msqGEMxBIYrlvDxNOEpVuiq4MnfFxC+CoHJA9/n50RrOoIEaDLEjLHxOfdRCJTro7Yw38LA/Wqt+5KRv3brtbOTipxDMYREXTAAGdpJ/nS3yF7VwASRg9POmEirFVWXdHcYz97PHkB/Sp7fJgjJByVGaZCu5JAQcF2B/PFJNQWs3d28adzMSBzhKWZpZlULAy4YNlmHGKkiMxDKu07Dtyc5NPjZzKyPtyACNvzppJXRmPEjqPcMf0pvcIfvF2+LmpqilaYNiGNSMfeZuBSTUM1hDIwONvGOKKdsujyZY18guaKcntSgdi5TNq+pj0B6ZqQ1G9/aDvEGue/fvGBucHLZz04+Few7ZXt1bduexNvb3M8UFxc3KzRpIVWUCLIDAcHB55oopIXn9I1/Ux6f9d0V7uWTTHto3W3kcskTCGNsoM4XJY5x1zzS6Xq+ov2P9JMr31001rqGqJbyNKxaBUiBQIc5UA9AOnhRRQhYadpdYu/+HO71WTUblNTgZIFuo5GWUgXCLkuDnODgnPPj4167txHcX3pE7L6SupalZ2dzBdvKtndvAXKqCuSp8KKKEK12zs5OzXoz186dqWqPOsTSpcXF48kqH2R7Lk5A46D3n31l2Wp32pekjRNKnvbmOytdHTUSkMrJ38pwPtSD7ajrjpnrmiihCfepe9pfSRrejSaxqenWGm2sMsK6dP3BZ3GSznBLfDp5Vm23aDVL/0H6hq095KupxW80QuomKSHZJtVsjHtY8RRRQhdK0h3k0iwkkZndreNmZjkklBkk1zn0g9oNT0/0rdjdPs7uWGzlKGWFGIWXvJe7O8dGwOmeh5oooCZXU+hPxooopIX/9k=: Live location: 12.9565468, 77.7076505 — https://maps.google.com/?q=12.9565468,77.7076505

[4:47 PM] **Aashu:**
> _You: Image_
jaa babu

[4:47 PM] **Aashu:** tabiyet kharab hoga

[4:48 PM] **You:** Nahi nikalte to late ho jate or

[4:48 PM] **Aashu:** hmm

[4:48 PM] **Aashu:** umbrella ☂️ manga dete

[4:49 PM] **You:** Haa jaruri hai

[4:49 PM] **Aashu:** aao jldi

[4:51 PM] **You:** Ha bas traffic na mile aaj

[4:51 PM] **You:** Aaj aane me fast wala root se aaye the

[4:51 PM] **Aashu:**
> _You: Aaj aane me fast wala root se aaye the_
accha

[4:52 PM] **Aashu:** bus number kya hai jise aa rah

[4:52 PM] **You:** 500f

[4:52 PM] **You:** Ac wlaa h

[4:53 PM] **Aashu:** oo

[4:53 PM] **Aashu:** office ke taraf se hi aa reha

[4:53 PM] **Aashu:** thora time lagega

[4:55 PM] **You:** Jyada bus udhar se hi jata h

[4:56 PM] **Aashu:** hmm

[5:52 PM] **Aashu:** hello

[5:52 PM] **Aashu:** wapas bej do

[5:54 PM] **You:** _You deleted this message_

[5:54 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAIDBAUGAQcI/8QANxAAAgEDAwIEAwUIAgMAAAAAAQIDAAQRBRIhMUEGE1FhIjJxBxQjUpEzQmKBobHR8BUkcsHh/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwQFBv/EACgRAAICAQMDBAEFAAAAAAAAAAABAhEDBCExBRJBExQygQYiscHR8P/aAAwDAQACEQMRAD8A+lrdiYsNyynaf5U7TcKFEO4gsSSce5pygYUUUl3VFy5wKAB2CIzN0AyaRbqVhXd8x+I/U803I+8Ay/hxn90/M1Kw83UGOP6/Ef8AFMR1pC7FIuvQt2X/AO0mZhbwhYxl24UdyfWokd6wlcKgEMfBQDBA9aejdT5l5OQkSKSpboqjqadUFma8YWtzdrZ6dbFdhkEkzs4Xe/OAMnnADNj2FZa8jg+/3N/a2+janZlBpNxaaxOttJDJCzL8BZSNjhg2MZ5B703rF9a6lpl7da1Y219BdXqJawXMwgWORgcN5vWPCJ1HXp3rv2daFo9140utTsTdXCiFJyNZtFmeRfiWOW2nJ3hcrjLDJAHsavdxVPwUKpO0eg+G9En0rwxpemXNz5lxaQiJmXLJ1ztAPVV4UZ5wBUowSQnOxh/FAcfqtWdFZ+5l/aVy3D44uYSP41waKXC0aGRJgCyuQCwycdf/AHRTETqKS6BxglgPYkf2pH3eLugb/wAuf71EkDTxqcbtzei8n+lMTTAMGbbERwC5yR9AKLlfxoYgxjibPycZPpSxHbWo3EIp9W5NMQyk6ofM8qVl/elYf7xVL4u8baZ4b2xSb7q9ddywQkZA7FieFH9far83JlBEELOD+83C18vahfyXclzqFx8UszGVh9e30HA+grJrM7wxXbyztdE6bDXZJPI/0x5PSx9p8FxfRvd6NJDDn8RobgSMR9Cq/wB62OvavFrXh2CPQHFyL7K/AdpWNfnyD07Lg/mr5vs7+SS4CSBcN0x2rY+ENTsLKe+tdcWR9HuoD94AgeVUwy/E23lR23eoXNU6TV5HlUMm50ur9F00NLLPptq5/wAzX6gJU1CfQjeaJpqQ20N15GsWqTJqDkMSSWIwiFcfDyDk+lbfwVBDcaHBrVnbtaXerRJcTrI7S+u1VLfLGMkqoAAB6VivAmgza1p9nqMGqWmoaH96d107VIFvUgg8zCKkjEvHJsGcE4z1HFetNLEDw6BewyOBXWyPwePghjz5Y/28Jx+aPkfp1p2KeOUfhuG9u9LV1f5WDfQ5qLqMcflZ2jzSQFI65qrksIupwO1zuToVBNFWvbnrRTU2hOKZ2io73cQbamZG9EGa4JLlhlYVX03PzSolY9LGkq7ZFDD3puO1hjOVQFvU8mlxebz5oQem0k05QAV84eN/Dsnh3XJ7R4z9ylLPbP2aMn5fqucH+R719H1nPF+jw+KNKl08BQ6nfHcEfsnHQj19D7E1l1OD1obco6vSOo+wzXL4y2f9/R83Q2kML70Xn3PStz4AtmtN+rSvcx+bLFZ26W+N8hkcDvxt4yc9lzVN4c8Pz6zq01jOZbQW4cXEixCTynXdhSDweVbjvtIrZeG9Y1SOz0e+1HTUNlqssUUV5pEqox3thFlgY7QTzkqx28iqOnaZt+tPxwdf8k6nGMfZ4fO7/dL+TfaPoFjpd3NfwaXbC8uEKSzwIEMi7sjcgwpPA5xmriN7NmxsjR/RkCmphAU4HQcUl0Vxh1DD3Ga6V3yeSqhlrSB+fLUe68f2qKkPmXOYJZNkY4ZviG70GafeyTaRE7xZ7KeP0rkZmtkCGIPGO8fX9KLFQv8A7Y4/Bb35FFdW8gI5kCn0bgiil9DHlVUXCqFHsMVwSIejqfoah3Ecnll5yZCeBGnCj6+1RCYUBVVSSRurY4Hso700rBuizluY4ztBLv8AlTk1GmnkPEjeSD0RPic/4rkEUiQgZFvH3Y/Mf8U7B5aki1j3N3duP69aOBWJiglkj2NmKI8kZyzfU9qksUt4CQAqIM4FCCUMNzIR3AXGKqfF+rx6JoN1fSQPcLAqu0Sddu4AseDwudx46KaOXQ+FZ51rs2m2Ek2sWs+r6dqU7zXIk0n8TzI48b5ZonOwoCR6Hnjmrn7P/DFr/wApNqV5YaRLNA4kiubKSWLbMygkSWpJjjkCsDkeorO6zBJ4m0uCewgk1jTbXMK6lohWO53Db5oe2cbJI2dQQoPYV6n4a0hNH05kE1zcXFzIbq4nuQBJJIyqCWCgBcBVXAHAUVZKoxpbEE5TlcnZbUUUVSWBRRRQAlkRjllUn3FFKooArZILi8cmQmKDsvc1Mt7aKAfhrz+Y8mnqRKrMMocMOR6H607FQ0EBum8wbjgMmecdjj/e9FyGVlkQ7T8rHGeKD5kjKVj2Fe7HP9B1pXkK3MpMh9G6fpQAqOIIdxLMx6ljWF8V6vc2Y1HWbaFmXT4R5bOrGP4nVS7Y5ZFBLED3rVaxdQaXarJLK0cckiw4B/N3HpgZP8q848WC9s9b0/Vr281LQfKgb8WKFr/TQ25kXeMjbmM8naPn68c2Y15ITfgR9ndvpGo65YultZpqEZnnhvdGLWokt4ZERfPjDHIkJbGeqj3NevVmvAWnNZaTNcyRaAr3ziZJNFtxFFJFtG0k9WJO5snON2K0tRm7ZKCpBRRRUCQUUUUAFFJZ1U4ZgD70UAKooooAKKKbmlWGJpJCAqjJJoAx32hax9zs4Xgngt2huVRrm4tDcW8R25xKQQY1OVG8ZweKyfhrQrhNVhW+i1nS9XvZHn/5rSrr7zaXYJLjfnKhccAMoHHXpUbx3rLw3pmj1jWbE24aC6s5LVoIboAndJE7xtHk5/eyGGOR1rU/ZPa2Njo02oaVrd3qGkX5zFBJAqJbuCd4AUALyflAC9SM1ortiU8s36PGygQlfLUYULjAHYcUqoSygykWccbcAs2cfypz72F/bxvF7kZH6iqKLbJNFIjkSQZjdWHsaXSGFFFR71ykBC/O52L9TQBW3BW4mZ2ZwM4XC5GB/poq3iQRxKi9FGKKl3Ee0g6ddyzyFZNpAHUCrGiilLkceArK/aPKyaFHEp+CadVceoALf3UUUVPF80RyfBmDXV9QtY2aG8nUqpIBckfoeK9Rmd7OKMQthcZ27VA568ACiitGdLYz4W9x7S5DK0zsFBYjOB7VPoorI+TUuBiS1hc5KAN6rwag3NxLaShEkLr/AB80UU47ilsWg6Co0nxahEp6KhYfXpRRSQ2SqKKKQz//2Q==: Live location: 12.9878265, 77.7539064 — https://maps.google.com/?q=12.9878265,77.7539064

[5:55 PM] **You:** [Image]

[5:56 PM] **Aashu:** full traffic

[6:01 PM] **Aashu:** kal ho jayega

[6:01 PM] **Aashu:** aate aate

[6:03 PM] **You:** Lag raha hai

[6:04 PM] **Aashu:** bukh bhi laga tmko

[6:04 PM] **Aashu:** aur padaya kya aaj wo

[6:04 PM] **You:** Bhukh to lag gaya h

[6:04 PM] **You:**
> _Aashu: aur padaya kya aaj wo_
Python

[6:04 PM] **You:** Basic bataya

[6:04 PM] **You:** Coding karaya

[6:05 PM] **Aashu:**
> _You: Coding karaya_
ki coading

[6:05 PM] **Aashu:** teacher kon tha

[6:05 PM] **Aashu:** wohi

[6:05 PM] **You:** Haa

[6:05 PM] **You:** Wahi tha

[6:05 PM] **Aashu:** ok

[6:08 PM] **You:** Aaj maggi banaoge

[6:09 PM] **Aashu:**
> _You: Aaj maggi banaoge_
mai ya aap

[6:09 PM] **Aashu:** hum free hai pyaz kaat dete tab tak ok

[6:09 PM] **You:** Hnn ok

[6:09 PM] **You:** Pyaj or mirch

[6:09 PM] **Aashu:** ok

[6:10 PM] **Aashu:** ek hi pyaj na

[6:10 PM] **Aashu:** thora freezr me bhi rakha hai dekhe

[6:11 PM] **You:** Wo n

[6:12 PM] **You:** Fir bus se utar gaye

[6:12 PM] **You:** Chal k

[6:12 PM] **You:** Ja rahe

[6:12 PM] **Aashu:** kyu bhai

[6:15 PM] **You:** Traffic ki wajah se

[6:15 PM] **You:** Usko 15 minute or lagta

[6:33 PM] **You:** Ab dikha

[6:34 PM] **Aashu:** hh

[6:34 PM] **Aashu:** traffic hai kya

[6:34 PM] **Aashu:** are hum amazon se chawal manga diye

[6:34 PM] **Aashu:** wo bhi aa reha

[6:34 PM] **You:** Abhi hai time

[6:35 PM] **Aashu:** tm ek do min wait kar lena

[6:35 PM] **You:** Ok

[6:36 PM] **You:** [Image]

[6:37 PM] **Aashu:** aa gaya saman aa rahe

[6:38 PM] **You:** I'm waiting

[6:38 PM] **Aashu:** pauch gayi

[6:38 PM] **You:** Haa

---

## August 11, 2026

[2:11 PM] **Aashu:** pauch gayi

[2:11 PM] **You:** Nahii

[2:11 PM] **You:** Traffic mil Gaya

[2:14 PM] **Aashu:** jaa

[2:14 PM] **Aashu:** kab pauchegi

[2:14 PM] **You:** 5 minutes dikha Raha

[2:29 PM] **Aashu:** ok

[2:30 PM] **You:** Pahuch gaye

[2:30 PM] **Aashu:** ok

[2:32 PM] **You:** https://youtube.com/shorts/da9sVlo0zzI?si=Nwz3jh09fiognes0

[4:43 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgMAAwEAAAAAAAAAAAAAAAQCAwUBBgcI/8QAPRAAAgEDAwEFBQUGBAcAAAAAAQIDAAQRBRIhMQYTIkFRYXGBkcEHMlKh4RQVI0Kx0RZTYnIkRGNzgvDx/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EACYRAAIBAgYBBAMAAAAAAAAAAAABAgMRBAUSITFBMhRRYdEGE0P/2gAMAwEAAhEDEQA/APom2ZhLMRGxy3IBHHJplXyTugc/I/WlbXPeTbZAPF5jOeTTaLLniRPin61m/MpcFcoRmjzbtgHLeAdMGpr3CMCsTKR6Rn6CrMTfjjP/AIEfWgd9nkxke4itSbC5Vn/aMOSGTcBtxzyPpTEc3ebcI+CM5IwKDxcr/qQ/kR/eq7Uyd2qhV2qSuS3PBx0xQAWPETp+B2X86nbcIy/hdh+efrULfw3NyvlkN8x+lTi4nmX1w35Y+lDBE5l3wyL6qRVU38WxY/ijz+VMVTbDNuFPllfkcUAUxnN1A5/ni4/I05WfCcR2bH+Vih/MfStChgjBSUIDHIMlDtGR5UVzeRYupf8Adn580VpsZ3Y3a7TLOWhLDd02g45NMbYPO3IP/bqqzEneXG1kzvOcjryaazP6Rn4kVDLXBViD/LkHuRhUgkWwvmQKOp3MKnumHWJT7n/SpSLviZem4EUhikbrLJGY5JBhsEN15BOefXArp3a3tzp+hXs9pFEb69VstGpwicA4Zs8H2AE+tb/aK5k0vSL67i2ma2smmXPQsgzXzbe3DxRPM5MkrHJZjksxPJJrjxmJlRtGHLPeyPK6eNcqlbxj17nrul/aratfg6hpclrblQheGXvdvPUjapx7sn2V6TaXMF33NzaSpLbzxbkkQ5DDP618n6fevPKY5AOmQRXsf2M6hMLLUbVjuhtpEkjB/l7wPke7KA+8mscLipynoqHXnOUYehh/U4fZLlcnrNUwcNKvo/8AUA/Wk2vZSONo9wq2wkZ5Zd5ySAf616CkmfIxrxnKyK28MEn/AEp8j3ZH960aQmXJvU9VDj5fpTsTb40b1ANUzVGRqqH9qyvmoNFMXEryynuIe8VfDu9tFWm7ENbnNmrmW4w+07jnjPmab2zeUifFP1pW0TvJrgsSCG/lYjzNNdzjpLIPjn+tS+SlwAE2eTGfgR9atqru5B0mb4qKsUEKNxBPqBipKM3XLVLy3e2lz3U8UkTgeYK9K+cu0GjT6PqM+m6gmWTlWxxKh+649h/I5HlX0vedYG9JAPnxXUvtF7OjXezkTwRltRtVJhI6sccp7jjHvxXLi8P+6F1yj2ckzL0VZxn4S5+Pn7PAYbeG23MgxxySfKvdPs37OS6N2Ymub1DHeXrLKyNwY0X7qkevLE+m7HlXSvsr7OJrV3candJus7Ifw1PR5sZGfYowcepHpXtx/i2X+6P6Vz4Ch/WR6P5HmKlfBUuFz9GXTFg2LnHqp+lLA5APrVts225iPtx+Rrtjsz4Gi7VEOyqP21QekkZX5f8A2qbW3ia0V2RiwByFY5OPjV914Zbd/R9vzFFn4TOn4ZD8jzW/R6XZGK5tkjCA92F42sMEUUyyKxyygn2iilsPcRsYxI85kB3buQCR5mre6hFwwZVA2g8n2n+1IJdPH3gEWQ/JIwSPZ1FWw3cYYmZHOVAHg6Yz7TVNMlNDwitz0SI/AGpPvWMC3VPTngClhdWbdV59sR/tTUbxZ2RsmQdpVSODjOD6cc1JQpcwPsV5ZWZty4A4A59KtjiLQyxl2J3EZPkc5B/pU7sb12J4nDKSByQM1KIHvJsDjIOfhj6UXCxnaBpNppVoYtOtYraCRmkdFJJLHqcn/wB8qesD/wAKoPVcqfga5t2C70JGVc8Z9efrVSSrbSypN4VZtytjg5oS6Q5Scnqk7sW/ZJhkBMgdORVKPhwcEFGGQfLBrUN3bjrKvw5rNnMbzzsrNtZdw8J64paN7nLOgk9Uebmhf8WzMOqkMPgaI/DfSj8aK3y4qEs8TWeHkXc6dM85IrhCRLaMeCyFTn3A1XR09jtFFFSMw2jmX78Eg5wOhz8jUSGH3o5V9pQgfOtuPeUHehd3+npUmUMpVhkHgir1EaDCBGQMjmuiSXGsxWv2g32nx6e9ml3dBzcO6SDu7dQxQBSDgdM9SPLrXpUDG1nMLn+Gx8JNXyWVpJb3MD2tuYbnd36d2AJdww271yODnrT1WEonj/ajVHh7P6Bolld3FrNp2kw30jxxuxeZYgIIW2g4yQzEHA4Fdtg1Iar2y0lrOVxZXGgy3/cjO1jJLGASOmeT7sH1ruVnYWdlLPJaWsMLzlTKUXl9qhVz7AoAArCm7G6IrWQtobyyaCI20T2d9NCyx5Z9nhbkZJPy8hRqQaWJdp7640vSoRYFIr68vYLCCSRN4haV8F9vngZIz51i9oNW1Ls2mvWP71nvNuiyX9rczxxiaCRXEZHgUAglgRkcYNdwvNHtNUsJdKu2uTFGsQjmExMyNGcrIHPO8HByevnmsufsXaXUGp2uo6hqN7d6lbrBLezMm9YlfcI0CqFA9eOc0XXYWfRm9p+1tzY2F+mkQXpubaa3s5r8rGYYp2aPcpUnJO1uSFxk4461v9p9TbSrG8u44+/uWYWttAc4lmdtqJx5ZOTjyBpPUexT3N7dG31h7fTbrUItSltDbK575WUnD5BCtsBxjg+fUFntH2bh1rVtMa7vriO0tTJKsNvI0UjTtwr71IICruAx69aLoLMq0fX1uND0LUO7tLebUZ47V4pCw2y+ISIpVSSwKNjdgcckUf4u0K7t5HGs2BhRxHvk3IN5DEKCQMt4TwOeKUsOxd1ZXFnDFexvptprR1SISyO0u0xMCpYg5PeMTknkMec1kPpmodno/s80pYItQvrSS5lkijm2pIwibJDMBz48jIHwo2Dc7pp881/ZxXWnXaXdpIMxzQkOrD30Vhdnezet29hKW1RdOmnuZrmW1h8aRNJIz7Q3GcBlFFF0G53K2YmEBvvL4T7xVtUp4Ll18nG4e/ofpV1Zs0RTdQieIrxuHINJwvcTB4+92Og4GOT7zWlWZfYeYmDcXUeMr5VS9iZe41HeRGFWkdVbzUnkH3UT4lSKRHbbuGNvt4+tFmsJiVoo1X145B99VJ4IbiL/ACjuX3dRSGcxeHUpfauf6VK52NIjLcLG65HGCTmq7gL+8E3rvUr0xn1phZAowkD49gApi+Cju1f7zXMvs5UfSpxRbDmK3RD6s3P1q0ySY4hPxYVwhllRWDIisMjAyaAJbZj1dB7l/WoES96qGY4wW4UcHgfU1aiFSSXZj7TUP+a9yfWkMnFGIweSxJySfOipE48iaKQyqfiSFh13Y+BBq6iimApqEjIsaIdveNtJHXFQCLbXsKRDCyAhh6486KKa4J7IIe4v2SPhD5fDNcWhNybh3JBI2+H0oopsRIDE9ockkrnk+z9a0KKKllIKSIdYJdsrgIDgDHl8KKKcRSGY4lTkZLHqScmpbRvLeZGKKKkolRRRQB//2Q==: Live location: 12.957475, 77.7048712 — https://maps.google.com/?q=12.957475,77.7048712

[4:43 PM] **Aashu:** ok

[4:43 PM] **Aashu:** aaj kuch padaya

[4:44 PM] **You:** Haa

[4:44 PM] **You:** String

[4:44 PM] **Aashu:** swati kitchen me pani ka nal khula chor di thi

[4:44 PM] **You:** Or hum puche aaj

[4:44 PM] **Aashu:** abhi kitchen gaye pura pani pani ho gaya hai

[4:44 PM] **Aashu:**
> _You: Or hum puche aaj_
kya puchi

[4:44 PM] **You:**
> _Aashu: abhi kitchen gaye pura pani pani ho gaya hai_
Yarr

[4:45 PM] **You:** Please pocha laga do uspe abhi

[4:45 PM] **You:** Mera dimag kharab ho jata dekh k

[4:45 PM] **Aashu:** abhi kaha laga de

[4:45 PM] **Aashu:** hum nhi laga rahe

[4:45 PM] **Aashu:** pura faila hai

[4:46 PM] **You:** To laga do na

[4:46 PM] **You:** Kuch to sukhega

[4:46 PM] **You:** Hum aate hain fir kitchen me hi rhte h

[4:46 PM] **You:** Kichkich rahega

[4:50 PM] **You:** Sahi hai ek kaam bol diye to message seen hona band ho gaya

[4:50 PM] **You:** Good

[5:48 PM] **Aashu:** bejo

[6:02 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAIDBAUBBgcI/8QAQBAAAgEDAgMEBwUFBgcAAAAAAQIDAAQRBRIGITETQVFhFCIycYGRsQcjUnLBFSRCodEzQ7Lh8PE0U2JzgpKi/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAEEAgMFBv/EACkRAAIBAwQBAgYDAAAAAAAAAAABAgMEEQUSITEiMkEGExRRYYGx0fH/2gAMAwEAAhEDEQA/APSt3jsDu9ncoPzFNMbQc8pkkDAaszy5QYST216rj+IU56QuQCsgJ7thpgN/3J/7w/x06Z0BIIce9Dio5kAiUEOD2ueaEct2fCnzcR4OGOfMGmCZm1/4WH8g+lEP9pP+cf4RTcE8KwRgyKMKBzPlTaTZeXs5YlG7O4nOeQpYDJJdN8iEn1V5486RnsZHyG2N6wwCcHvpccodVJKhiOgOacoA1H7QrsHRkgiYHtJRux1AHP6jHxrU+ErX0ziK0jIyibpX5Z5Af1IqZx9dekcQdkPZt49vxJyfoKs/sztQWv71hzysC/LcfqvyqteFIlfnVNwihWRA8Us6g927+tK7KcezcZ8mQUlFmgZlRFkjJJHPBFKM8qjL2zgDrhgalKTP70O+A/MUUpLmF1yJF+JxRSGZuPZT86/WiUEyw4B5Eknyx/tRP1i/OKGb7+PB5EN+lABceyn51+tE+8qVTkCObeHupN3js1yu4bl5ePOsM6RQ+pEyq3LCqBg9OlADlv8A2Ef5R9K1XirjTTOGnkhnV7m+Y7lt4sZAwObE8lH8/KtotV2wodzHKjr3cq8t6pqMt9PdalckvNOxmf3nnj3DkPcKku7h0UtvbPa0TTYX1STqvxj2dRt/tXt5LtTe6GUgxgmKcSMPPaVUH510LSLyw1LSl1CxlWaBwSCmRg/hx1BHga8rWl/JJcBJAuG6Y7q6L9mvED6Pc6hA2XglhEyx+MqsoHz3c/JfKuFrdVJVFTnzk9PVtGtqdtK4t+Nva/0uNcmM+s3jEghJTGCAOYU4+PMGt84CiI4dikixGJJHYgjOSGK5/wDmuaszes8hy5JZiB1J5n+ddd4YsX07QbO2m5SqhZx4MxLEfM17tfiCR8RQ5k2WlFFFRlYzJbQyNueNSfHFFRNQumhnCqT7OaK2kzDkiXPzaEYzl/0NJ7NEuY9iKpKtnAx4VXGylRlCrFls42se74Vn0e6UjCykjoRL/nRj8hl/YsrrJWPBAO8YJFLwRGQ7AnxxiqpkvOhWY9/tA/rWRYzyHMir75G3H9frSx+R5f2JK3UHo0atLzCjIQkkcvKvPHGGhtoesz22xvQ5Sz2zEcmjJ6e8Zwfge+vQnoKou6efA8gFH881TcS8O23EelTWir2ePWiuXJJVx0IHh3HyzU11bqtDjtdHq6PqLsK+ZemXD/v9HnSG0hhcui8/M9K2fhmzKq93IuN42x567e8/Hl8vOqzS7B7rUWt7lCggJ7dD3MCRt+YPyNbvp9lNf3kVpaKDLJyHgo72PkK56VaNv59T26PV+J9VjGP0VD3w3/KX7LjgzTF1LV0eVXMNswkPIbWYcwD8cH/eupVWaPp8emxLb2YAijAVi3V26ls+POrOvQqz3yyfJ0obVgKKKK5HQq5rb0q4lfJ5Nt+QFFS7DnBv/Gxb+dFa3NGdqfI3HbKs4RgpCp1Awevf8qfthhX5nG8gZOenKmlkdp3KR5yg25OOWTUiFOzjCk5PUnzpMaF1g8weeKzTE8rLLHHGAXY5Oe4d9IZF7P0eUvcoZl/5nXb7xVRxlrosrMW9q4NxMORH8I8f9f1q51rUItNsZJ5SOQ5DxNclvrqS8unnlPrN0HgO4VRRhveWcKs9qwiDDbQ28kskMZEkzAuRkl26D4/1rqvB+hfsmwM06j0+dcvn+AdyZ8u/zqi4B0Pt3XVrtfu1P7shHU97/oPn4Vv9OtNLwiFOMpPfN5YxbMFURtlZOpDd57z50uGTtC5GNobArFxH2se0Yye893mPOgwJyKZQgYBXly/WpztyO01ctst5G8FNO1Gv+duV73YL8zQuxsRBBMsKBbjaMDlsBxRUyijIsDPS7Hmn0P8AnS3kSPG9guTgZpiaIIFZWbtSQoYmkjcUJJ3TOSgOOQAP+jQGSTI2yJ3xnaCceNQEkeLN3JsdHAztPNR4VOJSGHmcIoxzrnHFOvC5uJrSwGyAHbIyn2j3gfr8vHO6cHN4RipNRWWReKdZbVL0qh/d4zhR4nxpnhrRzrWpLE+RaR+tM34v+geZ/kPeKhWtvHJFLPcXUFrBEyK0kxIXLNgdAe+um6NFp2j3f7GinjF8ITc9lz3GPcF3n/y5dfpVNSapx2x7J4QdR7pFzGixxqkahUUBVUDAAHcKVUSDUbKcXphuon9Cdo7nbk9kwXcQfhUS84i0q09F7e5kAulV4CtvK4kDAsMEKeeATjryqIsLaiokmo2Ua3rPcKosgrXGVP3YK7hnl4Uxca5plvqZ0+a7VLoOkZUo+0M+Nql8bQTkYGeeaAyWVQ9QZgYduCQxfB8hmn7a4hummW3lWQwymGTAPquACRz94qumuor1RLZyCWI74lZRj1w5Rhz8CrD4U12JvglwyXM0ayIIQp6A5opGhTW95BcehXEMyQ3DwuIycRuvVPeKKGwRJnYrH6vtE7QfAmmoNkaGVjiMDCk+Hj8acY9pMqj2UO5j59wqs1rUYLO3lurjnbwcgg/vJO5RTSzwhN45KXjPW2t7dYYjtuJx92v4F73P0H+VaB7KgAE9wA5kn9TT95dTX13LdXRzNKctjoPADyFbVwFofpEq6rdL9yh/d1P8Tfj9w7vnVqSow5JHmrLgeh4NeXhpbedVa5urq2kuUZsBYVlBZP8A1znxJqTw7w/q2n65+1tQeG7u/QZrdj2vtEGERDn03CJmPgXNblRUUpOTyyuMVFYRpehcM6rpYuBLdW1yL6wkjudqdmVuMlw3U7smWUE8ui1ajSbo2HCcP3e/TJonn9bkAttJGcePrMKv6KzkeDUNa4WuNQuOJJxNMj3iRi2RLpkRysYU71BweY76xrOgXT6/eag1yvoc19ZyC0eZUjuAgXOeWdwYBgM4O3B61uKe2vvrinE9zda5p12moT669xayOIbaTT42V8+r2ZZIQUdhuA6gYzk8qaBnWNBsJrCfVDcbQLnUJLiPac+oVQDPgeRqo0aw1fTtOu7f0CM3MTXctrKbhdju8ryICMZHtjPuNI4b4lludRvYZhcXFq8wGnyNbNEznsmkaE7sZ2Bcbj1yATmtP4BupLLjedbeLU4NGniIlfUDgrISmzf6oAfcWTvJLdWHOgRNvOAOI4GiTR+IooYhEiy7IzH2kgG0seZySAuT30V088jRRkeCHK5i04uh9YgEnzPU1zzjmeRtZSzz+728Ssij8TZyT50UV3oeo41vSU2mQJd6rY20ueymmVHwcHHfXZYo0ijSOJQiIAqqBgADuoorVz2jNv0xdFFFSlIUUUUAUnHMtxa6Ar2VzNbStKoMkRG7GCcZIPgKlcLahcX+i6HPdMHmutPiuJWAxlyik8hy6k0UUCOW3uoatpWparNb61qDmxvFRFmdXV12RkhgV557RvDuxjFdDW4OscYalo16itY2EdrdxqpZSzksfW54YAqDjy55oorTMo0n7XPtD1jhPieGw0uOyaB7VZiZoizbizg88jl6oooooQz/2Q==: Live location: 12.9923026, 77.7566526 — https://maps.google.com/?q=12.9923026,77.7566526

[6:38 PM] **Aashu:** kitna time lag reha bhai

[6:39 PM] **Aashu:** bus to hil hi nahi reha tumhara

[6:39 PM] **You:** Sala sab yahan rok ke ticket kat raha h phle

[6:39 PM] **You:** Upar se 50 rs liya h

[6:40 PM] **Aashu:**
> _You: Upar se 50 rs liya h_
kahe

[6:40 PM] **Aashu:** ac bus hai

[6:40 PM] **You:** 40 minutes yahi lag gaya

[6:40 PM] **You:** 6 baje hi pahuche yahan

[6:40 PM] **Aashu:** hmm

[6:40 PM] **Aashu:**
> _You: 6 baje hi pahuche yahan_
hh wohi dekh rahe

[6:42 PM] **You:** Gussa bhi aa rha

[6:47 PM] **Aashu:** accha

[6:47 PM] **Aashu:** kispe

---

## August 12, 2026

[2:32 PM] **Aashu:** pauchi

[2:32 PM] **Aashu:** kismat accha tha tumhara

[2:32 PM] **Aashu:** abhi aaye aur table wala niche mil gaya

[2:35 PM] **You:** Waah

[5:06 PM] **Aashu:** hello

[5:08 PM] **You:**
> _Aashu: kismat accha tha tumhara_
[Image]

[5:09 PM] **Aashu:** gajab

[5:09 PM] **Aashu:** full fast mode

[5:09 PM] **You:** Yes

[5:09 PM] **Aashu:** live location bej do

[5:10 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMBBAIFBwYI/8QAPBAAAgEDAwEFBQUFCAMAAAAAAQIDAAQRBRIhMQYTQVFhIlJxgaEHFDJCsRUjYoKRMzRDksHR4fFTcvD/xAAaAQEBAAMBAQAAAAAAAAAAAAAAAQIDBQQG/8QAJhEBAAEDAwMEAwEAAAAAAAAAAAECBBEDBRIhMUEUMmHRBjNRgf/aAAwDAQACEQMRAD8A+lopRIDgMMe8pFKk9q9iHuqzf6UzM3ux/wCY/wC1Lj9q9mPuqq/61UWKozthrt/dQIPn/wB1erX/AIxj/wAk/wBB/wBUgleRNsKp5LisLY/uQvQp7B+VNpX9ncZ/LIPqP+P0optFFFQIXm+f0jA+pp9V0ybufHBCqP1piM4k2SbSSMgjirKGUUUVFFFFFBUS4UuoM55PQxkZrO05ad/OQj+nFGoY+6OD4kD61NiD91Qnqct/U1l4TydIwRGY9FGao2ynvLZT1WMufmaffcxLGOsjBarTZEs08Zw0bKijwPmPrSCWxrxfbDt9pmhzvZLC1/er+OJGCrGfJm8D6AE/Ct7rupTafo2o3AiCzW9rLOnOQSqkj9K+Zr24eKJ5nJklY5LMclmJ5JNeG7uKtHFNPeXf2TbNO9mrU1vbT4/rr+lfaxA1yE1PTZYLc9JI5e+K/EbVJHwyfjXS7S7t7u1hubaZJYJgGjdTkMD5V8l6fevPKY5AOmQRXafsOupJbbVbN/ajt2jkjz+Xfu3AeQymfiTWq1uq66+Go9m8bPb6Nv6m26RHeHSof73cfyj6VFw+yaNsZCglj5Dj/wC+VTB/ebn4r+lS1snJT2CRj2eh+VdLy+UOoqvGzwIFlBZRxvXn+op6sGUFSCD4ioqaKKKDTXV4Z4tpKDnONrZ+oq5bySNGixzW5AAHHJ/WtfvX3hmoKo4yVVvlmtuGvk2WJDexiVlbapYYGPSloCYrcEHdJLvI+v8AtWh7Q37aH2a1jU7bCz2tpI8RPID4wuR48kcVqtK7WyR6k0Gq6zo9/aRacb59Qs02i2O5V2OAzA7t3GMEkdOanGVy9reWsV+bu1nG6GSAwyAHqGyD9K+cO0Oi3GjalcaZqKZeP8LYwJU/K49D9DkeFdy0XtRDq2tX1ppyCWOC0imkuGR42EruyhDGwBX2Vzz515/tv+ze1mla4tpcKdR7Os5md02ldqksM55U7SPQr6V4ry2nVpzHeHc2Pc4s9bhX7Ku/x8/bjEFtDbbmQY8yT4V3z7KOz02i6FJcXqGO8vmEjRtwUQD2FI8+ST5bseFc++yzRotR1Q6ndxd7aWZBjU9HlxkZ/wDUYOPMjyrtQ1GL8ysD8q89jbz+2r/HS/ItypmfR6XaO/0dbcyXB/jx9BT6qWMquZcE5Zyw48Mf8VZdN2PaZfhXSnu+TgSPs28ZycVi0KFiwBVj4qcUueIJGX3OShDcsfA1YopXdyjpMceqgmim0UyYVi8M1wuShCr4+ZrJ7O2frDHnzAwfpTmVWGGUEeorAQxqQVXaR7vFMo0etaDDrmm3+mNM8FvKYwWX2j7Lq5HPgduPnWs13sW9x+2jo89rBHfta3ItZYysffwODyV/K6qoPHUZ5r1ZgdXdoZSm45KlcjNGbpeqxOPQlTVzKYef7PabqMGu6vqOsR2sVxqc0GyK2mMoSOKPGCxVSeST08a5zrfZ3WtO7MRXsNlMNR1157LU4sElBPOXR2xn8IyuT79dliWSS57ySPYFXAGQeTVoEjoSKvLBxy5Tp+oR6Ius6bok0NrcXHaOKxtbUlXMSEx94+1snDDefQYx4VZh7Q6/dTafPajSJLbU9UurG3gkt3RljjaTEhcNzjZ0CjPnzx0WSytJLpbmWztpLhWDLK8SlwR0OcZyKRFo2mQvYNFYxRmweR7YR5URtICHIAODnc3XzpExEYiFq5VTmqcy5/H2h1i/1Xs7HZWcT3In1KK4torpobe47nbGHJIJ2+0SAQeR8w5e2+ktp9pc29ndPLNatdzW8c8aGBFdkblmAdtyMAF5OPCvRS9i7Bfuradd6hps1ss6xS20ikjvn3vncpzk+fT4gGqNz9ntggs/2Tci07i1FmwuLWO6EiBiwYhxgPuZju9elZcqWGJWNP1uy1LVG0/T21ObEMc7XAQ9wqSR94hLFuMjjGM5pXaDX9W0Lv7kabHJpVvJDEZZbnE1wZCo/dIFI4LdGOTg/GtrYdnY7G/1a5huTi/khYIsQQRrHEsYXjg/hzwAPStVf6DrkvalNRB0m9srbH3K2nkliEB/NJgKwaT+I9PDHWpmFxLezTXMUroJgQpIyUGaKTe5huXXhhnIPpRViISZluqKKK1NiAwbOCDg4OKmq9jzBv8AfZm+tWKSCodtiMx8BmppN6dtpKf4SKQGRNvjR8Y3AHHlWVQg2oq+QxU0EKwbO0g4OOKmkWf9m585GP1p9JBRRQxCqSeg5NBq7qLvbmU4zggdPQUVCpdS5likjRXO7B5xRWxiu/etnFxG0fr1X+oqJLyHu22SAtjgAE81ZIBGDyKrWn7p3tz+X2k9VNYdFY29zBHBGjPghQDkEc00XUB6Sp8zinVBRT1UH4inQYiaM9JEP8wpF9Ihg271yzKOvrTjBEesUZ/lFV7aCJp7g92hQMFAIzg45pGCVsOrfhYH4GppJtYD1iT5DFR9zg8EI+DEU6KLLmDPmzH6mn1jFGsSBEGFFZVJBWMp2xOcZwpOKyooNZHaRSRq5mUEgEgKtFXjbwn/AAo/8oorLkmDarXfsy27j8W/b8jRRUhZWaKKKgKr2HNsGPVmYn45ooq+E8rFFFFRRRRRQFFFFAUUUUH/2Q==: Live location: 12.9775918, 77.7155044 — https://maps.google.com/?q=12.9775918,77.7155044

[5:10 PM] **Aashu:** ticket sab le li

[5:11 PM] **You:** Haa

[5:11 PM] **You:** Ixigo se

[5:11 PM] **Aashu:** gajab

[5:11 PM] **You:** [Forwarded] Hi SWATI,

Your metro ticket from Kundalahalli to Whitefield (Kadugodi) has been successfully booked ✅

Booking ID: IXIMETRO178653251644624

🕒 Valid Until: The end of metro service today.

📲 Please increase your phone’s brightness while scanning the QR code at the gate.

💬 For any queries, please visit our Customer Service section.

[5:11 PM] **Aashu:** okok

[5:11 PM] **Aashu:** kitna laga

[5:12 PM] **Aashu:** metro me chadegi to msg karna

[5:18 PM] **You:** Nikal gaye

[5:19 PM] **Aashu:** ohh late se aaya metro

[5:19 PM] **Aashu:** jab kaugudi whitefield paucho tab batana

[5:19 PM] **You:** Nahi usi time aa gaya tha

[5:19 PM] **Aashu:** time dekhna humko

[5:19 PM] **You:** Ok

[5:20 PM] **Aashu:** are baap re tm to bhayanak speed se aa rahi

[5:20 PM] **You:** Tree park aa bhi gaye

[5:20 PM] **You:** Next kadugudi

[5:21 PM] **Aashu:** pehle hopefam

[5:21 PM] **Aashu:** phir kadugudi

[5:21 PM] **You:** Haa haa

[5:22 PM] **Aashu:** last station le jane me 10 min lagata

[5:22 PM] **Aashu:** dekho tmko lagata hai ya nhi

[5:23 PM] **You:** Let's see

[5:25 PM] **You:** Hmm rok diya h

[5:25 PM] **You:** 😂

[5:25 PM] **Aashu:** hmm

[5:26 PM] **Aashu:** 10 min rukega

[5:26 PM] **Aashu:** but phir bhi thik hai jldi hi pauchi ho

[5:26 PM] **You:** Ye bhi khle gaya mere se

[5:26 PM] **Aashu:** aise 6 baje pauchti thi

[5:26 PM] **You:** Haa

[5:26 PM] **Aashu:** metro me matha dard bhi kam hoga

[5:27 PM] **You:** Haaa

[5:27 PM] **Aashu:** dekhna kitna dee rukta

[5:27 PM] **Aashu:** batana

[5:27 PM] **You:** 10 minutes nhi liya

[5:27 PM] **You:** 4 5 minutes hi ruka

[5:27 PM] **Aashu:** chalo sahi hai

[5:27 PM] **You:** Aaj gaye

[5:27 PM] **Aashu:** papa ko ek baar lene aaye the

[5:28 PM] **Aashu:** us din 10 15 min rok diya tha wohi

[5:28 PM] **You:** Haa

[5:28 PM] **You:** Depend krta h

[5:28 PM] **You:** Koi train phle se laga hota h

[5:28 PM] **Aashu:** wahh pauch gayi kadugudi

[5:28 PM] **You:** Uske nikalne ke bad ye khulta h

[5:28 PM] **Aashu:** aadha ghanta pehle good

[5:28 PM] **Aashu:** bus pakro jldi ab

[5:29 PM] **You:** 1 ghanta bolo

[5:29 PM] **You:** 6 30 tak pahuchte the

[5:29 PM] **Aashu:** mazza aaya na metro pad

[5:29 PM] **Aashu:** par

[5:29 PM] **You:** Kabhi kbhi hi 6 bajta tha

[5:29 PM] **You:**
> _Aashu: mazza aaya na metro pad_
Wahi h

[5:29 PM] **Aashu:** kya wohi hai

[5:35 PM] **You:** Metro process same hi hai

[5:36 PM] **Aashu:** hmm

[5:37 PM] **You:** Aaj 6 baje se phle pahuch jayenge

[5:37 PM] **Aashu:** haa

[5:37 PM] **Aashu:** jab tumhara location dekh rahe

[5:37 PM] **Aashu:** bhayanak type se aage aa jaa rahi

[5:37 PM] **Aashu:** aise daily 10 baar dekhte the wohi dikhti thi

[5:38 PM] **You:** 😂😂

[5:39 PM] **You:** Or pata h

[5:39 PM] **You:** Kundanhalli tak

[5:39 PM] **You:** Bus

[5:39 PM] **You:** 6 rupaye hi liya

[5:39 PM] **You:** Wo bhi ac

[5:39 PM] **Aashu:** gajab

[5:39 PM] **You:** Metro 30

[5:39 PM] **Aashu:** metro kitna liya 40

[5:40 PM] **Aashu:**
> _You: Metro 30_
okk

[5:43 PM] **Aashu:** ruk gaya kya bua

[5:48 PM] **You:** Nhii

---

## August 13, 2026

[11:45 AM] **You:** Take a look at this Lac Bangle Set on Flipkart
https://dl.flipkart.com/s/IBMYxYNNNN

[11:51 AM] **You:** Take a look at this Maroon Velvet Round Sticker Kumkum Bindi 6mm – Self Adhesive | Pack of 15 Forhead Maroon Bindis on Flipkart
https://dl.flipkart.com/s/IBRrRUNNNN

[11:52 AM] **You:** Take a look at this Authentic Rose Liquid Sindoor | Smudge-free Elegant Finish & long Lasting color Sindoor on Flipkart
https://dl.flipkart.com/s/IVNOryNNNN

[2:12 PM] **You:** Pahuch bhi gaye

[2:24 PM] **Aashu:** bus aaya

[2:24 PM] **Aashu:** aaj banglore band hai shayad

[2:24 PM] **Aashu:** dekh lena metro aaj chal reha ya nahi

[2:24 PM] **Aashu:** aaj bilkul traffic nahi hai

[2:25 PM] **Aashu:** aaj banglore band hai

[2:50 PM] **You:** Accha

[2:58 PM] **You:** Chal Raha hai metro

[2:58 PM] **Aashu:**
> _You: Chal Raha hai metro_
hh

[2:58 PM] **Aashu:** dekhe jaa reha tha

[2:58 PM] **You:** Hmm

[2:59 PM] **You:** Gpt mujhe bata diya

[2:59 PM] **You:** 😂

[4:29 PM] **You:** codeshare.io/PYF

[4:29 PM] **Aashu:** nikli sona

[4:30 PM] **You:** Hn ji

[4:30 PM] **You:** [Image] On the way

[4:30 PM] **Aashu:** gajab

[4:48 PM] **Aashu:** bej do location

[4:54 PM] __[Call]__

[4:56 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABAACAwUGBwEI/8QAPhAAAgEDAwIDBgQEBAQHAAAAAQIDBAURABIhBjETQWEHFCIyUXGBkaHBFTNCsSNS4fAWctHxFzdDYnN0sv/EABoBAAIDAQEAAAAAAAAAAAAAAAEFAAMEAgb/xAAwEQABBAADBQcEAgMAAAAAAAABAAIDEQQhMQUSE0FRFCJhcYGh8DKRscEGwjPR8f/aAAwDAQACEQMRAD8A+iFo5m77V+5zrM+1qEw+y7qEFtxMSHtj/wBRNaz34N/Kid/9+mdVfVNt/wCIunK+11olp6aqQK0kYBZcMD2P21A2lU2Njc2hYLpengtntD6cWis1T0zBU0s4ljlkBS4sEG1QFZlBX5skgntqs6lfpuD2h9e1PVVnrLhDClEY5aeF28AmAZy4ICEnbgk8410W1dJsLtbrtd73XXaahRhRxyxxxRxblwTtQDJxxk6Mp+mqEXrqernZ6hL5HBFUwOo2qqRlMA9+Qc6KspYmua92/wBl/S1suNZNFc7lW01tqqqOXdJFDI7MPjB77Nqk6LrbLQdG9Z9NL07FJS0tzmlo6yl8V3SYbNyvhifiU+etFH0jR1PQ8HTlfVVVTBCAIqo4SaPY2Y2UjjK8AH6d9eWnpSeK9U12vt6qrzW0aPHR+LEkSQbhhm2p8zkcZPlqWpSzbWuk6t646jp79HJVUFoFNT0lJ4roil03tIQpGWJ7H6aEpqio/wDC/r61zzyVEVolrKKnlkbc3hBQVUnzK5x+WtNfOny/UEl0s92qbPcZoVjneKFJo51XO3cj/wBQ8j9NDyWmzWXom52qtr2pLbVRyCpuFTIPEkmk+Zznux8gPpqA2LU0NLNezipXrC90JvSPClkoqd7dbZkx4mUA96Ofm7YGOBkefJXUVDR1ntZu613TU1/VLdTlY4yn+EefiO5l1q6SzWy7N05cbNcsvbEWKnr6Uq4niVQrxSD6HHbuDnGNE3TpWpn6prbxa77V2ypmp0hljjp4ZQyL24cHGoosx7UqShp+kOjqSOzyJRC9Ue62ooLYZZC0Q5wWOSO+Mnvq4o7daaTo/qaa09M1VhZ6KVJFqYlRpQI2II2u3AydWVfZTebdYYq+rrKia2V8NwFR4MaGdoy2FIGAB8WOPpq3romutHWUcitDHNFJA7BskblIzjz76lKKt9m3/l905/8AQi//ACNLUlvp26etVvtVM/iw0lOkSu68sAMZOPtpaO6SpvAK1avhBwNzfYY/vqOSeWeNkSnbDDGTo1UVBhVCj0GNNeWNPnkVT6nQRzUNubdSgf5SR+/765v7TuseouneoEpLRHRrHLCj00TQmeWtmLAFAqtlQBnnHljOSNdEtzDfOq/LuyP1/wBNZrqzov8AjPUlJeaG9VtpuCUxpGeBFbfFknAz8p+I8/bROqA0TOrOqrv0zWWCsuNBSixVvh09ZscmanqH5znsVGPxwe3GqH2oe0C72PqIWWxQ0yeHEsk9VMniHLchVXIA4xnP19OXT+yOj9zgtZ6jvAsMUvipRDZlZSCN4fH1OcY8zrkVVWTzrJWVk0tTUSDe8kjZZzjzP5DWLF4gwtG7qU72Js1mOkcZT3W6rotr9p9U8cQv9BFLMhINRRnZlTjujefHcMPtqu9ofVs91qzTWT3G501LJDXUtItFUmcOqgFyy4X4Szefoedc6pK+SScJIFw3bHlrZ+z+gq6zqOYW271FoqDStmaCJZC43oNpDerA59NUYbFyF4jk5pntXYuGZhziMNlu6j/q6F7Mau02joyrvDXZZqI109VWVb07U8ayMFBVEIzt+UDHnkD6azfS9hrbv1wvU3T0xktCXOeolq5MCd1/qix85BHARlGM+edbmHoK3wdDz9MeNWTU07maSpLgTeLuDbx5cEDj/vrLr7N7pH1ZTVcHUFeCYpHkuQMccsbEn4PD/q3ZyW8zjTMEHReRIpbqz9W2KfpKO/e+iC1AsrSVC7CpDFdpHPP0A1mqi6dYR0NV1HYK+y9Q2FmedadYjFKIgTlVYd2UDHPPHYnjVlF0DbW6Hi6cp6qsiWmqfeY6zIMonVs78du5xj6evOqY+zAQNLWL1bcIbpJG8ElRHDGqNC3LJ4Y7ZJJyD3JPfUUW36ZqKPqiw0V5o5qgQVSblViMoQSCp9QQR+GlpnS9PQ9NWCjs9CZVp6VNqmUfE5JLFj9ySdLRzQyRhpWb+bM7f79dPWkhXyJ+51Ga0HGyNjntk99e+JVN8sSqPX/vqg8TmaVg3eS8gAjrpFUYBXIA/DU83eNvo4/Xj99D+7ztJvaRVbtkfTTvc938yV2/3650DV2SoL6KaoICKSezL/ca+eOtunpOnr3NSuh9zlLPTP5NGT8v3XOD+B89fQQooh/mOqXq3pqlvdnlpXJSbvBJx8Enke3b6+mdZ54WytoHMJtsnaLsDNvOHdOR/wB+i+c4aSGFy6Lz6ntrqvspskkAN1nQq9TtWnU8ExgglvsSFx6DPnrKdD2A3q/NBWxkU9J8VSh82BIEZ+5Bz6Kddwt8QaojbaAMEqPoo4H65/TVOCgP+Z/onH8h2k0N7HDzok/gKwVqgHPgofs+P20LUGqZf8aMlQwO1VB4++rQdte6aN7q8gRaFgWklH+GqN5kEc/kdSSQIY2VVVSRwQOx0paeKU5Zfi/zDg/nqFzLS7WZzJDnB3DlfXOihonmGOpVJHHOMfbS1HLUGmkZQpZWO4Y9f9c6WjR5IWOaZX/Cscg7q3+v7aLAJ7DUFYsrU7blRVHPBJOn06tJAjNK/IHAwNVcLIWV1vZqXacc4GozLEDjxAT9F5P6a8ZadHxIOR5yZI/M6IXbt+HGPTU4bQjvFCrPvGY43YZx5D++gq6VnYR8LnIwDnjHJ/sPx0fIYoEcKRuOTtz56qEy7NIed3b7f7yfx10yOja5e7JCUdrpKSpqXoYFinrZA0zLnLN9fwGTx6/XV5Ftp6nDjahVUjPlx5aCo3BqGKIzuPhUeXqf20VMzO6x1S+DCfXO4/fy0SO9XJTeJG8TZVlpaBhSUSyxRTkRpjGVz3GpfDqU5WZZPR1x/bRpS0TqCtOKSX/lOm+8SJ/OgceqfENC1tdE8LxpuYkDPHbnUAQLgAnPC0OFSp2LjhWUHGloUNvAOc6Wq+IViOJN5BWcs0bxOqtu3Aj4QW/tqK3ysYURY2bkjII+/wC+p2qIUHMiceQOdY3qu7y262U9NSO0c1YpldxwVj7AD6ZxrjFYlmGiMr9AmuFwz8VMImala6StpopTFPV0cUmcbHnUN+WpDDHkYGwtyChxn8uDrm56SnasSBKjLPN4QZ4yoxumBPf6Q5x/7h9yT01WyW++zWKomaWkaZoFJHyOCQrKPLJ8vXSuHasnEDZ490E0DfNNJtlR8Mugk3i0WRVZLXXhZY6Ro6WrnpnWOSTMSRHdhcgNuQ/Tyx31U+911La7RUe91dZNVTU++MrEuQ0bEqu1V4Jx3J7aOjzIkqTuQzK8TN3wcFdSUduE8FvRZn2UUkLI/hcS7EK/XjOfXtplPC8utpOnXnfTTRLYJmBtOA16cq666oaC400Eav7vUJWLVe5+7F0JL7A/zZxt2/Fn99XNqroblCWCFGSVoZYnIYqy9xkcEYIIP0Oq6v6cSoM8njRtM1b77GJoN8YPhLGUZc/ECATnggkfTkygtwpoYVJp1dZDIwpoBFHk44C5PkByToRGbf7+np8v2RlEG5cevr8r3VN0rcDV00E895q5Kko7vTCGJU4zxkRZ4x/m14L1WLTe805kqR/BI6xUmKjLEk7mwAM474+mrOio5bXQU9GJXlp44jGzqnfOedufX9NQU9kSKjWIVJlVbYlrYogBGB85GeDg/LqnhTBrRedZ58/UlXcaAvcayvLLl6AJ5vxSGmV6KSStelFVLFHIihEPA5YjJODgeh7aj/iENyuCxUcNQ8Jpoqo1IdVRUcMVyDyT8PYaieyCoqKZveLZLcYaRKaWOppRIuwElGCFtyn4j5850d/Dlo5KqaKQE1EEFMI1jCAbC/Ixxzv7YGMa6j47nAO09Ony/ZVzNw+4crPr80091kequroOnK6Ckktq1MkkCzs5bGMkjH5Afnpa0966Us1+qIqmvieSRIxErRvxtBP7k6Wsk8e0XSExPAby+UtuGk2ayJrZWEuGvy1LTQrJMFIyMHudZHrilaSmoKyMZSGP3OUD+hlJIz9wc638MHhtncPsFA/11V3ClkSrmnp40mgZAtTSsMiYc9vIMPI624zC9qhMRKW7NndgZRKc+vksRXdSXLwrRJHXbpoYWY8Kdr7pF5GO+zHf6589S2ynFd11UVCOppYKqSqeYHKhFcsDn6HjWkj6T6drojWQTTxQDlkEoAT6hsgkfnqAJTSRGltcPgWlWBZhnfVMO2T32/Qef20og2ViZJB2h3dBB1J0Fe/NPZ9rYaOIjDt7xBGgGpv25I+lDTwLN4NTJ7xMzssIXKBmzzlhjv8AppnU9HHLcrJAKGmrVM0x8CcgI2I+/II/TRdTLBZ6GCSrVjJNJsBWQIFOCcbiQAMDHqfvqHxKC9UiTDx2lpZtoAnaN42YYPxRsMgj1PmO+cOp6kuIHPLLyIPQpJhwYqlLcs8/MV1CqrfNV0tLHRUZipKl7u9M0Tp4qUyGJnCpyMjAUjtySMaOrrvcYae610UlP7tbJDG0LQnMwRVLktn4SdxwPTnOi6MWuK4ra46OVammkNWjsSQ8m3DNuLbmOJMZbv8AhpVcFinr6h6qeJZkKSVERqGWNipABkUHaxB2jn0z5ayhj2soP8NfD9HPTP2WoyMc+yzx0vn+xlrl7oS63WuWC81sJpxRW6Ro2p2jJMyqql8vngnccYHlz31DbbhKvVlytUI8AS17TNPImVcLDF/hJ5FzjJ+gGedWd3prJHXmS5ypFNIBNJE07Kku3gM6A7WxgckeQ9NeUctmutbV0tNEZm8Zax5hJgGUBAGX4twIG0ZAx3HmclzXl4G+LvS/P7ZV5INcwMJ3DVa15fejfmqehSSATyztDUtLfViJkgXIxJjcD9eBj6Y0VRXmuq66F46aSSl9+aDwxSOQqK5TxPF7ZBGT5YyO/Oj5aiyQySQzSQhlqveigZ2IlznccduQeO3GvJFtVKjXinWaojMu/ZSzkxNKTgsVLBM5znPn66DWOZ9LxQ1zRc9r/qYbOmSZ0tWRU9gpUkRmJaU5H/yvpat7QIBbKZrbHtpJEEsYOc4f4uc8/wBXbS1riY5rGi+QWSV7XSOJbzKm1DF/On/5h/YaWlq9UKkvdqoZq6CSSliL4Zt23nIx/wBdT2+NTWxrgbUQuAO2QQP30tLXY0VZ+pPv0zU9RbpkwWjM7qG5G4QsQf2/E6D6cqGuFaKycJ41RRUMkm0YBY+Kc4/H9BpaWl1ntAHj/VMqHZyfD+yoPe5DSSI4V5ay0mskncZlEgZFGG7gA/EB2B9MDVjU7KG29WzRRI00Uk0avIS3wyfGwxnAGW8sdhnONLS1jjzsnp+itsmVAdf2FbCZqO9zCP4gts4D8/yncD893P1wNS9M0VPDZ7bPHEqzy0kJaQfMfhX/AKD8h9NLS1uhALxfj+QsExIYa8PwVmrhI9LE1fTO8daa2uiM29mO1BMUGCSMAgEDHl6nPtS7+JdRI5lSP3ioMbgbHeJIACyjg55JGMZJIxpaWlrzRoeH4TJgsWdc/wAqGoqamolWeOplpTLFC7rTkKpYxJzjn0H2A0tLS1nle4POa1RRtLBYX//Z: Live location: 12.9645413, 77.7180241 — https://maps.google.com/?q=12.9645413,77.7180241

[4:57 PM] **Aashu:** yeha se right muregi to metro aaywga

[4:57 PM] **Aashu:** seedha kadugudi aa jai

[4:57 PM] **Aashu:** traffic kam hai aaj

[4:57 PM] **You:** Ye kadugudi nahi jayega

[4:57 PM] **You:** Itpl tak hi h

[4:58 PM] **Aashu:** tab metro le lo

[4:58 PM] **Aashu:** warna problem hoga

[4:58 PM] **Aashu:** phir chalna parega bahut

[4:58 PM] **You:** Haa

[5:08 PM] **Aashu:** hello

[5:08 PM] **You:** Ha

[5:08 PM] **Aashu:** phir galat bus pakar li kya

[5:08 PM] **Aashu:** bus right nahi le reha kya

[5:09 PM] **You:** Abhi yahan traffic h

[5:09 PM] **You:** Lega

[5:09 PM] **Aashu:** ok woha se right lena bai

[5:09 PM] **Aashu:** hai

[5:09 PM] **You:** Turning pe h

[5:09 PM] **Aashu:** bus right lekar thora sa chalega aa jaywga

[5:09 PM] **Aashu:** ticket kaat li

[5:09 PM] **You:** Haa

[5:09 PM] **You:** Aaj 20 ka hi kata

[5:11 PM] **Aashu:** galat kaat li kya

[5:11 PM] **You:** [Forwarded] Hi SWATI,

Your metro ticket from Kundalahalli to Whitefield (Kadugodi) has been successfully booked ✅

Booking ID: IXIMETRO178662055164624

🕒 Valid Until: The end of metro service today.

📲 Please increase your phone’s brightness while scanning the QR code at the gate.

💬 For any queries, please visit our Customer Service section.

[5:11 PM] **You:** Bhi

[5:11 PM] **You:** Nhi

[5:15 PM] **Aashu:** ok

[5:17 PM] **You:** Aaj thoda late hoga

[5:17 PM] **You:** 20 minutes waste hua

[5:18 PM] **Aashu:** accha koi baat nahi

[5:18 PM] **Aashu:** metro station me hona

[5:18 PM] **You:** Ha

[5:18 PM] **You:** Metro aane me 5 minutes

[5:45 PM] **You:** Fir aaj ticket ke liye rok diya

[5:46 PM] **Aashu:** chalega to msg karna

[5:46 PM] **Aashu:** mera aadha time tumhara location hi dekhne me chala jata

[5:48 PM] **You:** Chala

---

## August 15, 2026

[4:03 PM] **You:** Ho gaya batting

[4:06 PM] **Aashu:** aaj batting nhi aayega

[4:06 PM] **You:** Kon khel Raha abhi

[6:23 PM] **Aashu:** haar gaye

[6:25 PM] **You:** Ye to pta tha

[6:25 PM] **You:** Nikal gaye kya

[6:34 PM] **Aashu:** nikle hai

[6:34 PM] **Aashu:** ye nitin ruka hai ek hagah

[6:34 PM] **Aashu:** lagega time aane me

[6:34 PM] **Aashu:** swati bukh bahut laga hai

[6:36 PM] **You:** Kab tak aaoge

[6:36 PM] **Aashu:** 7:30 bajega

[6:37 PM] **You:** Ok

[6:37 PM] **Aashu:** tabiyet thik nahi lag reha

[6:37 PM] **You:** Kyu kya hua

[6:39 PM] **Aashu:** ek cheez banayegi

[6:39 PM] **You:** Kya

[6:39 PM] **Aashu:** pehle batao banayegi

[6:39 PM] **You:** Bana dungi batao

[6:40 PM] **Aashu:** noodles banao

[6:40 PM] **Aashu:** tumhara favourite hi hai

[6:41 PM] **Aashu:** tmko bhi accha lagega hum bhi kha penge

[6:41 PM] **Aashu:** lenge

[6:41 PM] **Aashu:** hum jab niklenge to banana start karna

[6:41 PM] **You:** Mera chhodo na

[6:41 PM] **Aashu:** kyuki humse wait nahi hoga jada

[6:41 PM] **Aashu:**
> _You: Mera chhodo na_
gussa ho

[6:41 PM] **You:** Noodles se better maggi h

[6:41 PM] **Aashu:** dekho gussa ho to rahne

[6:41 PM] **Aashu:** do

[6:41 PM] **You:** Agar bologe to

[6:41 PM] **Aashu:** pyars se banayegi to bolo

[6:42 PM] **You:**
> _Aashu: pyars se banayegi to bolo_
Gussa nhi h

[6:42 PM] **Aashu:** noodles hi banao

[6:42 PM] **Aashu:** wohi man hai

[6:42 PM] **Aashu:** use jada pet bharta

[6:42 PM] **Aashu:** bahut tez bukh laga hai bahut tez

[6:42 PM] **You:** Thik h

[7:09 PM] **Aashu:** nikal gaye hai

[7:22 PM] **You:** Ok

[7:22 PM] **You:** Kab tak aaoge

[7:22 PM] **Aashu:** aa gaye

[7:23 PM] **Aashu:** 5 min me

[7:23 PM] **You:** Ok

[7:23 PM] **Aashu:** aaram se banao harbari me garbar mat banana

---

## August 16, 2026

[3:34 PM] **You:** [Image]

---

## August 17, 2026

[2:09 AM] **You:** _You deleted this message_

[4:37 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBQECBwYI/8QAOxAAAgEDAgIGBggGAwEAAAAAAQIDAAQRBRIhMRNBUWFxgQYiMjSRsQcUQnKhwdHhFSQzUpLwI2KCov/EABoBAQADAQEBAAAAAAAAAAAAAAEAAgMEBQb/xAArEQACAQIEBAYCAwAAAAAAAAAAAQIDEQQSITEFQVFhFCJxoeHwBhMysdH/2gAMAwEAAhEDEQA/APphZFZ9qnPDORyrekbFS6UqoG5Gzgc+Ip9QQopEl1Chxu3N/avE0sy3MgPRQhB2yHj8KbBcl0Uq2k6aBH6yOPjWZJVQgHJJ5AAmgTduINR506SF1HMjh406NxIuVzzxgitSMGsqmjTLR1ViJaASwDc74XhgHA/DuxTgiRzxbVAJJB7+GfyqNGu27eMsyq3EYOM/7x+FSlEcGG24HItjPxpvaXqFtDe6BMYK+2p3Dyqokk6aeSU5wThc9g/fNWOoTdHbsUPrN6q+J/3NVZ9VQF58FHjyFa09bspPoKZZZWYxEhVO3h10VbW0MlvEEUIevJJ4/hRVXW10IqfUqdA1iaaLTRqFvcfzE01vHdMykM4ZyARnOMIQD3edavrtxeahoLWlvcQafd3TKsrsuJ0Ebn2QcgEgEZ6uyrCLSEtrLS4zclhYXTXO7o/b3CQbefD+pz48u+olroklrLpUUmoxNaaZKXt4xAekZdrKFY7uOA3MDqrgyYjLGLvy6dvnuelnw+aUlbn17++3YladfibQvrMTOZjbPKryKu443YzgAcMdlV2m67dy+iPTSsrayCtsuVA3yyYMb7eWCrqx6uB7KtLHS4oNIgsROWeOB495XaSGyMlc5wCaj6fodvHqtld/WHb6lAkDRbMLJIqlVl58CFZxjvHZV5QrPLl6Wevv6opGdBZs3W609vRiNN1qeP0d0y7uIHuZri1WeWQMkSZwM8Tgbj1AdnVVJ6RfSXpWmTwrZWst/M8CSgrIEVA/HaxwSGA2nGDz6qlekGlNo3o509vd200mmaW8JW4t94OFLBlG71CduOORwHZXz/cSfVrYsoyRw49tctSvXpWi+nZnt8M4bhca51JfxT5XW/x0OtD6WlaK6V9Jmt3lRgksNwJCjFcA4Kr14r3vo7qn8SjT+YknIsLWUtlShZw+SMDOcqc5NfMFhePNKUkA5ZBFdk+gt2I12NmYqotyoPJQTKSB55PmaKVerOqlJ/bM34pwvDUcK61BWtbvzXU6RejZJFMOo4P+/GpKOr525I7ccDWl0u63cd2fhxpVtOehy6YjjXi+eyvR3j6HyWzIt5t+tbEGAg447T+3zotYzLcjBwIxuz38h+dKQlsu/tOSx86naamIOkPOQ7vLq/D51vN5IWMo+aVyQI5Dyk/+aKkKMCis1DQ1uUFlqV3qF/IxltoLGKwgupI3jzkyLISN+eCjb2HlUCHVNQuDc2xl2NPp0l2lwLQxYKlAQgJyVIfmeIq3i/hlvDKtvAyl4I7dg4dg0aAhVOc9TMM8znjUaztNLs5VlhjkZ+ia3BnuZH2xHHq+sSNvDl3VzPD12kr9b6v7sdaxFBNu3S2i+7kHTYtQnv8ASBFfItw2jhnmkh3k5dSBjI7snrx35rL67dy6ZZ3dqY47iexW8liitmmO7HDPEBU4HryePYaubCPTrF7X6s6l4ojArPOzlY87tvE8sgYz3ClSaNo8sMEaL0ccUItlEdy6hohyRsN6w58+09pqvhq0Y2i9+77fJfxNGUryW3Zd/goNQ+saouuTxvBFFLo9tNLE8XSbsrMdoORgY3DPPlXEtX0ybTryWwvlBdVVu51YAqw8QR4cuqvpeHT9OjhkjSJdktulq46VjuiQMFXn1Bm48+POvH+nvotYazost3BGsGrW0e2EiQgSbPsEE8cgYzzzjsrKrg6jje93r/bZ6nC+L08NVySXklZeyRwqG3it9zIMdpJruv0N6QbD0duLudGS6u52V0YYKLGSoUjtzuPn3V4j6JtCh1bVzqN2Fa1smVo1dsB5faBPaFGDjrJHge32kNvbo6WqhVeR5mAYnLOxZjx7STUwWHldVZHT+Q8Sg08HS5Wv/hsedVM+6LpLdc7WYcewc/0FWjyx9Jt3ru5Yz11V3D9JdSnqXCDy/c16FKLUmmfJTelxbKX2xr7TnaPz/DNXKKBhQOAqusE33LOeUYwPE/t86nkZmiHZlvgMfnTU801EIaRuSKKKKuJRFZBzgm/wJrUtjmsg8UP6Vf1HuI1VGdQQ+Qcg4q+Yo4FM0sY4M6juJxQBGx4BCfKru2426ZHAilwwQyRf8kUbcT7Sg9ZpzBkKjoo/7F+FZVEU5VVB5cBVlDZW8kKMY8MRnKsV+VB02L7Mky+DA/MVMyDIyi0zS7LS7doLC2SGJnaQqOOWPM8akmOM841/xzVidNP2bg/+lB/SlnT5xykibxUj9aiaWiGWaTzS1ZCCoT6oI8Mit1AUYHKntZ3S/Yjb7r/qKSFlLlBCxccwCOHLv76mZFbM0V9udkzLk5IDddMWWYHck75HDPA+XKtWRiSGgckcxtzj4Usxxj2oWU9pjI/Kp5R1JYvLkfbjPin70VEzGOG4jzNFOVBmZ6OlXXu8nhmm0q693k8KyRswtfd4/Ci2/ojxb5mi193j8KLX+gvn86QQWvusP3B8qbSrX3WH7g+VNoYrYKKKKhDB4ioSLjUpB2rn5VOqHJ6upx/9lx86mVPcjdiR0eCSAMnmaNpplFZ/rRbMxVr7uncMUVmBSkSq3MUVoVQQNuhjbtUGsXXu0vcpNaWLbrVO7I/GmXALW8oUZJUgDyp5hyMWvu0X3B8qxB7sPA0yNNkaoDkKAK1iQrCEPPjUIFv7vF90fKmUq1ObePPMDB8qbQxQUUUVCBUO8O25tm5ccH8P1qZS54UmTa48COqlAxlFQLTpN8kXSkBDw4ZqT0JPtTSHzA+QqNETuOorAGABx4dtFAkTS/dj978hUyiil7hHYKKKKBE24wHA5BzTqKKWRBRRRQQKKKKhCHFw1KYDrXPyrS7vJIT6oQ+Iooq3MqapdSsuSwHgKKKKbBc//9k=: Live location: 12.9561574, 77.7137139 — https://maps.google.com/?q=12.9561574,77.7137139

---

## August 18, 2026

[11:17 AM] **Aashu:** https://claimstorage20.blob.core.windows.net/gold/Adarsh_Pyspark_Developer_5YOE.pdf?sp=r&st=2026-08-18T05:30:25Z&se=2026-08-18T07:30:00Z&sv=2026-02-06&sr=b&sig=Uj%2B%2BSPGn%2BYNk4%2FylWkSpZ%2FCMkofnsXxfLIZnFnYqlz8%3D

[4:42 PM] **Aashu:** nikli

[4:42 PM] **You:** Haa nikal gaye

[4:43 PM] **Aashu:** location bej do

[4:44 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBQIGBwEI/8QAPBAAAgEDAgIGBwYFBAMAAAAAAQIDAAQRBSESMQYTQVFhcRQiMjRyscEVM1KBkaEHI2KC0SVC4fBFU5L/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/8QAKxEAAQMDAgMIAwEAAAAAAAAAAQACEQMSIQQxBUFhEyJRcYGRodEUwfDx/9oADAMBAAIRAxEAPwD6V9i58JB+4/4+VOqvhv7W/tjNYXEdwIzxEJswx3qd6mSzRRW8k8rhYY0MjNjOFAyTt4VEPa5twMhTLHNda4QUylvHluNDwv2nGQfMUlNQs3tLW6W4Vre6ZFhkAJDl/ZHLb8+VSwjEjY+eKbXA7FJzSNwo6GQXOJOHBTbBPYe786fUS0uI71ILq242hYOuSuOTYP7qaZdXcNrNaQzFlkupDFEOHILcJbfu2BpF7YDpwmGOktjKfWDyJGMuyqPE1EEjzW5uDO0Nvwlz/KZWAGc5BGRyPZS7aTTZtL+0o5llsmiM3Xvn2ANzg7jkezNO9vj1Ssd4dPVWIIIBByDXtRNJmjutPgltpOuhdA8bhSOJTuDg7inyRyvIoUuqYOSo7dqYIOQkQRg7rM7ilMAQVPI7GsWlFtbXMtwX6qBWdmxk8IGaxguYbpVaAyFWiSYFoyo4XzjfkTtuOyqasSBOVNoJExhQ4bj0dWjZS2GO4orK7gkaYtEnECMnftoqwCm7JVffGAtB1mzk6Ja1Zehzu04hWV2OwJLMCMfh2re9RuEn0DUGjGElsGnRe5WjP/Nc6k9I1640uCKSS5vOpMcjOSSD1jncnsCkb10K2nSzgu7uDMtvZWvUx4OOsEak8/PIzXA4UZNUsxTMR0Mf0r0fFhaKQfmoJnqJ/oVBLBLpR0K2iRm028u7aaPHKCXYuvgG9oePF30faCnpHaSQ3KRzPqbwSRPcs0/BllwyeyqcsDHau+TWwp0iiPRY631TDEZzb8eT1ueHq8458W2cU6DXbIabYXt3PDZte26T8DvkgFQdzjkM4ycCtvZU5Fr4GDtyWHtakG5knI35rXdEt1tbfo7dwPMs9xqE0Mp61irIROeHhzjGVB5c61rVOkWn6NHoF7M893rkczzX0HXMWV+B1IYE4TDHAGOXLaunXOp2y3QshewreugdIuL1iNyD5bHevmDVdSmv7i61K6Jee4YzPk9p5DyAwB4Cqq7G0WtDTP2Iz54+V1OE0Drqj3VQQ0CfMG7Hln4XQ9L/AInNBpwsr3TZGj6hojKlxxsSeLBwVHf31snRqePULGx0SzfrrG9Ed2zjkkYAM8Z7j1qgEd0tcCtL+SS4CSBcNyx2V1T+DeuLpur31pdXKw2U0HXEuTwq6soz4ZDHJ/pFVseXPa2oYG3p4Lfr+HUaenfW0wyMx18fMLaoriEdHtBgnljh/wBLEitcXDRRlth6oXdn/PbOw3qVaL9rRrNezzyOOj9tNlZmX+aetJf1SPWyOdX99r9tb6tNa3dxb26wRwTJI7+2HLhvIDhG/jU2bVLWyn6i8vYYpWOVVn3wTsT3DOQM1qbQZuXiBj2xnPsvOO1D9gwyc++cY91p2oXEN1Z3La3dusraRE9mHmMYkdkbjKgEcTFuEEb9g5He36LuxuZELMUXTLAhc7DIlz8hU+51p476eEwI3UX8ForEnOJERi3mOIirG2ujdwykmP1JpIv5blh6rFd9hg7bjsPaadOi01JDpInlvuN1CrVd2cFsAxz22OyKKKKvWNUNuLCbitNAWKCyP31xGd5B+FW5keP6VZXtpnRbu0tEGWtpI40BAySpAFVqrbhQFEQXsxishFFzCJ5gVpOnbFowFX+Q6685PVRrfRLwahFCVQaZwLduvGMi6EfBw4zy5PnlkUqbTdVj0vT7T0W4YLpUdsRayRKVmC4KyMTngG2OEke1z2qxC8Pss6/C5FZBpRynmH95Pzqj8BkQCVoHEHzJAWGj6fe2YupZYI43fTLW3TrWVl6xFkDK2CdgWXPYezNcF6R6DeaFeej31rLDHKC0Jk4TxL2jKkjY7eWDgZrvxlnKlTcOVIwQQp+lU/SnRl6QaQ9nO4EgJeGUruj9/l3+GahV0AcwBpyJ+1v4Zxo6WuXPHddAPphfP0NpDC/Gi7+J5V0v+H3RzUorK51RrS86u+tmhtjBKkexI3k4iCFOARjmBnG4rXuhGgPrHSBoLyLEFkeK6jbkWDECM+ZBz4Ka7qt9OqhRHDgbADIFZdLozVBe8wu1x3i7aMaaiAZyf19qus9JvVsdRV7fDz6Rb2qAupzIqShlznsLLvy8ag69puq3Wn3dpBa3Egmso4ofR5YkjLBCGEpJBJzy5jHdua2H7Qn/APVH/wDR/wAUqK7njTgRYlGSRnLYz2dlbHaBrm2yf9n7Xl269zX3wPnlH0o1zp13JqF3cLEOqk1S1uVJkX7tI41Y8+wqRjntVjoVrNZ2tylwnAz3lzKoyDlHlZlO3eCKjLcTLIWIjbfIByAD304ajMOcMZ/vI+lWs0oY68b5+cqp2qL22HbHwIU9hgmiqx764LZCIB55opmg6cKrtQpVrCkgldlRsyHBI7KQLFZppigjUK3Dgxg9g5VksEX2cZWT1+EnOT+VSNOBELk9rn/H0qy0CSEpnBUQWCJcRI+6tnPCSvIeBrKazijuYkUuEfn65J/fzqZL75B5N9KVfe8Wp/qx+4qQJUSAvDpsfZLMPzH+KjyWTRkkvJwA+0OE/ryq2pN17u//AHtoDimWhUmndHre1lurqyEcUt4/WTHgJ42G2efn+pqUtnOy8SGIjJG5I5frVla+7x+VFt91/c3zNAMbJu75l2VVCC4Khlh4lO4KsPrisCkq+1BMPJCflVxa+7RfCD+1Np3KNgWvlwvtcS/EpFeB0b2ZB+RBrYaweKN/bjRvMZovRYqLhP42/airg2VqTn0eL8lAoovSsKjPNG1ksKkl8KuOEjuzTIHkgj4JIJDuTlcHO9ObiHt3AXyAHzpUzqEOLks223EPpSUllGzS3Sv1bqiqRlxjc4rHUvVSJ+0P/wB+VZZhP++VvIsflUe9WPqcxo4OebA/WgbpHZWVKuvd5PhpikMoYciM0u693k+GohTOyLX3eP4aLXeEHvJP7mi192i8VBry2OLdT5/OmkF7a+6w/APlTaVbDFtEP6B8qbSKYRRRRQhFFFFCEsQxLyjQeSiswAOVJeAsxJmlAPYDjFeeiRn2zI/xOaaSczqntMF8ziol5cQvA6LIpbw37aIbeFbuZerUjCsMjNSmjBiZFAAII2FGAjJWFo3FbR+C4/Tavbr3aX4D8qTprcVqB3Ej6/WpLqHRlbkwwaDgoGQsLYEW0QOx4B8qxt/dR5Gn14oCjAGBQmsLf7iP4R8qZSbXaLh/ASv6GnUigIooooQiiiihCKKKKEKP/wCQ84vrUiiimUgq6ygSRZOItgNjAYipPocHamfMk0UUyTKTRhSKKKKipJMO0s47OIH9hTqKKZSCKKKKSaKKKKEL/9k=: Live location: 12.9560007, 77.7123551 — https://maps.google.com/?q=12.9560007,77.7123551

[4:44 PM] **Aashu:** mera 6 baje se jaruri call hai

[4:45 PM] **Aashu:** use pehle try karo aane ka

[4:45 PM] **You:** Aa jayenge

[4:47 PM] **Aashu:** ok

---

## August 19, 2026

[5:22 PM] **You:** So rhe ho kya

[5:23 PM] **Aashu:** nhi

[5:23 PM] **Aashu:** pauch gayi

[5:23 PM] **You:** Abhi metro aayi hu

[5:23 PM] **You:** Bahut traffic tha yar

[5:23 PM] **Aashu:**
> _You: Abhi metro aayi hu_
itna late

[5:23 PM] **You:** Jisse aate the wo chut gaya

[5:23 PM] **You:** Metro

[5:24 PM] **You:** Abhi koi aane ka dikha bhi nahi raha

[5:24 PM] **Aashu:** aayega

[5:24 PM] **Aashu:** map bejo

[5:24 PM] **You:** [Video]

[5:24 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAIDBAUBBgcI/8QAPRAAAgEDAwEFBAYIBgMAAAAAAQIDAAQRBRIhMQYTQVFxImGRsQcUMlKBoTNCQ2JygsHRFSMkkqLhU2Pw/8QAGgEBAQEBAQEBAAAAAAAAAAAAAAEDAgUEBv/EACgRAAIBAgUCBgMAAAAAAAAAAAABAgMRBAUSITFBUQYTFCJh0SMygf/aAAwDAQACEQMRAD8A9KWK7bSIHxGfjzWL84tJMdSNvx4p5F2oqjwGKYvOTAn3pB8BzV6joYiGb18dI4wvx5pyX2LiNz0OU9M9PlSLP2jNJ96Q49BxT0yd5Gy9M9D5Hwp1Auim4X7yNW8ehHkfGnKhRm7OLWb+A/KlxcRJ6Cm744tJf4aU4kVQYypAHQjr+NUg7RSUYOisOjDNKqFCsbQWDYG4cA1migI31Z1dzHOyhmLEYB5oqTRVuLBUS4fF0h8IkZz8ql1Wynely46yOIloiMl2K7bSIeYz8eafqBC8sDyxRr3kUZ4y2CARnFTIZBLErgEBhnBowhDw+0XiOx/HyPqK07tT9ImnaFMbVIZLzUF4kijYKsZ8mfz9wB9+K2ftDeSafoGp3sIBltrWWZAemVQkfKvLl7cPHE8zkySsclmOSzE8kmvixeIlSSjHlnv5JldPGOVSs/bHp3OvQfSxb3O6G/0qW1ifjvIpu+28+I2qcemT7q6daXUF3aR3VrKktvIu9JFOQR515JsLx5pSkgHTIIrtX0I3L3NjqthOA8Fs8csYP6vebtwHuymfUmssLipyn5dQ+vN8noUaHqcNtblHSrFyYgjDayjp7j0qTUYwyRyK8TlgBjax6j1pyOZWbaco/wB1uv8A3XpM/KodoooqFCiiigIhNx3bOJYSAM8Ln+tNQodtknOOZD/9+NV3dR5yEUHzAxWsa92nvbDtDfWVprWk6dBp+mxXHdagm/6xIxckA7lYcBRxnGRxzWmkz1G8q2LK5l++zEfIVMhXZEi+SgVod5260+y7Ni6u2WO8/wAOW9bTijnu3ZNyI0gGE3HoGwTkcVea12lt9D0y3v8AWXNpDI8MJCrv2yOM4PPQc59KjizpSReX1rFe2VxaXAJhnjaJwPFWGD+RrzN2i0W40XUrjTNRTLx9GxgSp+q49x/I5HhXo5tSWO+eyaWBrxIRcGFc7u7LFQ3ljINar9IulR9otEZo4CNRtQZLdl5LeaHjo2Pjg18WLwzqxvHlHt5JmawVbTP9Jc/Hz9nB4beK33Mgx5kmu+fRP2em0TQpLi9Qx3l8yyNGwwUQD2FI8+ST5bseFc9+izRItU1UajdDdaWboUUjIeTr/wARg48yPKu8Iwdcr0r58Dh2vyy/h6XiHMk36OlwufoVTQ2zKwdAQGIwaO5z1kkP82PlSYBsllTJPIYZOTyP+q9M/KGe5K/o5HX3E7h+dG6deqrIP3Tg/A/3p6ipcWGfrCj7SSqfLYT8qKeooCuvbSCOEtHHtfIC7SRznyqi1jsRa6kmuyNcbbzUhA0UzRBvqskKgIV8SMjJ6dSK2iS3V4tgLLg7gc5INI2XK/ZlR/41x8q6TOWjR+0HZTXLw67bWx02a01qa2muJpJWSSPYI1dAu0hgQnGWGMkVO7W6I/abUtDtZrd5dHNxczXb5GBiIog9SXOPQ1tEj3PdsvcqWIwGVv70/BH3UKJ90Yq6mhpRxnTLjWdO+vS6pJLZXSX+naF9cY7f8mJyXky3g4xz47q2J+0up6lq7W+kXFiYrvWmsLV5IBKiRRW26RhtILe3z9rwx0ro08aTwtFOiSxNwySKGU+oNRo9M0+Ka3lisLVJLd3kiZIgpRnGGIx4kcE01rsTSzm3YvUrrTBpcZ0/SV0+81a4si1t3iu7oZCZwGJCr/l8rk48OOAnsl2okj0HRD2ogdIby2ubmHUXujNIwj3SsHUjI9nOME/ZAwOlb8vZrSUj09IrZoksZJpYFWQkK0ocOec5zvY89DVPb/R9pUcKW9zd6leWkNnJY28E8ilbdJF2uVIUHcR4nOPDwxU4rZCWuTvJ3ZWW/bTS/qt3PcxahadxbJeKiypK0kTOEBARuGBZcqeRkVsD3N4NIN9YWN9PduAI7K5cQyE79vtkk7VH2vPHv4qrXsCG0i5sZtSifvTAomXT4o3CRSrJhiuCxbYoJJxxnFXvaDT9Tn028XRL2G31CXiOadCRGD1xjx8jg48qNoiTK7Rtbv7241WzvI4ILvTZo4pGtnMsMm9NwwWUEEdCPSrQXt0PGJvVD/eq3QdJu9I0NrW4t7CBYm3q1tNJKZiftvIXUHcTjnJ/DpVkbK6A6Qn+cj+lNh7hX+IT/wDiiP8AMR/Sim/qtyP2IPo4opaIvIuCwXGSBk4GazUa59qe2T94t8BUmszQKKKKAb7z/Ud1j9Xdn8acqMntX8p+6ij5mpNVgwzBcZIGTgZ8TWaj3XMluP8A2Z/I1IqAKKKKAjX/ADasPMgfmKkjkgGoWoM7mOGIqHPtZY9MViBr0TIsqqUJ5IA6V1bYl9zVte+kKDQdQNnqWiamkuN67HhcMuSAeH4zjoeaK1fUL6x7SNDqV9qfYfvJY/ZjvIy0sKZOEY94MkD3DkmitFFdUZ6mdQNzE14r7jsVCAdp6k0+Ly3P7Vfx4p5WDKGU5BGRWSAeozWWxoNi4hPSWP8A3ClCRD0dfjQYoz1jQ/gKiX8EQgwkSB2YKpAxzmmw3F28iG4uG3rywA58hUoEHoc00baA/sY/9opJs7cnPdKPTimw3C45nth+8T+RqRTCWsUbq6qQV6e0TT9GVBRRRUBBvEWW5WN2VF2ZyQMnn30hbF09qG6K45yBgfOpzxpJ+kRW9Rmo13ZwNZ3KBY4zJE8e5ow6jIxyp4Ye49a6TOWihk1Gae7uY9P0Rr2O2k7l51kgjVnABOA3OPaHPjRWkHStMt7q8g1V+z9lcRTugjn7PklkBwrgq4GGGCMedFaaV3OLnV7DiJ18EkZR6VKoorJ8mi4Co1zzc2ynpuJ/ECiiiDJNFFFQoUUUUAUUUUAUzdfovVlH/IUUUQOIds9R1SHU0eHWdWi74Suyx3siKCJ5VGFBwBhVGB5UUUVsjE//2Q==: Live location: 12.9776009, 77.7160294 — https://maps.google.com/?q=12.9776009,77.7160294

[5:24 PM] **Aashu:** wednesday ko rehta traffic

[5:25 PM] **You:** Pattandur agrahara

[5:25 PM] **You:** Kis side jaya

[5:25 PM] **You:** Jata

[5:25 PM] **Aashu:** wohi mall

[5:25 PM] **Aashu:** jaha ankit hsi

[5:25 PM] **You:** Wahi tak ka aa raha

[5:25 PM] **You:** Baith jaye

[5:25 PM] **You:** Fir aage ka le lenge

[5:25 PM] **Aashu:** woha ke baad  3 station aur

[5:26 PM] **Aashu:**
> _You: Fir aage ka le lenge_
nhi

[5:26 PM] **Aashu:** koi mtlb nhi

[5:26 PM] **Aashu:** at the end tmko phir wohi se pakarna hoga

[5:26 PM] **You:** Dusre side se aata hoga na

[5:26 PM] **You:** Wahan or

[5:26 PM] **Aashu:** nhi phl

[5:26 PM] **Aashu:** pgl

[5:26 PM] **Aashu:** same route hai

[5:26 PM] **Aashu:** aur kahi se nhi aata

[5:26 PM] **You:** Ok

[5:27 PM] **You:** Aaj late ho gaya

[5:27 PM] **Aashu:** koi nhi

[5:28 PM] **You:** Hmmm

[5:29 PM] **You:** 6 30 hoga aaj

---

## August 20, 2026

[12:42 AM] **You:** [album message]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Video]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Video]

[12:42 AM] **You:** [Video]

[12:42 AM] **You:** [Image]

[12:42 AM] **You:** [Video]

[12:43 AM] **You:** [Image]

[12:43 AM] **You:** [Video]

[12:43 AM] **You:** [Video]

[12:43 AM] **You:** [Video]

[12:43 AM] **You:** [Video]

[12:48 AM] **You:** [Video]

[2:31 AM] **Aashu:**
> _You: Video_
😍

[9:18 AM] **You:** [Video]

[8:11 PM] **Aashu:** [status_notification message]

---

## August 22, 2026

[12:52 AM] __[Call]__

[8:53 AM] **Aashu:** pauch gayi

[8:55 AM] **You:** Left kadugudi

[8:55 AM] **Aashu:** bus se na

[8:55 AM] **You:** Yes

[8:56 AM] **You:** Masst khali h pura

[8:56 AM] **You:** Road

[8:56 AM] **Aashu:**
> _You: Masst khali h pura_
so jao

[8:56 AM] **You:** Aaj to udte ja rahe hai

[8:56 AM] **You:** 😂

[9:20 AM] **You:** Hum to pahunch bhi gaye

[9:20 AM] **Aashu:** kl 9 baje nikalna

[9:20 AM] **Aashu:** humko washroom bhi nhi jane di

[9:20 AM] **Aashu:** chaddi me ho gaya

[9:22 AM] **You:**
> _Aashu: chaddi me ho gaya_
Chii 🤮🤮

[9:22 AM] **You:** Ab kal se 9 baje niklenge

[9:22 AM] **Aashu:**
> _You: Ab kal se 9 baje niklenge_
haa kal aur khali rahega

[9:23 AM] **You:** Hmmm

[9:23 AM] **You:** Abhi se kya hi kare

[9:23 AM] **You:** [Image]

[9:23 AM] **Aashu:**
> _You: Abhi se kya hi kare_
padho

[9:23 AM] **You:** Yahan pe dikhta nhi tha

[9:23 AM] **You:** Gadi ke alawa kuch

[9:23 AM] **Aashu:** hmm

[9:24 AM] **You:** Kal se 9 baje ke bad bhi niklenge fir bhi koi dikkat nahi h

[9:43 AM] **You:** [Image] Beige dekho yahi h

[9:43 AM] **Aashu:**
> _You: Image: Beige dekho yahi h_
wahh

[9:43 AM] **Aashu:** breakfast kar lo jaakar

[9:44 AM] **You:** Bina aapke nhi khaya jata n

[9:44 AM] **Aashu:** filmy dialogue

[9:46 AM] **You:** Na na

[10:58 AM] **You:** [Forwarded] Stay Available - Order Arriving Today: IMMUTABLE Solid Wood Study ...

Your order will reach you by 11 PM today, please ensure availability. 

Please take a moment to check on the below issues with this Open Box Delivery. 

Damages

Missing Items

Wrong Items

Share OTP 026412 only after your product check is complete.

Once you share the OTP and accept the order, returns will be allowed based on the product return policy.

Note: Televisions will be taken out of the box & checked only during installation by the technician, not during delivery.

[11:00 AM] **Aashu:** mam padha rahi thik

[11:00 AM] **You:** Bahut fast

[11:01 AM] **Aashu:** nahi samaj aa reha kuch

[11:41 AM] **You:** Aa raha h

[11:41 AM] **Aashu:** aa rahi ho tm ab

[11:41 AM] **Aashu:** ho gaya padai

[12:11 PM] **You:** Kyu

[2:08 PM] **Aashu:** nikal gayi

[2:09 PM] **You:** [Image] Abhi nahi

[2:09 PM] **Aashu:** full padai

[2:09 PM] **Aashu:** niklegi to location bej dena

[2:09 PM] **Aashu:** neend aa reha agar so gaye to call karna

[2:12 PM] **You:** Okk

[2:12 PM] **You:** Abhi nikal rahe

[2:22 PM] **Aashu:** location please

[2:24 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBQECBgcI/8QAPBAAAgEDAgIHBAgEBwEAAAAAAQIDAAQRBSESMQYTQVFhcbEUMnKBByIzkaHB0fAjNEJDFVJic4KisuH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIEAwUG/8QALREAAgECBAUCBgMBAAAAAAAAAAECAxEEEiExBUFRYdGhwRMicYGR8BRCYuH/2gAMAwEAAhEDEQA/APpuishSeQzRwnGcbUDMUuJy4bOMhiPxrdiFUszBVG5LHAFLhHDJMp7H/IUANorVnAJAILAAlQRkA8tqQGupSRFCIx3yc/uoWoPQk0VDkt5wvWCWSSRCDwjYHwxUsHIBpgmZrV+VKMkhaQRopCHG53O2e7xpgdWjRiygPgLkgZJ5DzqZK6BPUiXycUBI5qc1tFJEsKt9VOIchtvTnTKlWGxyDUSw+qZEIHGp5gc/3iuK1jZ8inuaXSTSy8UMbFcYJ5b0VMcyZ/h8GPGiusatlYhwuyk6XQPf2GlwxzPbyvfxhZF5xuFfB+RFRbXWDLrNxPc9Tb3tlpkqXKSE8Eciupycb8J2YY7DVmbqwjtLe51V1WN74PbMeL32LcHu+Z57d9O1WHRre6E+pxxLPqAXTckMeuDHZCB69nfWKrTedzjJLa/t6noUaiyKEot729/Q5zVtTvZ9K1myugzYsknR5LYwHJfBHDk5XYYzvzzVnf6pqGlzalBM9rczrFbSQydUUVWllMWGAJyAQDzzjbxqxTo9pyrNxwTzGaMQyPNcyuWQHIGS3IEeveakX1hbXU0rXNp1ntMQt5SS26KWZRz2ILMcjf8ACiOHravNr9X38ocsRR0WXT6L/PhnJah7TZ6rrvtkkF5ILWzGWgCqQZmG65I7T+FVf0odLrKO2k0mHrJdRiuFcmM4WLhJIJbv5HGD410XSK2sdI6PatfGBzIbbeS8uZGaVo8vGu5JJz5V873tw8cUkzs0krHLMxyWYnck+e9Za+ajF03/AG735t+57XCcJTxsvjyvaHa19F4PR9X+kc622nRXtg1nDb3EdxI8UvW8bKy7kcIIGOM4GTnFegN0ike7gn0+aO606W8ht1MUBMfBIVGTKT731s4Ax2c8183afevPKY5AOWQRXrf0NwRX6anbXMc0qWkkV1CvXOqJIScHhBxnKA586mlOrOo4p/M/Y1cS4fhqOHVemvljy33a6+TvINT1LrFuZJbZrZtVkseoEODwdayBuLPvDA7P1qBdz3l9Fol7JLCto+sIsdskW6BXdQePO52Odu3w36uHTrR4Y1FtiM3HtgBZtpSxfi595Jxyqlto9BuJoLyKO5biiOqxRhpCgwcl1jBxxEnkBvk95rVUpTSUZS9Xvp+27nzlOrTbcox26Jba6f8Ad9CZ0el67ShJ1ccebi5GI1CjadxnHecb+NNlzFeqwGQ4xz+X6VKgt4LW3WO1j6uIs0gG+cuxcnffmxOPGkX6nqldeann3fs4rRSi42jLpYx1pKTco9SQucfWAB8DmitLcsYgzuGLb7DGPCipejEim6V2cV3Y6dZSAiGW8SI45gFHG1Uk8txq8lhc36ESaXe2tmcjAa469OsceGAmD/qNdItxcr7tw3zUfkKYt9dpykQ/EpP50TwLm229/wBX43O1LHKnFK236/ytDnbrUFHSOGSK5SK4/wAVW3aOS5YzFOLhI4PdWM5227Qc5NMi6m26NSXUzzGS61CSKSR7p0RVFxIAGO/Cm24GM5x210C6jchi3BCWPMjIJrEt/PJjMSjmD9fOQfDFJYGV23Le/LqU8dGySjtbn05HGzw2eqaFPFqE8MtlDrCQCRJmMccLrHxYYn3ck4J27tq8j1zS5NM1O80u8w728hjLdjgHZh519H+3uWIkR2jP9AIx+PZXL/SNpadI9IkeOGUahbLx2xwMk/1IcHk23zAPZXGrw+WW6ep6vC+NxoVck18kt+3fyeDw20NtxMgx3knsr2D6OdHOl6TpOqlpYr6+1HqpE4ivDEOsTq2Xkd1J3G2R3Vzn0U6Pb6jqp1O+R3tLMqY1C5Dy8xn4Rg47yO6vaJ9SRoXEbSq5GxCHn91RhMJKa+JL7eTbx7isYv8AiUlot/Byukagr9JtJaG4RWuLi4SeJrlnmwEkIEqnZd1GBjbGBneotqzJ0bidGKuvReUhgcEHbeu0bUkKsEjlDMN2VQN/mc1iLU8kGYzA9wXbz8a7rAStrL06279vU+fePjfSPTn0v27+hMiy1vHnclF9K0dQ6FTyIxSjqUBySZM9xjb9KSdRh4XO4IBIB7fCtU4S0aMSmiBJ7RxcMc3Aq5XA7870VsgIUcW7cyfHtorRlXQ45n1No7ado1YCQ53zxLj0pkFpNK0imRUKY95M5z5GrS2HDbxDuUelaQfzVyfFfSoTZeVFclrM8rxhkynMkHetjZXIGf4J8Ax/SpcO2pTDvXPpUyqcmJRRRdXLjOEPbgPv9xFbNDOgJeBwBzOVI9asb3nGO849Kbdfy8nw0Zgyo5vTdLttIt3gsbN7aFnaRlCsQWPM53/e1SOtTOCwB7jsavLn7LzZR/2FMIDDBAI8aSaSskOScneTuyiBB5EHyoq3a0t296CInv4BSzp9sf7ZX4WI9DVZkTkZVni7AD86yM9oA8jVg2mxH3ZJV8mz60t9OIH1Z2/5KD+lDmkGRkOimW9tJOhYSqu+MFM9nnRUurFOzYKEmWkc8JUBZUwB31paMHkuHU5BfAPfgCtZEZpFVooMtncjPKmrHKBhXjUdyp/9pFifd1P4k/fpUyoDArqMRZg2RjOMd9T6GCIt9/Z+MU26/l5PKlX39n4xTbr7Bvl60dBdQufsx8af+hTaVc/Zr8a/+hTaORQUUUUgCsEA86zRRuBX2LpHG6ucHjPb4CioV0WS4kAH9RPPxoqvhp6kZ7aFv7PGSCeIkd7k/nWfZ4e2NT5jNL6u5POdV+FKXbRtPCHlnlJOQQDgc/Cl9yvsYvEWKa3dFCjiwcDHaKnVXX1skcHHGDxA8ySasFPEoI5EZoewLcjX3O3/AN1RTbr7Bvl61mWPrGjJxhW4t/I1tIgdCp5Gi4WNLj3U+NfWm0m62gZv8uG+45p1IfMKKKKACiiigCpvlIunODg4I28KKtqKrMQ4BUay9yUdgkYD76KKRZm+GbV/l61VjUJ0UKpXCjA2ooqo7ES3JdjcSyyrxuSO7A7qsaKKUtxx2NZBlGB5EGtbclreInmVB/CiilyK5jKKKKQBRRRQBAu7ySGcooQgY5iiiirSJbP/2Q==: Live location: 12.9560764, 77.7127785 — https://maps.google.com/?q=12.9560764,77.7127785

[2:24 PM] **Aashu:** tumhara order aaya hai

[2:24 PM] **Aashu:** mygate par notification aaya

[2:24 PM] **Aashu:** kitna pay karna hai isko

[2:25 PM] **You:** 1021

[2:26 PM] **You:** Kya hua

[2:26 PM] **Aashu:** kuch nhi

[2:26 PM] **You:** I will pay don't worry

[2:26 PM] **Aashu:** ok

[3:21 PM] **You:** Soye ho

[3:25 PM] __[Call]__

[3:26 PM] **Aashu:** aa rahe

[3:26 PM] **Aashu:** bathroom me the

[3:26 PM] **You:** Ook

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

[7:42 PM] **Aashu:** [Image]

---

## August 23, 2026

[9:48 AM] **Aashu:** pauchi babu

[9:50 AM] **You:** Abhi nahi

[9:50 AM] **Aashu:** itns lste

[9:53 AM] **You:** 9 22 pe safal me hi bus aaya

[9:53 AM] **Aashu:** oh

[9:55 AM] **You:** Bich bich me signal par bhi Ruk raha tha

[9:56 AM] **You:** Abhi varturkodi hi aaye hain

[9:58 AM] **Aashu:** ohh

[9:58 AM] **Aashu:** tab to bahut late hoga aaj

[10:02 AM] **You:** Hmmm

[10:02 AM] **Aashu:** pauch kar msg karna

[10:04 AM] **You:** Ok

[10:10 AM] **You:** Pahuch gaye

[10:11 AM] **Aashu:** good

[10:11 AM] **Aashu:** 10 min late ho bus koi nhi

[10:14 AM] **You:** Ha abhi start bhi nahi hua h

[10:14 AM] **Aashu:** good 😊

[12:09 PM] **Aashu:** [Image]

[2:15 PM] **Aashu:** nikli

[2:16 PM] **Aashu:** location bej dena

[2:24 PM] **You:** [Image]

[2:24 PM] **You:** bhi tak class hi chal raha

[2:24 PM] **You:** Aaj to khane ke liye bhi break nhi mila

[2:24 PM] **Aashu:** full padai

[2:25 PM] **You:** Kha ke niklenge

[2:25 PM] **You:** Pet dard hone laga g

[2:25 PM] **You:** H

[2:28 PM] **Aashu:** ok

[2:40 PM] **Aashu:** nikalna to msg karna bro

[2:40 PM] **Aashu:** bro 👊

[2:43 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAMEBQYBAgcI/8QAPRAAAgEDAgMFBQUGBQUAAAAAAQIDAAQRBSEGEjETFCJBUTJhcYGxBxVCkaEWIzNSwdFicpLh8BdDU6LS/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECBAUDBv/EADIRAAIBAgQDBQYHAQAAAAAAAAABAgMRBBIhMQVBYRMiUbHCBhQ0coLBMnGBkaHR8PH/2gAMAwEAAhEDEQA/AJy34T1zXNR7EWut2el3F5He391q7xqzMmRlI0A8RB6+e2asv2kWOp6hxfFetpmrXeiNY93DaOIxcFiTzRyMQWCHJ2GBv8avXaqxwpLn/CC30rFxFNNZXUMbz2jzwvClwq4aJmUgOAcHIJzUmkiCdzn3CGOGNR1fWdZsfuSwuxZ2NtpSzI8/KCsayOuc7efngtscZKHG8Gs6RxbxbqR0y6uYtQs44bLU4ZRGtkgUB8v/ANvfPxx55qVh+zvVzb28NxqmlN2c8con7k7XEHI4cGOVnLZO4IOVAOwq9X0JmjuVubWCa1lBEkUwDqyk9CpGDUU4vmSaaOdcGLq+pcb6dr76Pc6ZaQ6QLe7mmcEX0mPCQ348+E83u+FXzWr7Uo9F1WbRoA2qLasbZdmy4BxgeZ3JA91Oe7zqiqtvGkaKFRIyAqgDAAHkAKTHab5icY69NqaUWJuSOdah+2kfDVxp/EemT8TWmqWIK8kKLNZXJX2WVfINuG93l0p3qmha/ecIcA6PfW8l2YL6A6qgIbliU9HOdwFOD13FXrLgn93LnzwhP0rUyAZzzD1ypp5ULMyucQaZfz/aVwzrNhZu9ssdzb30yDA7LB5Fb5nI+VRlnNrXCvGHEeoDh691u01d0lgurLDOgUHETA7gDIHy86uzSIpHM6jPTJrbmx+LGffUsosxROEeBoLvQ524thNhez31xdwW1tdmN7SKUANFlT7LY3X095IrolnZ6dbWlva2gjjtreNYYkWTPKqjAHX9aatuRQUU9VB+VRcHe9xqa8CT+74DvufyoqKEUY6Io+AoqVn4hmXgSNtcRmMpGyOIX7CQo4bkcAeE+h3H50pdrkRKfxSAVBcG6VdaRps1nfySS3Emo3ExkmZWeRO0PI7cu2Sqqfn5VZZIw7xsSfAc49dq45EpXOmZtAV9N6a3jA8kOfEzDI92f9qfU2cc99GMbRoW/PakqavdDcjeqPxbx5Dw/wAQS6bc2RuYRbJMhhbD9oW9lyTgKQPLf3VfcD0rytqmozX1xdaldEvNOxmbf16D4AYA9wqniajoJW3Zt8G4dDH1JOo+7HfqdIT7W7pbSUtokHeyDystw3JzeWVIzjGM4NWu/wCK4Dp+l3ljcWENrqbyc8t3zFYeWPJU4Iwc5FedrS+kkuAkgXDdMeVdE+y+/sbTXnTVrm2htRC8sfepxHH2hAQjxbElXO3+EelcsNiZupknrc0eK8Gw8MM8RhrrLuv+l81bWe76RpWpzacpnuoxM9q7kdnEil5WHQk8oAA65YbVM67Nd2kunHTRp0kF5PHa5uIncgsGYMCGAxgDbHzqEttT4MmQdvdWEkWnA2EH3hcRyI6eFi0ec8w3Vebr4cGp23ueGk4c02YapaNpmmSxiKfvQZUdVKqrN57HofdWs2zyCRH67xBa6TJr0M1pEZrCyW4gEcEhSRzGzYYrkKMqOpGx6071vULfTOI7HT+xVreYr3mQysDAJG5IsDO/M+Qc9AKbjWuGNSTiOWW8jSxuFjsbm7aYCKYNEcBG6ZAZgabz33B2tHWr6/e2Fu86Wnf55F5WbsgV7GT8ONzgeYJpAIcQ8Vx6Lrl3pzWqsICgVuSViQUVtyu3UmimPE/FHBqavJMZ+/SXCrJJLb3ScoIHLj44UfnRTuxWR0G01C2v7aK706ZLuCcFo5IjlWGSM5+NOOeUe1Fn/I2frim63LoQDbOoHkB0/St0voScNzKfeP7VCEbcibfUJrmQOFSPlHUtIDj9K2tJO1MjFQGB5SQcg/ClUljf2HUn0zvW4AHQdakIzXm/jjh2Th3XJ7V4z3KUtJbP5NGT7PxXOD8j516QqB4w0GDiPR5bKbCyjxwS43jkHQ/DyI8wTVTF0lUh1Rr8H4g8DXu/wvR/3+h5ohtIYX50Xxe89K6BwRw3qC2ya3HqEOn9oDHEJYGkLIfx8ucEE9AfQGong3Ql1LXJotVAhtrDJuUcgZcEgRE+9gc+5TXUr+6tpJIIY54ezXG4cYFVeH0YuXaVHsbPtHxJRh7pQW+r+yGelcL37Xlu33np8UXfDfr3W1dXhYpylY8tgK3UgjqTTqz4Ivk07URd6vFNqNzLbSiXsSY3MDcy9qpOX5ifFv0A9KseiTW00snYzROyqFCq4Jx5nHp0qYrVunseOS01Kg3D2qmHVJPveG31PUp0lfu8LCAKicnIRzc3iHVgQcgY6VF2PA17pvDcumwayI57m+W5cIJEidQvKYyVYMObAJII6Dar9L/Fg/zEf+ppO92WJv5ZFP8ASgZzOP7NtdtoIrez4kEcMS8oxJdJzbk55RLgdcYHp65orqtFK4WGGm31peadZ3dgZJbSeFJImALeAjbJ9fXzpzzwTHlblY/ysN/yNVzge/sLjTZY9CstThsuc3MffLZoY8SEtiIkYK5ycDpmrH2uP4kTjHnjm+lO1tgTuaPZQv8AhK/A0n3SVP4M7D3H/n9KcrNG5wrqT6Z3pSi7CyGXNeR+0qyD1H/B9K17W7bLdiOX0I3+tP6KHZ8gsVSKxtbDVbu6s7TutzdRvNNIpOXfniGd+mxPT1Pqaqi8eytf6ugvYuyhSIWgabDM7PIjF/FsoKqfcpB88VeNblKXTS4LpHF2bKDg7lWyPf4V2qMi7m073EbosrqsbMyEOQCeVcAHOCx2GepryfGcNXVbPTg3FpLR21vd/vtc0KFWMo9+WvX8jPB+qza1o2hahcTCWWcRu5VsgMYJCwG5x4hjHu91XCoLRtOMC2yQw93tLcgopXlOAhQKFHQAMeuDsNhU7W1wqlUpYdRqKzu+u70/grV2nPQbzc4kiJK8nPtgb9DRfjNpJjyGfyOa2ufYU+jr9RW8y80Lr6qRWkcDZTlQR570UlaNzWsR/wAIopDI7hm3toOGdJTSJ5XsO6xvA0wyzqw5gzdNznNSOZl6qj/A4oW1W3RIbU9jDEoSONVHKigYAA9AKP36+Ub/AJr/AHpiRq7owxNC2PevMP0zWEEBP7qUqfRW/oa37Vh7cTj3jf6VgywSeFynwcY+tAG8aup8UnMPeMGlKTjijQ5jGPgdvyrW8fs7WRh15cD4nYUDOf8AGepzCfsLdygf94WXqd/CPyFTHB83fLS2Jxzq57QDpkb/APzVN4gl7bV7jHso3Zj5bVeeBbfstNRyMErn/Uf7BatVEo00VYNymWeiisEgDJ2FVC0aypzoVBwdjn51vSRuIgcBwx9F3P6VjtXb2Im+LHH+9MDeNFjQIgwo6CimV1dzwSBSiHIztk0U8rZHMkLJ32OGETGCeYRqJXQFA748RAOcAnoMmsSXMqxtm3kD42x4hTDhfVodU0O2uLO3uI44827wzFe1iaM8pVxnZtgSPfUp3hB7fMn+ZSP1oA1hu4nUBpFD43B23+dLbPso58+QpOR4XiZm5HVRnyNUnjPVRa3UWlR88VueWS77I4ds/hB+H1qpjMVDC0+0kW8HhZ4uqqcf8i3dvp/bdmLqzWbPsLOA2fgK01qYQwAP4cZdgfQDP1xVI/Z227PvXdLn7sxz9779Hjk9eXs858seu1Z0C/fUre/0VXkaN45GsmkOXTAPhJ9CKpYfijdWNOvG2bbf7padUXcRwuKoyqUJXy77fZvXoyteO4uNt3kf9Sa67osIgsUVenQfAbD6Vzbh61haSzvJ5mCtIeziigkmdioBJwinAGRXTNOubaeyhe0l7WLBTIUggrsQQRkHPka3a9aEpdmnquRh0aU1HtGtHzHlJdhFnJQMfVt/rWWmjWSNGLhpObHgbAwMnJxgfPrSmDjONq4JnZowAAMAACk+8Q/+aP8A1ClSCOoxUfeaxY2dy8E8k/axosknZ20siopzgsyqQB4T1PkajKcYK8nYlGEpu0VcUnNvK4YyxdMe0KKWSdJI0ki5pY3UOjopZWBGQQRRU0/A5ta6itrF/EBdiOu+Ou+azRRQ9xx2GepwxvYz8yLnkO+N+lc44/A/aed/N0jY/HkA/pRRWHx/4ZfMvJm77P8AxT+V+aMc7f8AT7HM2PvLGM+XZZx+e9Y4D24khk/FHHIw+PIf70UVhUtcTQ+nzN6rpha/1eRnhhpUt9D7Cd4X57gc6hSccifzAj9KldPuZZNP06GR2K3Go3RuCrFDOV5sc3KR54yBgbDbFFFehxLfvk1y09B53DRXucJc9fWOdPvrhJrbllci3fUFjDMWwqhSoOdzjO2fKsSxnTbPRL+2muDcy2c00rSTM4kfu5fmIJxnP/OlFFck+7fwt6To13kvG/rFuHnYappkZZ3W6sZHn7SRn7R17MhjzE7+I9MdfhhPXXuINb1o2lzJbY0+DIjVDn+Nj2lOPliiinVk44fuu2vpCjFSxFpK+nqJ7RrLvOg6S8Vzc2iC0iAit3wo8PvBP60UUVYbtoislfVn/9k=: Location: 12.9553325, 77.7002976 — https://maps.google.com/?q=12.9553325,77.7002976

[2:43 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAAcBAQAAAAAAAAAAAAAAAAIDBAUGBwEI/8QAPRAAAgEDAgQDBgMIAQIHAAAAAQIDAAQRBRIGEyExQVFxFCIyYZGhB4GxFTNCUmJywdEkFvAjNFOCksLh/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwQFBv/EAC0RAAIBAwIEBAYDAQAAAAAAAAABAgMEERIxBSFRwRNBYXEGFCIzgbIkMqHR/9oADAMBAAIRAxEAPwC0cIcKavLxDpVzc2upWGhaZdPfr+0XQzSStjKoigbQSAT4dT6U64x0rUbrjPWbjVNC1nUtKuxEIE0goiXCKB7twwG84IHc9MelaSJA593c5/pBb9Kba1YXOp6Jeafbzy2E1yqqlxg9CGDEEAg4YAqcY6GpNJeZFPJV/wAPpG4ennXXUjs7zXtYZ4NNglST2QlGYbwDkZxjoPBc4z0qeujXuHZOKebpl4Lq+1QXUesJcCFGgDZSLmZ6Z6DZ8/DFXXSOBtUtdT0i7u7/AEtzYzc8ywWbJcN7pXlc0sSyEEZL5P0FWq8tBPByb6ytbmBnU8qdVkXcD0OCMZFRTi/MbTRT+BodT/6y4l16bRp9G06+jiRLOfCNLMMbnwP/AHdfHd61O8Z32vxcK6g/CsBbV2eMJtAdgpYBioPQkDz8CTUxNHcks7xbiTn3WzSS8zvyn746YppRfMTclyM14yteMLnQb3h3U9Kn4gmeRJdM1eGNI2iO4E8wA+4w6jOfHvirNrWmarf8bcCyXsLXenadBLLeTAZjFwIyAx+e5Rjp41ZAWA+CX54Qmi8xfHI9QaelC1FbtNNvrX8VrnV1tJF0q70pPaZlHuPOrDGR/MAP1qB0GTiDhKx1zSZuFLvWZL25lnivbcq0VyH6DmnuB/3860IugbaWUN5Zo27BxuwfLNS0i1FK4X/DzTDwppNtxUzNqcEJhuEhvCoaIymRYX2nDBSR6HsegrReXaStkMnXoArdBUcerD0rhRD3VT+VR0POcj1roSn7Ph8Cw+n+qFRXKj8EA9KFSw+otS6EpbXUdxHHJC6SRSEhZI2DKSCQRn1BH5UaZc3Nup/qb7f/ALUNwRY3GncMaJY3q7bu3tszoSCVkPU5I6d2NWAxgzrJk5CkYqhU0mW6m0AqfCmszB7mGIHJVizDywOlPqbIN19KxHRFCD8+tHhrdDcg9Z3xD+JCaTrOrac+ni4mtJVW2aNsI3udeYT4gn+EfSrzxDdvp+ganewgGW2tZZlB7ZVCR+leXb24eOKSZ2aSVjlmY5LMT1JPr1rDc1ZUMKO7O/wXhtO9cqlZ/THy6mqQ/i3IsUQl0WNZN6c1knLKVz75VcAg4zgZP51ZeIOKFsDbpZTafLazWb3sbTbybgh8LGm09CcjwPXwrz5YXjzSlJAO2QRWmfhleaQbfVbTiC8tYIWhEMftN0sXuSElwmT4FFOR2Jz40rS4lKfhzNPGOEUKNv8AM23JLdf4XvV9Ri0/W9OjmtFIuNslyXc7rZGKxpjzPMbr8lapC/e+g4g0+xgTTTa3gkbM0Ds6ctV3ZO7Bzk46dPnUDLqfBesWk13qFzYcy7jNsTfXCc4IhZAyHrtBOWDDuTmrPe6pw8i6Zq93qtmsSCSO2uDcrsfcAG69ifdrqNt7nlEiJl1+zW5vLZrRRcxarDYxqsUmwo8kSliw90Nh28R1Apx+0IBxgNGMQ9mK8r2jmtuFyVMgjxnGOWM586RtNb4Xm024ubi8jtLK51MzLJPMFE0sMiMHQ9iuUQ/UU2tb7g+e2TVrx7ayee/lngurmRVkleKXqyP4p8Ix2wcUgJDT9c0ySW/iv47iOW2u5bcCG3mkBVWwCSqkZ/OhUUPxC0LRru9t9LtL/UYZJ2ne4s150bO+GYAjtgntQoywwi6xXCypG9qVmSRQ6Op90qRkHPlilOZIPihJ/tYH9cU3W7dT70DgAY6Dt9qUS+hbuWX1H+qjBYWxJvnuEkupOYQqBFHjKCM+lLWbiSIuF2lmOeuetKJIj/A6t6GjAAdhipCQjfWsV7ZXFpcAtDPG0TgeKsMH7GvM3EWi3Gi6ncaZqKZePs2OkqfwuPkfscjwr1BVP/EjhteINEkeFM6jaqZLcju3mno2Prg1hvaPiRyt0dzgnEfk62mf9Jb+nqee4beK33Mgx5kmtN4R4a1LTLRL46ja2kl4gL21xbNL7oPRWXOOo/MbiKh/w30i1v7qTU9QeNbW1ZViV2AEkpwfooIPqVrR7i7tp9RjBuIeUuOu8Y86r4fSjnxZvmbviTiOf4dFclv/AMGWk8I6miwxxa1a272tvcJBLa27q6c05CEluqIfhHfoO2KkLHg++srC2eHUbZtSh1F9RIeBjbszR8srtznOPe3fzEmrFoksE0crwyxyMWwdjA4A7Zx+dSddHKex5VLqUi54T1FtDk0+DWI457iea5ukEJWCTmHJRQDuUKcEdTnrkHJFMZ+A7scM6boUOt7EiM7TJtkWNxIfAK4PuEkgE4OTkVoDf+aT5o36ik7jpdWzeGWX6imBQbbgnXrSIRR8YXdqigBUgWR1IAA3HmMSCcZwDgeFCtGwPKhRkMCZmTduXc6t1DKpIIPXIPjXMwTnB2OfIjrUPwlPE2hQQafaanFbWgECLqULQylQMjG4DcACAD8qmOcAcyRup89ufuKMY5IM5E3sYW7Bl9D/ALons06fupz6NTpJY3+B1J8gaPRlhhDLmXkfxRrIPMf9/wCKLzbvbuaEFe/QYP60/oUnh+QY9SoWlrZ6FHfjT4PYIRy5XCs3cmUscnrjoPoPKqVc/iNdroWsXUN3D7XHKwtI2l6CPkLKDJ73xdWGB/F7vma0DVZhHdzyuGaFykZ243Lt3dQD3+JumRUf7PYTx3EeIpFvMiaPlMTKSoU5XGT7qgZ7YHevJcStq8LnXGm5ReMYeNmdGlUjUj9UufqTGkz+03NpMJecrwzFZN24MuYiMHxHU/WpyorS7WVZVlkUxoiuqq2Nx3FckgEgfAPE+PbtUrXe4ZSqUraMKu5krtObcdhud4uYy5UghgMD0rl70SJv5ZFP+P8ANHm6Swn+oj7Gi34zaS48Bn6da6BSOKFcU7lBHiM0KQxJbdrdEhgk2xxqEVWG7AAAHz8KG6Ze6K39rY/WjOkm8lZj37MARRczr3WN/QkUxBXeNv30LD+5M/cVxFib9zMQfJXz9jR+cR8cUi/ln9K4Xt5ThjGT5N3+9ACkauud7hvLpiuyMERnbsoJNcjjWPOwEA/PpTfUn22jL4uQv+/tmjdhsjOeKNTufbeRC+0REMQOzMepz8utXDhh1ube2lX4RHk/Jux/+1ZvfzG4vZ5j/G5Yemelahwrb+z6XGpGCFVT9Mn7k1qrJRgkZqTcpsmaFCuEhRliAPnWQ1BZE3FMHG1s111DqVbqCMGiG4j7K28/0Dd+lc5kjfBEfVzj/dMQqqhVCjsBgUKbh5mZwXjQqcY2k+APn86FGAyHla4WVtscbJnoA2DSM11KsZ/8CRX88bgPpRNL1SPVdNtdQtEL291GsqlWBxkdQevcHI/KnPtEf8RKf3AigPyBLqF/hkXPkeh+9KNtcEEBgBk57D1pGflvFnakhOAPHqe1UPibVYZtaGlSvLFpMDbJBCcMz+LHoex+R7Gsd7dwtIKT3bwjZZWc7ubhHZLLLvDPYyThLe5tGlB/dxTjP0FR/FNzyLOXwaONmwemCeg/zVTm0CCzha5v7K7gs1GRMt/E+/yCgJk5/Ki22oTavwrqFtcSF7myQTo56l4gfeUn5d6z2fEnOvGjXjpb237pfhmm84YoUJVqEtSW+3Zv8og9Mg9p1C3i8GcZ9PH7Vr9gmyzi8yNx/Pr/AJrOOHrW3t54Lm5nkLPC0ixw20spVSSu4lFIHY960mC5gnhiltnEsMiB0dASCtdmtWhOWiLy0cajRnCOuSwmKkZBHnSYgiBzsBPmep+9d50fO5WW37N/VDtxnHxYxnPh3pTB8qpT6FrXU4SFUkkACk/aIf8A1o//AJClSMd+lRs+u6bbzzRTTyoYHEcsht5OVGxAOGk27R0Ydz41GU4w5yeCUYSnygsid9OFnzEysCASQfGhUmzkMRy5Tjp0QmhVqfoVNeoe3jxA2WY7TgZx0HlQoUKi9yS2Gd9GgWNwi7llQg4/qFZTxQgTiPUgO3Pc/U5oUK898Q/ah79j0Xw796ft3H2tux4R4cBZiP8AkdCfJwBSfDYxp3ELj4v2bKn5HGaFCuZa87+l7R/VHTuuXD6vvL92P9GkuI5LU2tzJbsNNJ3IqEnErfzA080uX2i00C1dSLU6a0xhSR0VnLgbjg5J7+PcmhQrt1G3c1E9s90cWmkranJb47MLHqd6dIln9ql540dQJN3vA85l3f3Y8ac8SRHQ7m7XTJriEHTumZmfaTMilhuJw2D38+tChVOW6Tl5pLuW4SrKPk2+xJaFtGuX9oF/4wtophG7M4DlnUkbiT1AGfT1qv8AEEs8cPE4Sdxbm8AeDC7ZAYosgnG7BHToRQoVZdNxoLHV9yu0SlXeei7Fq1rTUuLwSNdX0eUXCQ3LxqvoFIFChQq2pCLm8oopykoLDP/Z: Live location: 12.9553329, 77.7003308 — https://maps.google.com/?q=12.9553329,77.7003308

[6:53 PM] __[Call]__

---

## August 27, 2026

[12:29 AM] __[Call]__

---

## August 29, 2026

[10:27 AM] **Aashu:** pauch gayi

[11:20 AM] **You:** 10 baje hi

[11:37 AM] **You:** Aaj maybe table lene aaye

[11:58 AM] **Aashu:** okk thik hai

[2:18 PM] **Aashu:** nikli

[2:20 PM] **You:** Hmmm

[2:21 PM] **Aashu:** location my brother

[2:21 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQDBQIGBwEI/8QAQhAAAgEDAgMDBwgHCAMAAAAAAQIDAAQRBRITITEGFEEiMlFhcaGxBzNSYoGRksEVI1NjctHhFiQlNDVCgpOy8PH/xAAaAQADAAMBAAAAAAAAAAAAAAAAAQIDBAUG/8QAKhEAAgEDBAEDAgcAAAAAAAAAAAECAwQRBRIhMVETFGEy0QYiJDNBcYH/2gAMAwEAAhEDEQA/APpPvDeNvN9gB/OsYS0t2ZDG6KE2jcMeNLWoLStHDP5G3cSqY5+jnVhGpRApZmPpbrVPgFyZ1FLBHKQZFyR05kVLRUjFtOGLOP7T7zSWpHN6B9GMe8n+VWuML5IHLoKprssbyTeAGwowDmqj2RLhFVqtu19ZalpqfO3luGhH0njbdtHrP5VoC66LbTrWzWzR2SBoZzLJKm79a7bcJIoIww6jOc10m5tWumRY5OFKgLpIOqEeI9dKnQdK1+QLrEJtNVYZaSBtgn+sAcgn08s1uUK0aa2z67O1pGpUreLo109ucrHnGDUtU7cX2t6TeaffW9uBMqiMwI2d4kU88seWAeg64rfezFo9hY6dYSD9ba25aX6ryNu2+0fnSdt2e0nQ7tY9JhN1qnhLOwfgD6RAwAfRyzWxWFotpCV3F5GO53bqzHqTUV60HHZTWF2Go3tCrBULWOIZy/7xgmkjWRcOoI9dQtA6fNNkfRf+dM0VqHJTaEEuFYHyXyDg4Un4UVIttNENsE+1OoDLnFFG1FerIbopfvSDqko9qGgXkGQNxBPIZUj8qeGRlDFFFFIArnfbLttY6LqtxbRRteXYI3IjAKnIcmbwPqANbp2hvJNP0DU72EAy21rLMoPTKoSPhXy5e3DxxPM5MkrHJZjksxPMk1p3dzKjhQ7Z3dF0uneuVSt9Mf48nUbL5SreW5Uahp0lvCeXEim4u3pzI2qfuz7K6MsFvrulWu6OCeykVWEgbcGXHhXy9YXjzSlJAOmQRXafkR1G4NlqlgVeWCB45YwD5u/dkezKZ9pNY7W7qTn6dTk29X0a3o2/ubbhLtdnS7KytrGLh2sKRJ6FFM0v3hvG3m+wA/nR3n9xP+GujhnlsoYopfvQx81P/wBZo73H4iQD+A0YY8oYopfvkP0m/A38qKMMMoj412OtsD7GFYNJNM8UckGwbw2S2enOp+JcDrAh9kn9KjEsj3cSSRbCAW5Nn1UyRyiiipKIL61ivbK4tLgEwzxtE4HirDB9xr5l7QaPPo+p3OmX67niOA2OUi+DD2+45HhX1DXPflC0BdcsLp4Uzf2zM8BHVsAZT2ED78GtW6t/WjmPaOzoup+yrbZ/RLh/Hz9zhsNvFb7mQY9JJrvHyWdmZtI0N7m94sN5ekSNGDtKIB5CkenmT6t2PCtE+Sjs+ms6nJqNxCZrSyK7EzgNKeYz6lGDj0keiuz8KQebFcL7Jh/OsFhbv92X+HR/EWpJ/o6XS7+wMZEd4hK+OIq7icnBFMd2PjPOf+WKW4bhDiOfduD7iVJyK94twOrT/wDSD8DXTPJnjvILCMo7bzJtznJxk1ElxdAny1YA45r/AEr1W2mJWl8hJMkMm0g8zTVpJH+u8tecjHrT6DshF5OOqRE/xYop/ev0h99FLK8Dw/IiZbxVDtwAp8WOK8tJWa8Jl2FnGFKNkACsjaz7ccYkDoCcj4URwPDPHI+1ue0Y5dfsp8C5H6KjkkCkKoLOeij/AN5VJUFBVFIczzn943xq8JwCT0FUKsHLuucM7Nz9ZNXAiZh2X0+10qWe106BIIHzMyrk5YnmedbFVRpI/vsx+qBVvUtJcItScvzSeWLC6U52xysAcZC5Fe96HjFMP+BqO1hjms4uIobqRn1mpO5wfs/eaOBciyjiXCsynDynAYdQFpw28J6xR/hFLmCOK8t+GCPOPUnw/rTtDYJEPdYP2SfdRU1FGWPCOb6D26/SfZiO/ksYbfUxc20MtvlghjmkCrKnPOCpPj1U1tY1zSxrsenFrxZGmaCOSSCQQvKoyUVzyJAB9XLrWqt2HjfSOzMCajFFe6Y8cbygEC7jR+KY9vUkFQw9GDUq9l7hu08OpXN9ZzJDqZvlndJDcNGQwERPmqqhsADkcDpjnkaRhTaM9D7bPw7W51gQQ2b6XcX1w8URLBkuFjGOZONp6VtGs9pNJ0aS6j1C5dHtVieULCz4EjFUxgc8kHpWnf2KD6QLKTUox/hVxp+9Ym8+ScShvYMYNOy9mdV1e8u7/Ur2x48zWfk20Um1RBKZCMnqTn1YoaiNORd9o+0A0zszDqywmOOSaCNlvUaIxo8gViwOCpAJPOqq07RaZca42n2V3Y3NnFp817LcW8vGaMrIoA8kn/ax5Yyase0FrJrll3SSeONRdwTgtGTkRyhipx4kDFKa5oq3V3e6jbapBpynTLiw48eF4TtKp3FhgDGwqeeQaSwhvLFLztNBBoupXemiZb+3ltQ0N5bvEypLKiBtpxkEFsHwIpzTu0M11qrWly0CK2qXliiqr72SKPeu0g4z1yT1HTnVHbdjJjZ6jxbjToO+x2YUWcUjRjgzCQsWOdxYeP8A9q1t9BSHWIr8X8TrHqV5f8MI2SJoSgX2gnNN4Esm1RXESRqkayMqgdFJx7azF3DnBcqfrKRWGmxtHAS4wWOfswKzvxutWUDJYge8VHGTJzgH530Y+ihPvFMUnBEkd7JwwQFQDqT1NOUmCCiiikM545nN/pslvPfz6ohkaPT7u44igm3cxzqQBuUEhCTyyxHIgVnpmtXFpa2T3Otd7u2u1e4tAnEeCAqA/GGwMm0hnyQoB8nmK6CXY9WNeSZkjeNndQ6lSUOGGRjIPpq9xG00r9IzyWUTHUnGnR6k0D6rGUAlhEO5WZtpXG88MvjGV8M1Dpml3Oo63FqT6mbyxtbtktXuI1cSptRiyYUDzty7hjzAQT47RpOjQaXNxbea4LGLhsrOSrHIO7BJx05Achub003cNuvLYMcnyjz9lG7wG3yaF2yvtQh1pYre9ltTHJAHjN20YkjYeXIqhDhF8WzyIOeQwVLiWVNPsZpu8foNrljPJb3GTNMkhfiCRmTyX2rhgeRXA6g11EMwGATiqOSdzdNxHkKM8iMAxBK8x1FNPJMo4MeytlHb6NHAY+7nc88drxMvBDI7FA3PPgfSM5AJxVqlrHGMRl0Gc4DGqjsnoK6PCzC9ku1KlIA8YTgxFi+3l5xyep9gAq/qW+S4rgh4TjzZn+0A/lWE5lhhd+Ip2jOCv9aZpbUP8nJ68D30kNkS8dZXkXhEvjOcjpWYuJx50APrV6iEAGeDK6Y8M5A+yvc3CdVSQeo4NTuM2xEveyOsEufVg0VFxZT0gb8QooyLYvkfooopmMKSn/1K2H1W+BoopoTHaoZPnJT4iR//ACNFFVAmZb2QxZwD6i/Cp6KKhloKWv8Anb48Cy/GiigCCy5xM3izEn76YoorG+zZj0gooopDP//Z: Live location: 12.9777989, 77.7274114 — https://maps.google.com/?q=12.9777989,77.7274114

[11:05 PM] **You:** Khana kya kha ke aaoge

[11:05 PM] **You:** Ya banaye kuch

[11:05 PM] **Aashu:** mat banao swati

[11:05 PM] **Aashu:** humko late hoga

[11:05 PM] **You:** Kitne baje tak aaoge 2 3

[11:06 PM] **Aashu:** hum roll khaye hai

[11:06 PM] **Aashu:** abhi swish ka chaat kahyenge

[11:06 PM] **Aashu:** mera fav hai

[11:06 PM] **Aashu:**
> _You: Kitne baje tak aaoge 2 3_
haa itna to minimum hai

[11:07 PM] **You:** Sahi h

[11:07 PM] **You:** Kon mangva rha

[11:08 PM] **Aashu:**
> _You: Kon mangva rha_
koi nahi 😅

[11:08 PM] **Aashu:** hum khud

[11:09 PM] **You:** Akele ke liye

[11:10 PM] **You:** Khud kha rhe ho

[11:11 PM] **Aashu:** hh humko bukh laga

[11:12 PM] **Aashu:** sab usi me thora thora le liya

[11:13 PM] **You:** Hum bhi ja rhe pizza order karne

[11:16 PM] **Aashu:**
> _You: Hum bhi ja rhe pizza order karne_
okk eat club se kar lo

---

## August 30, 2026

[2:22 PM] **You:** _You deleted this message_

[2:22 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABAUAAwIGBwEI/8QAPBAAAgEDAgQCBwUHAwUAAAAAAQIDBAURABIGITFBE1EUIjJhcYGRByNCUqEVM7HB0eHwQ3KSFiRigvH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAKREAAgEDBAEDAwUAAAAAAAAAAAERAiExAwQFElETQYEGFCIyYbHR8f/aAAwDAQACEQMRAD8A+iZLgx5IEX57j+nIfM6GNQ4Z3JOWxkk7f0H9dGJbh/qSsfco2jREdNBFzWNQR+I8z9Tq5SJhsUOzvHvYMY1O7Kphfjnv9deOCUYA4JHXTSoqIXV4lzKzAgqgzpVHnYA3tDkfiOR1SZNSgd0ziWnjcDAZQceWrdA2l8wPH3RyPkef89HazeTRXRNCVP3MyVA9n2ZPh56IkkSPG9gM9B3OsBLuYK8bBG5At392NCBmcirLGVPNWGldJK1HOYZeUecf3+Gi0JpJBGxzAx9Vj+E+R1nV0iVO3eSCucY01bIne4PWywVKrGh3OWABx9dehPSaptjFEiGFI/z46w8RkSQsysIvUjYDHP8AtqykkEEIVopgSck7OWnhWFll3hVI6VAI98Y1NT02D85HxU6mlcqxW9RO0iIsYiD5wz9fprMUgY5nkeU+ROB9NZVykwb19uM7x8tXIwdFZejDI0p8BHkFkRaephdFCo33bAD6aCq08OtlHZsOPn1/UfrpnVR+LTuo64yPjoCubxYKaoH+1vn/AHH66qlk1IxoJPCqmGCRIvQeY/8Ap0n4v40ouHSIZ90tYy7hTQYLAdizHko+p8tMC5jKygkFDnI7Dv8ApnXzpc7jNWzVNxqmLzzsZnJPc9B8ByHwGvJvdd6KXXLO1wXG0b7Uq9V/jTn5OpUf2swrMPSbG6Rn2pI6kSP9Co/jro1mr6a9UMNdSTpNTvzXZnkfI555HkdfKVHXySVASQLhumO2us/YlXyxXyvoN3/bS05qCCeQdWVc/MPz+A15Ntu9R1qjUvJ1uU4bbUbd6+2t1yv9OySIsiFHGVPUaDgFSUdI5EKoxQFgc8tXelw+IqK24k49UZH11hTuI4Z3PQSMfjz11D5HIO6ossMBP3cfNj5nr/nx0wSRH9h1b4HQ9vQ7Glf2pDn5aIeNH9tFb4jOhiRnqaq8CMdAR8GI1NIosbG07sY750BS1KxK0IDSFGIXYM5HbWu2+5V81xp2rahKqlq7vV28UxiVTCsZlKurDBOBEAc59rt3z4b4mSu4yr7eJaU0jF1pEjADqYWCybj33Ell9ynVEybLmql6BIV9/rN/TQ/gnwqqlyWbG9Ce56/xGtX4R4quFxls1Fc/DSsqZJHZlQBZ4PDkKsPIhl2nHkPPRnC3FAu/FlfStNTPTsGajVAN6rG5jcMe+47XHuJ8tAB6MHQN2Izrg/FVkeyXeekdD6K5LQMejJ5fEZwfke+um8O8TXK58J3W4yeHBVUVqMyQtTqHmkMRYT4xjZuBVQOuGz21Z9oSx3C33SCdI2jpbOtxiZUAZZt7c8+RAIx0xnXn3ej69ELKwdThuQew1+z/AE1Wf9/BxGGkhhfei8/eemuxfY5w2Upp71Wx4NQvhU6nl93nJY/E4x7hnvrnFstFRUi8vMnhm00ss86MAfvEyAh/9gc+YUjvrtFbdq+0018pFnSaWhNJJFUGFVO2aTaUZQNuQFPMAcmHlk+HY7dt+rV8He+oeSppp+00fe7/AJSNoq1CRR7QAFkU4A9+gI5WmjEGCGMhJ/z6/TRFfWRsJYlWTcGx7PLkf7apgqYFqpJZcoG5rlT/AIOn6666wfGN3C0jmRR4M6Og5AMv8xrLxp0/eU5I80bP6aozRu26CoSOQ/lcDPxGrRLPGPXUTJ+aPr9NIZl6ZF+Lep8ihzqa9WrgYZ8VR7m5HU0oHJrtjMUPE10I4fpKWop1M09SlV4jEy7n9UFB7RXnjHz0HbOI6E2WOoNmjgW3Ww3ejjinEgWPY3qk4BViCRggg5PXGtlhoYYauurpZSj3COJHViAF2Kw5Hv7Wtetdgsscd1sNtrGRzaYqKsWOJQH3K6pNnoXxvzj3Z0CDK2ttdquHD9N+zEVm3LBKvSkR9qZPuZ3Vcd857aMo/RFr5qCmokSSzRRejt+FQ6MNqjsMLjqdK+KbDa2grq66vcCWhhpIGg3boznCbFU4Y723esMZx20RTvTNI/E1JedtDV08U8qGBT4qRg9AfWBILDGgCXeagsNnp6+C2JN4MAo4KaFfXcMR92M8iuASQfy6CrGtVup6ektloop6a8QuxzMIUeFUUgFiDyw/IcgOemVRbaS/Ulvqg88tHEGq6aON2jEhkT1GypDAhWYY/wDLSy42Cy0lkpBefHe2W6OaKNJYd5KTMFRABkllyqrgZ6aYgI19lWUPSWmjU8RUYrKk1tX6OJFJA2EEMCfW7Y7nTerktVsuVPYFtq+FXMZJGA9RH/0jJnmSxjIBz+EDVNtpoLxPTVFBdp1r7fSLRzpVUO2XBIYM0bgEE7eoGDz0wunClFca2trZp6la2aSKSGVXKiDw8FAFBw2GDNz/ADHSUKxVTdTluTOoafw3lio5qiZpAoj/AHYGc5ZmI5KMdgdDUFbFXW+lrIlaJZ03BHIJGCQefccsg9xpvxDb3u9tlo4qyWjErDe8aglk7oc9j0OO2r6OnMFFBBM6TNGu3eIljGM8gFHIADA+Wn2J6ij1W5cjrHwo85CKD5gY00qo6Z0ZFRGkxyCrk/PGvf2fTMAfCKEjorEY+h1XYXUVlM/ik/5n+uppibZF2kmA8tw/pqaOyDqzQDwncFs1vpquktdUYLjJWC2zS4iSNk2qivtPIP65QDGDjRv2eWWu4eul7StWgikuEi+DT0gIj3JvLYwoCjB5L19U+R0NWXm9zWu0TVNTc6anatqInrKOi+8qIVGYj4RQlWcjAOAO+OelXDc1fNbOMZ6uhulRVV8kFHDLLFskJcMgDY2D1Nw3MMdeZ1JRs3F/DNTdLxJVVFpslbTtBHF4c33c0pIYNtl5lCvq45EEZ6HSriHga63C1WKFobfV1FHQCmfHhx7JlIKNlo23IOeVGM+XXTT7P6oRQJY6n0to4grrUVULQMKhmkZoAhyBtVcjazDHfppdX328xXaVKm4XWmY10sFRTw2/dHTUnreHMj+Gcn2Dkk53HkMaAKpKe50E1bQSTU9urrxSR0KGmmaRDOquvpJIUCMMQkfIZBIOOWrm4ZuJs91oxBTUsNTPSyra/TWdSkbZkHikeqXwP+Pv0PwPNVePZ6GKnmq9gqpJY6yiZBG255IqhXZRt3kqNozjPmDqiju/FVclLC90qoLxJVRpJSx29SYozjxC7vCFULzK4LdcbmyMAjYOFLBU2fiSa41dDbrVTmjan8KimZklYyBgwUgYKgEE9yc63OKoSV9qByPzbSBrUuErdcLHamp7pcI6upep8Tx0YyEqVAJYkDnnJx2B6nrrZ5KJTGx3O0uPVctzB0R5Gn4C2zg4OD2OqvADfvXZ/cTgfQarDtPb9yEh9vUdcjV0D+LCj/mAOlgeTCNttU0QACbAygDHfnq/Q0vq1sDfmVlP8dEMwUZYgDzOhjR7qaHatp1ODKvy56miGKUafHxhPFbbp6TDBT1It89dSz01T6VE3hjaynkMMrFcjmOvPQvD/E16tElbFxMJZ4o7UbrG/ixySYUgMuURRzyMAg45+sez6mtNqtFdM1HaqCn3oIpDHCBuhPVSPLz88c9F2+y2qz1Dx0FspKeOqQxybY/aA/Cc/h93TTaEjnd2ray2RXWajtMdJcmp/wBqCX04VCxpIWVphmP2hnBUdR0OthuHG9xorlX072+2h6VlxG9wcSVCshZWT7sqMhW5EjBHPsS8HBnDQUL+wqAgHPOPPy+HIcunu1b/ANJ8P+iNSmzURgaQSlTHnLAYznr05Y8jpSEMYU1cbjZIq6jkWIVNKKiFqgZVNyblLjI5DIzzGk/C9Xcbra7h6XPHU0ol2UVZHD4InTaMttyfV3ZAPcDOnFclE9FJR1UcTU0kfhNBjkUxjbgdsctB2S20dsLpaqBKOmcDfjILEdORPv0DBhiSPDDG4YI8tNqSpRqVGldQ4G1snuOWl9UnhVci9m9dfn1/XP115DKYhMqnDMu5T5Edf0/hq2pRmnDClaVBOtOrEM25W28hnr11IJTTwiN5IRgnGTk/QaIFJE3OQvJ/vY6ujijj9hFX4DUyi4YuaVpagAiSQAbl2jZz76uWGYnIihj97Eu2rar1JqeTybYfnonQ2EC+V6yF9qgSjru24+WpphqaU/sOBbdVG+I+YIPv6a9kYm2RSE+um0g+/ONTU1Xsifdh7najEdQM6WwTSVc7Ru7Ig7Jy1NTSpHUHxQRRfu0APn3+urdTU1JQuu6jNO/4txX5EZ/kNLajlHkciCP6fz1NTWlODKrJsEPOFP8AaNZ6mprM1BakeJUwRMTsOWIHcjporU1NNiRNTU1NIZ//2Q==: Live location: 12.9782227, 77.7100528 — https://maps.google.com/?q=12.9782227,77.7100528

[8:41 PM] **Aashu:** [Forwarded] https://www.facebook.com/share/r/1BysLXmnjn/

---

## August 31, 2026

[7:02 AM] **Aashu:**
> _You: Video_
😍

[6:40 PM] **Aashu:** [Document] OD337455302788072100.pdf

---

## September 1, 2026

[7:56 PM] **You:** [album message]

[7:56 PM] **You:** [Image]

[7:56 PM] **You:** [Image]

[7:56 PM] **You:** [Image]

[7:56 PM] **Aashu:** kon beja papa

[7:56 PM] **You:** Nhi

[7:57 PM] **You:** Hum edit kiye

[7:57 PM] **Aashu:** gajab

[7:58 PM] **You:** _Waiting for this message. This may take a while._

---

## September 3, 2026

[11:58 PM] **Aashu:** hello

[11:59 PM] **Aashu:** ye college wala akshat aaya hai yaar

[11:59 PM] **Aashu:** time lagega aane me

---

## September 4, 2026

[12:00 AM] **You:** Ye kon h

[12:00 AM] **Aashu:** are benchmate

[12:00 AM] **Aashu:** hum teeno ek bench par hi baith the

[12:02 AM] **You:** Okk

[12:02 AM] **You:** To aana to uthana humko

[12:04 AM] **Aashu:**
> _You: To aana to uthana humko_
ok

[12:04 AM] **Aashu:** iska bahut bhayanak accident hua tha

[12:05 AM] **Aashu:** mar ke bacha hai na ye

[12:06 AM] **You:** Ohh

[12:07 AM] **You:** _You deleted this message_

[12:07 AM] **You:** [Image] Papa ka birthday 🎉🥳🎂

[12:08 AM] **Aashu:** happy birthday 🎂

[1:58 AM] **Aashu:**
> _You: Video: I’m forever grateful to have you in my life Papa happy birthday 🎂💞🌎_
Happy birthday 🎂

[5:18 PM] **Aashu:**
> _You: Video_
😍

[5:21 PM] **You:** [Video]

---

## September 5, 2026

[2:22 PM] **You:** Hello

[2:22 PM] **You:** So rhe ho

[2:30 PM] **Aashu:** nhi

[2:30 PM] **Aashu:** kab aayegi

[2:30 PM] **Aashu:** location

[2:39 PM] **Aashu:** nahi aayegi aaj kya

[2:43 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQCAwEFBwYI/8QAOxAAAgEDAQQHBQYGAgMAAAAAAQIDAAQRIQUSMUEGEyIyUWFxB1KBocEUIzORsdEVQkNy4fBTYiSisv/EABoBAAIDAQEAAAAAAAAAAAAAAAECAAMEBQb/xAAqEQACAQMDAwMDBQAAAAAAAAAAARECAzEEEiEFQVETFGEGcdEiIyQykf/aAAwDAQACEQMRAD8A+ioXZTuwOQR/Rl+hphbtAd2YGJ/BufoatmhjmXEig+B5ilZRJDhHH2iJuCkdofvTZJgxFAbhxPIcBmyFI/lHD96xfkz3EVsvDvOfCmoJ4pRiNhkfynQj4UvCpgvJDKpJlOFcaj08qkgJbQSFLYsUG8BhCNDnlSlrC6Rda8XWo3Id4DxFTvCbq9SBe6vH61swAAABgDQVJhEiWKo+/H2SJ4uanvD96rEcCffLKVij7RQ8AfTlU75ERetXKzcFK8WPh51rZMM+7o26TvN7zc/gKKUgbglLI00plfQnRV90eFYRd8gkP1IOHZRn4VW5ZnWOPvt8q2kST2kaoqrLGo/l0b/NF8CpTyYkxKIntdyRIterBxTEFwk2QMq44o2hFJ3LwSITGpW4yAB3WyaultnZV3sSMODd1h8edKOOUVrGe6U7vWgY95Dn5A0VNodxsjoNaqg7bGY89F8h/mqTOtwyw4ZGPfVtDjw+NOUMEyVTW8c2rr2hwYaEfGqv/Ig4ffp+TD96ZOcHBweRpF2mSeNrhSY0B7UeuT4kVERk90TkT2z7koG6QR8iK8n0n9olhsKd7QW8l3tBNHjjYBEP/Z+R8gCfGtz0gv2stm7Qv9nFTLBaSztnundUkZHjpXzZe3DxRPM5MkrHJZjksxOpNY9ZqKrSVNOWd7ofTLetdVy8/wBNPbydXj9qcV1dKL7ZslrDjdEkU3W7meJI3VPDwzXt7W4guLSKe1kWSCRQUZNQwPDFfM+z7155THIBwyCK7H7Erky/xCzmYmO3ZJYVPAF97e/+c+pNV6TV11V+ncNXWejae1Y9zpuEsr78HQLVTDMH7Jm5xv2TnyPOtlFdRu262Y5PdfQ1ZLEkq7sihh50rLaOFxGRInuSa49DyroymeWiBmaGOYYkUHz5iqOrng/CbrU91zr8DS6SPC26rFD/AMc3D4NTSXabwSYGJ/BuB9DU5DwY+2xDSTejbmrKaKZ0NFDgnJhkVmBZQSOBI4VKiigEKpuZuqQYG87HCr4mrHbdRmxnAzikrNzcXLSSYyqjdA1AB+tFIDYvtHZyTWEsc4dxcK0c+7zRgQwx6V86bc2VLsy/n2deDeMZ0fGBInJx64+ByOVfTd5N1Fs7jVuCjxJ4V4Hp10eXbOxWaFc39spkhYcXPEof7v1way6vT+tRKyjs9F6ktDe2V/0qz8fP5OIQW0VtvMgxpqSeVdy9mPRyXZewnuLtNy7vWEhQ5Vo0A7AzyOpJHnjlXi/ZX0dXbV9LtK4UNa2ZXq1PB5Trr/aMH1K+FdlIRdWRoj7y8Pl9ay6Gy1+7Vnsdb6h16q/h28LP4MpcSxNuv94AcYOjfsabhuI5tEbtDip0I+FL24+57eu/2jnnUZLZH4dkjhzx9RXT3Jnk9lSUoddFdSrqGHgaVe0KqRCwKf8AHJqv+KqE1xb/AIg6xBzP7/vTUFzFMcKcN7raGjyhOGJBSnZ3LqP/AKxnK/CitpRRkkBRSPVW44RzR+ahvpQdxO7dyr/fr+ooQSS+9cpAQurv2FHmalbwrBEEQDTifE0qUkeVHW4hlKZwCMfpVrzTxIzSRIVUZJV8YHxqR2J8im0pesuVjB7MWp/uP+P1pUguyxqcM5wD4eJ/KhcnLN3mJY+ppjZ6b0ryngvYX6/QU7e1C0rfVBDZOx7TY1s8Gyolt4WdpTHqQWPE+NMzO25uOhG8cZU505+dM1UMvPoCd3sgeJP+iqKeDZW2+W8k0dXHYYH0qVeI6TdOIdn3strsmyTaF1ACZZ3yY0I44A1IHM5Fa7ZPtJmeRW2xsyJbRn3DPaBk3D6EkMfLIql3qE4k6VvpOsrt+qqOPup/w6QDjhVMttFJy3W8V/asRXMUkccsTdZBIgeOZRlXU8/KrlYMMqQR4irk2sHMdKq4YsEvI+zHKrLyJ4/OimqKbf8AAnoryY+zEdyeYerZ/WoS287gDrwwBBwUxw9KtjnZnCvDIhPPGR+dX00spgUZJz34beT5frSd2ymFkEPVvvhSAcjxPyFbUSIWKh1JHIGtNK28c+8zP8CcfSmpFqIE4BNP2SdXaxA8cZPqdTSB4VsFh3VAR2UgeOR+VC54HsZbLWIVSTwAzWsv7iW2sbx4iRcJYzzx4474Gn60zcmTd6tiCD7oOW8vKq79DbqlzBEJJI21jP8AUU6FT8DVccGhVRVMTByr2ZiBrzbi3jOlsdkziVkGWCZTJHnjNO7fj2VF7N0XYc9zNbfxYFmuFAYP1JyNBwxiobU6K7TsGuLzosZrnZt1G8TLFrIiHvRMvE8OXhSOyOi/SXaFuNnvb3Fns4TdfIbperRGxgvg4J000rnRVStm3k9y7mnvV+8V5KmU4nwu6zPg9p7MriVuiVusmcR30kUen8hQMf8A2Jr2DRIxzjDeI0Nafo9Z29vbW9vYh/sFopWKRtDM7HLSenhW7JwMnhW2hOmlI8fq7tN+/XdpXDbYpPNLE+6p3xjiVzRV8Iym8Rqx3v2+VFW7kuxk2t8yO0UUUSkXvApiI3ULsQi7wzqTgVxfaXSfpPfbBv8ApHsOaztdh2lz9l6poUkmPdw7b6Ea768COPDnXY9qyiGCGRjhVnjZj4AMCfkK4j0U2xs7YGwp+jXSOR4BPfzxX0XVsSkTQqFkGAQcOoxjXnwq23gpuZN7sPbnSOwvOjZ6TSWlzabfIFt1MaxyxElN0tuqowd9fHQ8RiupwuJYkccGGa47dbeg6WdJ+iX8MJkNhtGaeSMIwENsskZQ5Ix3I/z9a65aMEsImPAID8qS8sF2nefBlwWlaRc/d6AePj/vlWQwmdCudxe1kjieVWQqVjUHvcT61lF3AQDpnI8qqk0JMSeG4tLprvZu5vv+LC+iyefkfOi4N9tUiO9jS2swctEjljIfAnA08sU/WCcDJoSHapkim6CUQYCgDThUZ9VCDi53fhz+VZgHY3jxc73+/CoEsZyVXeCjHHGv+4opcgb4L6KqLSD+mD6NRQgModoooqwzGu23rahSMgk/oa8htDZ9tLP9/BbT7owpuLaKYqPAF1JA8uFFFOsC9xvo9s+2S5ZI4YIoyAzJBBHCrEHTeCKM/GvUXPZt3I5Ciiq3kvpUUk42LIpPEipUUUhagqm6JED456fmaKKNOQVYZi0kMsWWAB4aVKD8MnmWJ+dFFR9wLsW0UUUox//Z: Live location: 12.9827025, 77.7283976 — https://maps.google.com/?q=12.9827025,77.7283976

[2:44 PM] **Aashu:** aaj late se nikli ho kya

[2:44 PM] **Aashu:** abhi mere office ke pass hi ho

[2:46 PM] **Aashu:** biryani lane me late hua kya

---

## September 6, 2026

[4:28 PM] **Aashu:** ghar pauchi

[4:33 PM] **You:** Hmmm

[6:47 PM] **You:** Hello

[6:47 PM] **You:** Kitne baje Tak aaoge

[6:47 PM] **Aashu:** yaar dimag kharab ho reha

[6:47 PM] **Aashu:** 6 baje hi nikle hai

[6:47 PM] **Aashu:** traffic me fashe hai yaar

[6:48 PM] **You:** Ooo

[6:48 PM] **Aashu:** 50 min abhi bhi dikh reha

[6:48 PM] **Aashu:** [Image]

[6:48 PM] **You:** Okk

[6:49 PM] **Aashu:** khana ka

[6:49 PM] **Aashu:** kya karna hai

[6:50 PM] **You:** Soch rahe egg fried rice bana dete hain

[6:50 PM] **You:** Kyaa

[6:51 PM] **Aashu:** bana lo

[6:51 PM] **Aashu:** bookh to gaand faar laga hai

[6:51 PM] **Aashu:** aaj jeet gaye are humlog jeet gaye aaj

[6:51 PM] **You:** To abhi 
Chawal or sezwan chatni or dudh order kar do

[6:52 PM] **You:**
> _Aashu: aaj jeet gaye are humlog jeet gaye aaj_
Waah 😂😂

[6:52 PM] **You:**
> _You: To abhi 
Chawal or sezwan chatni or dudh order kar do_
Kar do fir chawal chadha denge

[6:53 PM] **Aashu:** suno na

[6:53 PM] **Aashu:** tm apne hisab se kar lona

[6:53 PM] **Aashu:** hum aate hi tmko bejte hai pakka

[6:59 PM] **You:** Okk

---

## September 7, 2026

[5:11 PM] **You:** Corn flour 
Milk 
Coriander leaves 
Onion

[5:12 PM] **You:** Chat masala

---

## September 9, 2026

[3:24 PM] **Aashu:** [Forwarded] [Document] 4244446685.pdf

[3:24 PM] **Aashu:** [Forwarded] [Document] 4144446107.pdf

---

## September 10, 2026

[12:04 AM] **You:** [album message]

[12:04 AM] **You:** [Image]

[12:04 AM] **You:** [Image]

[12:04 AM] **You:** [Image]

[12:04 AM] **You:** [Image]

[12:09 AM] **You:** [Image]

[12:15 AM] **You:** [Image]

---

## September 11, 2026

[12:18 AM] **You:** https://chatgpt.com/s/m_6aa2fb8fdd5c819180a3503dc9091014

[12:19 AM] **You:** [Image]

[12:19 AM] **You:** [Image]

[12:27 AM] **Aashu:** [Image]

[12:33 AM] **You:** [Image]

[12:45 AM] **You:** [album message]

[12:45 AM] **You:** [Image]

[12:45 AM] **You:** [Image]

[1:49 PM] **Aashu:**
> _You: Image: Six months of marriage, with a lifetime of love ahead. ❤️💍_
😍

[3:07 PM] **You:** 3 baj gaya

[5:08 PM] **You:** [Forwarded] [Video] Adarsh & Swati.mp4

---

## September 12, 2026

[4:00 PM] **Aashu:** hey

---

## September 13, 2026

[1:08 PM] **Aashu:** [Forwarded] [Image] All members need to join today evening compulsorily irrespective of which group or contributed or not. 

Please share the same in your Residents' group and tenants.

[1:08 PM] **Aashu:** [album message]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[1:08 PM] **Aashu:** [Image]

[8:11 PM] **You:** Kitna time lagega

[8:16 PM] **Aashu:** kl aayenge

[9:24 PM] **You:** Kya karna h

[9:26 PM] **You:** Baithe hi ho

[9:26 PM] **You:** Abhi

---

## September 14, 2026

[12:32 PM] **Aashu:** [Forwarded] [Video]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:15 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:16 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:17 PM] **Aashu:** [Image]

[4:18 PM] **Aashu:** [Video]

[4:42 PM] **Aashu:** [Document] IMG_5128.HEIC

[4:42 PM] **Aashu:** [Document] IMG_5131.HEIC

[4:42 PM] **Aashu:** [Document] IMG_5125.HEIC

[4:42 PM] **Aashu:** [Document] IMG_5126.HEIC

[4:42 PM] **Aashu:** [Document] IMG_5130.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5133.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5123.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5121.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5134.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5127.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5132.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5124.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5119.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5120.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5118.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5129.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5122.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5114.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5109.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5115.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5110.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5112.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5117.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5113.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5111.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5116.HEIC

[4:43 PM] **Aashu:** [Document] IMG_5108.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5098.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5103.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5101.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5102.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5099.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5100.HEIC

[4:44 PM] **Aashu:** [Document] IMG_5096.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5094.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5095.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5093.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5097.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5091.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5092.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5090.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5088.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5086.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5087.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5089.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5085.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5084.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5083.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5082.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5077.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5081.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5080.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5079.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5078.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5076.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5067.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5066.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5064.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5063.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5065.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5059.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5062.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5060.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5057.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5061.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5058.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5056.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5055.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5054.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5053.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5052.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5050.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5051.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5046.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5048.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5049.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5043.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5042.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5047.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5041.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5040.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5039.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5044.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5036.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5038.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5037.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5034.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5035.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5033.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5032.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5030.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5031.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5028.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5029.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5026.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5027.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5024.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5025.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5022.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5023.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5021.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5020.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5019.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5017.HEIC

[4:45 PM] **Aashu:** [Document] IMG_5018.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5016.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5015.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5013.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5014.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5011.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5012.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5009.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5010.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5007.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5006.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5008.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5004.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5005.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5003.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5002.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5001.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4998.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4999.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4996.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4995.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4997.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4992.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5065.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5066.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5064.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5063.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5062.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5059.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5060.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5061.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5056.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5058.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5057.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5054.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5055.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5053.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5051.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5049.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5048.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5052.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5050.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5047.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5046.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5044.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5041.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5042.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5043.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5038.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5039.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5037.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5040.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5036.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5033.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5035.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5034.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5030.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5032.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5031.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5029.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5028.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5025.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5024.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5027.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5022.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5021.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5026.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5018.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5020.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5019.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5016.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5015.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5023.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5014.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5013.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5012.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5011.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5008.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5017.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5010.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5005.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5006.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5007.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5004.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4998.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4997.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4999.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5003.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4992.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5009.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5002.HEIC

[4:46 PM] **Aashu:** [Document] IMG_5001.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4995.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4977.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4996.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4978.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4989.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4990.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4991.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4976.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4971.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4972.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4970.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4968.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4973.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4969.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4975.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4979.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4974.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4966.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4964.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4962.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4963.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4967.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4961.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4965.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4959.HEIC

[4:46 PM] **Aashu:** [Document] IMG_4958.HEIC

[4:47 PM] **Aashu:** [Document] IMG_4956.HEIC

[4:47 PM] **Aashu:** [Document] IMG_4957.HEIC

[4:47 PM] **Aashu:** [Image]

[7:23 PM] **Aashu:** 🌺🙏 🌺 GANPATI BAPPA MORIYA! 🌺 🙏🌺

Dear Residents & Families,

With the blessings of Lord Ganesha, we have lovingly prepared pure, sattvic Mahaprashadam without onion & garlic for all our residents. ❤️🙏

So, please don’t prepare dinner at home tonight come together with your family and enjoy the divine prashadam with our Skandagiri community. 🌸✨

🍽️ Tonight’s Mahaprashadam Menu
🍚 Pulao Rice
🥗 Mixed Vegetables
🥣 Bundi Raita
🍯 Dates Chutney
🍌 Banana

⏰ Dinner: 08:30 PM onwards
📍 Venue: In front of A Block Pandal

Let us come together, seek Bappa’s blessings, and share the joy of food, devotion and togetherness. 🛕❤️

Ganpati Bappa Morya! 🙏🌺

Team SKRWA

[8:26 PM] **Aashu:** hello

[8:32 PM] **Aashu:** hello bhai

[8:35 PM] **Aashu:** kaha ho bhai

[8:36 PM] **You:** Kya

[8:36 PM] **You:** Change kar rahe hai

[8:37 PM] **Aashu:** khana khane chalegi bahar

[8:38 PM] **You:** Kahan

[8:38 PM] **Aashu:** bahar

[8:39 PM] **You:** Bahar kyu

[8:39 PM] **Aashu:** ye log bol reha bahar tmko bhi lekar chalne

[8:39 PM] **You:** Kon kon h

[8:39 PM] **Aashu:** visjal nandini chodhary nitin ersina

[8:40 PM] **You:** Ohh

[8:40 PM] **You:** Thik h

[8:40 PM] **Aashu:** chalegi

[8:40 PM] **You:** Hmm

[8:41 PM] **Aashu:** mood thik hai ma

[8:41 PM] **Aashu:** na

[8:41 PM] **Aashu:** vishal baar baar bol reha bhabhi ko lekar chal

[8:41 PM] **Aashu:** bilkul milata nhi unse

[8:42 PM] **You:** Haa thik h

[8:42 PM] **You:** Chal lenge

[8:54 PM] **Aashu:** okk

[8:54 PM] **Aashu:** batate hai

[8:58 PM] **Aashu:** ready ho jana

[9:09 PM] **Aashu:** so gayi kya

[9:09 PM] **Aashu:** zoomcar wala ka wait kar rahe

[9:10 PM] **Aashu:** jaise wo aaye apan nikalte hai bro ok

[9:10 PM] **You:** Aaoge ya udhar se hi

[9:10 PM] **Aashu:** thar taste of rajasthan jaa rahe full authentic khana khilayenge aapko aaj

[9:10 PM] **Aashu:** hum to ready hai aap ready ho jao mam

[9:10 PM] **Aashu:** veg khana khilayenge bahut authentic

[9:11 PM] **You:** Haa haa

[9:11 PM] **Aashu:** daal bhati churna

[9:11 PM] **Aashu:** kichwa

[9:12 PM] **Aashu:** kya pehan rahi babu

[9:15 PM] **You:** Saree

[9:16 PM] **You:**
> _Aashu: daal bhati churna_
Nahi mujhe nhi pasand h

[9:50 PM] **Aashu:** [Document] IMG_5164.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5168.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5158.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5174.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5165.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5171.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5176.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5074.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5172.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5156.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5173.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5157.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5162.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5161.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5166.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5160.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5169.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4982.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5075.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5167.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4988.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5069.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5155.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5163.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4984.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4983.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5170.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5072.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5073.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4986.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5070.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4985.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4980.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4987.HEIC

[9:51 PM] **Aashu:** [Document] IMG_4981.HEIC

[9:51 PM] **Aashu:** [Document] IMG_5175.HEIC

---

## September 16, 2026

[10:29 PM] **Aashu:** [Forwarded] 🙏🌺 ॥ गणपति बप्पा मोरया, अगले बरस तू जल्दी आ ॥ 🌺🙏
Dear @all Residents & Families,
With heavy hearts and immense devotion, we have successfully concluded the Ganesh Visarjan ceremony.
A heartfelt thank you to everyone who joined, offered seva, and made these celebrations so vibrant and memorable. May Lord Ganesha bless our community with peace, happiness, and prosperity! ✨

📸 Cherish the Memories:
Relive the special moments of the celebration and contribute your own pictures/videos by uploading them to our shared album:
👉 Click here to view & upload photos/videos
https://photos.app.goo.gl/NZgBGCdi61BDqUec6


Warm regards,
Team SKRWA

---

## September 17, 2026

[12:24 AM] **You:** So rahe ho to aa jao yahi

[12:24 AM] **Aashu:** nhi so rahe

[12:24 AM] **Aashu:** [Image]

[12:24 AM] **Aashu:** soyenge wohi

[12:25 AM] **Aashu:** aadha bed chor kar sona

[12:25 AM] **Aashu:** aa jayenge thore der me

[12:25 AM] **You:** Padh rhe ho kya

[12:25 AM] **Aashu:** hh

[9:19 AM] **Aashu:** Dear Residents,

Panditji has arrived for the Morning Aarti and will be starting the Puja in 13 minutes, at 9:30 AM.

We kindly request everyone to join us near the Ganesha Pandal and seek the blessings of Lord Ganesha. 🪔🐘🙏

Thank you for your presence and support!

Ganapati Bappa Morya! 🌺

[11:43 PM] **Aashu:** [Forwarded] [Image]

---

## September 18, 2026

[4:28 PM] **You:** Aaj fir kuch accha ban raha niche

[4:38 PM] **Aashu:** [Forwarded] [Video]

[7:52 PM] **You:** Cultural program chal Raha hai

[7:52 PM] **You:** AAP join karna chahenge Sir

[7:59 PM] **Aashu:** hum bhi aa gaye

[7:59 PM] **Aashu:** main time par kaam aa jata

---

## September 19, 2026

[2:42 PM] **Aashu:** kaha pauchi

[2:42 PM] **Aashu:** location nhi bejna kxa

[2:42 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAECAwQGBwUI/8QAOxAAAgEDAgIHBQgBAgcAAAAAAQIDAAQREiEFMQYTIkFRYXEUMoGhsQczNEJScpHB0WKCI0SisuHw8f/EABoBAAMBAQEBAAAAAAAAAAAAAAABBAMFAgb/xAAqEQACAgEDAgUDBQAAAAAAAAAAAQIRAwQSIQUxExQiMkEGgdEkYXGRwf/aAAwDAQACEQMRAD8A+lfaEHvZQdxcYzUkba1DAEA8s1DOpmlEYYhVGpiP4A+tTqNKhRyAxTAWkwNWrG+MZpaKQyN4InOXjQnxI3qL2RRJqR5F2wAGP91ZoosKIOrmX3ZtX71B+mKYZLhHJdEKKuSQ2PrVqvK4zcNFwS8uZH0xCFzpC5JGDjmedNK2JukcuaJpXknguIHd2aVcNoySSfzYrqNvb2axxwmRusVACxc5J5d9cu4Ta+0cSs4FBZDNGDt+XUM/KuyFFJJKg52Oap1DqkT4Fdspnh6HdJWx54NRPw0n80beq4q6bWHujCnxTs/SmC2ZZCyTSDYAZw31qfczfail7BMNgq48moq+VuRyliI84z/mijcxbULbbx9Yecna/wAfKpqZEFWNVQ5AHjT68s9oKglk1nq4mBc8yD7o8aW4GoxIfdZtx4gAn+qlVQowoAHgKYEbSlXKpGz6RuQf/c1mOlvTjhvR1REwkub5hkW8YwVHi5Puj5+VaWBlMk24yX5egAr5c4nxGW9nuuJXJLzXDGZ/U749BsPQVJq87wxSj3Z2uidNhrsknlfpj3NVxr7Sek91dPJw+SCyt+SwrEkpx5s67n0x6V63DOkHSCe34Lb8dvbK8sePs0EHUIqSQSKygBwqgY1MoI32J5Vyqzv5JLgJIFw3LHdWj6LpLJ0u4GVLGC2ulu5BnsoqFWd/LsqP4FZ6PW5HkWPJzZf1jommhppajTWtvdW2n/Z0PoczScctljPvqxOPDH+dJz5V1KIFZ2RWYqFBOo53rCfZrw5oQ9/cRtkp1cWBnI5k7ee3wrdKwhieWbsljk/0K62d3KkfH4FUbYSSym4MUITsrkls1HDNcupYRxsMkbNjlS2LaxNMwI1t3+Ap9h+EjJ78n+TWPY17idfMOds2fJgaKs0UrHRWt4YmhBaNCdzkqPGn24CmVBsFfYfAGm2sUYt1wi9pd9udLbqqSTKgAGobD0FDBDpfvYfU/Q1LUUn38Xx+lS0hjJEjcjWqk92RXzn036OydHeOT2jxn2KUs9q/c0ZPu+q5wfge+voqcAgaousHw2/ms70m4HadI+EzWcxMLEarZ2z2JByYeXcQOYzU+p0/jQ47o6nSOo+Qz3L2y4f5+x85Q2kMLl0XfzPKtP0W4fLMxmIk0zgRpGpx1i5B38iwXHoDXmcO4fJccTa2uo2T2diLhD3MCRoPxB/g11PoDZtdcZdxtBbx6mx+o7KPLkT8BWXTNK1+on8djrfUvVIqPkcHzTk/27pf7/BueFxJwjh8FkYisMK6Q43B8SfMnNT9YlxdZ1L1UW435t4/CpJFmUbMXXyA1f8An5VFFCJFLCKErnbMekmr7vk+T7cEtiNVkoP5gT/JNIkVxCoWORHUbAOuPmKj9mAOeowfGOT/AOUyZ1tonlkuJ4Y1xlpBqAycf3QF0uTxukPSmfhfETa21glyFQF3abRhjvgDSc7Y386KXiPCeE8ZvpnvJbea5tyIJCcqVOA2DuO5x/NFbx8JLlckGRalybhNV9vwaS1/DReag0Rfez/uA/6RTIHZbeECN2GgbjHh6063Oppjgjt8j+0VOdBCv+Ii/a39VITgZNRt+Kj/AGN9Vp0qdYmknAPPzHhQBA8huAEiBGRqbUCNvD40smtlCvHpjXtMQQQQO6pJVIdHQZK7EDvFed0gvxa8HupDqifQQpfYajsBmmlbpCfHLOT3awScX4hd20Sp7TMWbT+YjbPx3Pxro/2f2RteBdc4xLcuZSDzC8lH8DPxrm0EDTSQ20GQ8jLEnkSQBXY47a3LtD1X3aqM53O1U5qjFQRhicpyc5O2XajgUrHhhg5P1qL2RR7kkqejmhopkUlblsDftKDUpQWaq8UtFv8Ahl3aOcLPE0eeWMgjNNge6aJHxEwYZxuDStdSI6rJbsC2caWDZxRTT4E6apmPuOhVxxCO3uLq8e3vHQtcLC5CmRmZm9catI8lFFbL2tO+OUHwKGitfGyIleiwPloIZcQxgxye6OQ8qIplDS5WTdv0E9wohkDwIsTprCjO/L4U62XT1oyTh+Z79hWRURSy6p10My9kgkoc8x3U+OdEBDyZGdiQQfjUh/FL+w/UUXHKP94oGKs0Te7Ih/3Csb9pV1i2s7VTtI+tvMAf5xWyMStIXfDbYAI5Cub9O7gvxeOFDiJYtZUbDJYgbei/OtcCuaMszqJB0HtRddJrcsMrbo8x9dlH/dn4V0uaF+tEsLhXxghhsRWH+zePrLriDbKY0jGoe92i23p2a36jCgZJ8zTzv1hgXpIM3XhAfiahuLrFvIkqGOUqQAeR9DV6q3EMeySZGdtvWsV3NWTxrojVf0gCoG7V+o7kjJ/k0CO5QDTMr+TL/ioITcm4mcLESCFIye7wppBZ6FFVvaJRs1s+f9JBFFKgsdbtJ7OuEGQoxltjTbUB2eRkKvq5E8thSxMkUStJNgFR75AFQi8hVpRkuGbI0jORgd/LxpiLP/Nf7P7pLnP/AAtOM69s+hrz/axHIXhhCgjHabH0qN72WZlAcZByBGud/nRtYtyL19ctaWVxPOVCRoWytcj4heScQvZbqUaS+AqfoUDAX+K9/pH0gS6gktbaSSTtFXcns7eHj614nB7B+J8RitVRmRvvCDjSvjnx8Krww2JyZNlnvaSNv9nVg1vwqW8fY3bAqP8AQuQD8dz6YrW0yGNIYUiiUJGihVUcgByFPqSct0myqMdqoKrXnaMMf6pBn0G9WaqXCLNeRo2cKhbY48qSGy3Vax3hZ/1uzfOmSwGKJ3SeUaQTgnIpLeO5jgjCPGRpBwwIxRXAXyXaKrdZcjYwK3mHxRRQWeHO3VYKKuT5V6lrZxyxB3ZznuzgfLeiitGZxEvoo7aJDFGgZjjURkj4mvB6dSvw/hKi1OhpCEZ/zYY4O/pRRTxcyQZOzOfABQANgNhXRehdrFD0cs54hpmuSZZH7yQGwPQeFFFUZ/aT4fcapDqRSeZGadRRUJaFVo976YnuVQPnRRTQmLxD8HJ8B86nAwMDlRRR8B8i0UUUhn//2Q==: Live location: 12.9946242, 77.7575981 — https://maps.google.com/?q=12.9946242,77.7575981

[2:43 PM] **Aashu:** tm khud ye sab me active rahegi

[2:43 PM] **Aashu:** ki humko bolna parega ye sab

[2:44 PM] **You:** Abhi dhup me khade h

[2:44 PM] **You:** Soche bus me baith ke bhejenge

[11:22 PM] **Aashu:** [Forwarded] [Video] Skandgiri Fun❤️❤️❤️

---

## September 20, 2026

[1:32 PM] **Aashu:** pradad to bahut accha tha baby

[1:32 PM] **Aashu:** mazza aa gaya

[1:34 PM] **Aashu:** bahut rush tha bahut log khaya

[2:03 PM] **You:** Mujhe bhi khana hai

[2:10 PM] **Aashu:** khatam

[2:10 PM] **Aashu:** location bej do

[2:12 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAMEBQYHAQII/8QAPxAAAQMDAwEFAwkGBQUAAAAAAQIDBAAFEQYSITETIkFRYQcUcRUjMkJSgZGhsRZigsHR4TRDcpLxJFRzg7P/xAAbAQACAwEBAQAAAAAAAAAAAAAAAQIDBQQGB//EAC0RAAIBAgUBBgYDAAAAAAAAAAABAgMRBBIhMUEFExQiMlHRBhUkM2FxYrHw/9oADAMBAAIRAxEAPwC32bSUy5SdW2WRHcTEtMeVGthUkgFb7pdQpPw2I6edWn2ZypDWkrvqW8NPNy50l6ctrbhwobSEJRjGfqHHxqz2zVNintT3Il8gPsxPnHlJfBDScfSPpweelL2vUFru8R2XaLhGmMtZ7RxpwENcZ73iOhoWoWMgTZ9WRtKx76WbeuW1NGoVtpDolKK/pIIxjGw4KfIVontFHvvs2vi4TTqxIh9o2jaSohW0jjrmkbj7QLHFgTpke/WZ+W3HUplr3nhawCUg455PlUrYb58q6RhX6a4IKHogkPblbUN8cnJ528ZHpSnwESLlIV8nxW9qt/ycobcc57DpiqC3pFk+xl2TtuvygIAWGfe3tpVnlPZZx5cYq5Pap04uXHec1LayEDvFMsbvy5px7P7+9qPTzdycbDDy5jjSlNKUULCSkBSd3OMYHxB6VbLW1iC5LLa0AWiAlxhRUIzQOUjrsFZ09pqTdtS63kQkrjXaLNiyrZIUjA7RLJ7ufFKvonw5HlWhXm+2+yqaF3u8GEp4EtiQoJKsdcc+oqtzPaNCVqjTlps0qDdUXB5bckx1la2RjuqGDgDOSc+ANVpW2J3K/oi5z7V7L9R3h2BJZuSp8p1mMEKKg65tCRtxkgKPl4GmcWy3/SH7Kz5CLe7GtLpjShD7RTym5B76nMjCsK548a0iZrKx2+c5EuF8tjD7Strja5QSpB8iKidFazZu9lvN3me6xYsOc5HMpLhSy42CNqwVee4f26UxDC+PDTftClXWeqS3arlbEw/f2Gi6YryFcBQAO0EEEEjGfvpxoa9TjbdRXCfNuNxtcR3tIT8mMG3H20t5VtTtSTlXA4qWTr7TAyf2htQPpKTUdZPaHD1Bq1dqskUTI7Sihyb740joMlSGyd609BuAxQBEaFt2s4ljMpKNPpdujqri6JqXu1C3cHCgOBgYGPDFFaT2bbpKltDd+8kZooHY+a0sMR7M9Evsq6W69uREW1xl+0ZbTHSd21vs8bjvCFBZ54Oc5zWgeyO2XZd1vl/mQFtRn4TcVhp5gRzMUhIG8t9Eg7fh3q1WMpYZRuUc455rjZKn3lHnGEj7hn+dJO6Cx8xRINrXbVtXG3TlXhCZCI9kiWtaSh1wFIUt5RK1gd0geGOB57LDVcGvZ0/Ynlof1PGse9UVbRUo7kqCOvdUe7txzyOetSevo2o5qbenTchtKUKWZLKnwyXAdu3vFKspHeyOCcjyqK0Rp6fZr7c7hKhQojT0VtjbHlLk9q4hSj2iSsbkJwcbcnkA0NgjLLFN07EjWOJMs0ldvTFcbvBXbgtRkKHB3kbxgj6p4yOlTmitbpsOiYMCbHflS2XnOyYX3OzZyCkLJ6HrgYPGPDFXnVbzMVtF5McO3WBDe93kKcX3MpOe7nB+JFYTMfW20t5ZU44o5KlHJUonkk1y4yvKgko7s3Oh9MpY5yqVn4Y8epfNS+0Z+5txURdO2VBaKsrno96AB8EgJSU8jnGfypTT92jXbXelJ2mLG7bLosLZvDTLBTH7HA72R3SOpB+A54rNYExbzpQ4B0yCK2v2HzJD0K6wFPOBiOtt1tIPTfu3D4ZRn4k1RhcVOU+zqHd1jo+Ho4fvOG0S3QrpyxRL57T9bS75aWXmo5YjRg+wCgpUFb1DIwVHaOevNRem7fdnvZXrOwwmHluRJciPAbeRkqayDhORyfpYPmfStd2Of9w4R6gf0prF3uOvBx1wlKvteprSPKGD3d6y3XRltsOm9MSW9UoUyhKTA2rYcSRvUtwjvA89fPJxitMs/s0tlo1Q3eY0hwKZddkNRUtoS2hxxO1XeA3FHkknA/HN22ueEh38v6VwNuDHzyj8UigLCtFFFIkcBGMZFJRuUKV9pSj+dNff2MfSUD5FBH8qGJUdLSEqebBA5yrHNVqUkth6N7jk8yF+iEj8zTU9oISlbk7dhPTnp8a9tPtFxwh1BBIx3hyMUnLS0mMsthPOAMHzOKTd5W/QWsir6iZRIbMd0ZbcaKFD0PBrEJ8B2Kv3eY2e8gLSSMBxB6KHof1BHhW3XpeJCyPqo/vUdqLTqL5ou1pjJ3XCNES6yR1USgKLZ+OPxwaMfh+1pqS3RqdB6l3Ku4T8kt/f3MXZjtR9ykDHmSfCt59lWm37NY1yZe9mZOIcU2QMoQB3EkHx5J9N2PCqL7KNOJvVwXcpH+EhqT2YIyFu4yP9owfiR5VtCWZIHdkZ+I/5rhwFFX7ST14Nb4i6in9HSWi39hxsdHR38U00iIQp6R2wQohXUj1NKbJo/wA1s/H/AIpOAhKlPl1KVKCuSR6mtXg8lyLlMYfWSn4Lx/OuEsDpIx/7f6mulTaJKs7QNgxgepr2H2R9dI/KgBRsgoG1W8faznNFCVBacpII8xRUSRAFxA6nHxroWg9FJP31MOJQUqU6MpSCo8c8VXU6js71stU9JdMe5vIhx0lrK0uKWU94Z4AI5NEaubgg6duR2UpPUA/dXA2gHIQnPnivUyVbWrqi07E/KLkcyEYbGMAkAFX2jtUQP3T5UzNzt5uZiNsymimQYfbqbHZLe27tmQokcZ5IxU1O/AnCw4cjtOZ7RtCs9civSUJSkJRlIAwNpxj4YppaXmJF4lW8y3DMjIQt1Ck91O7BwD4kApyPDcPOuwp7El+ayuLdo64SN8hTqG9qe7uA4UeSOmKbkloJRZy022LaY649tQqMypwuFCFnBUep60/S48k919wfgf1FJsKZkKgpjvOFc2KqYyFNjBQnswQTng/Op/OkItwhyol0lMSVLZtq3G5HzJBygZJTzyODg+ODSWVbIlJzk7yd2PxLlJ/zEK/1I/oRSaX30bgnaQvkjOOfwNDWx5+OwysqekR/emtycDZlI5POD3xTJi6wJFsulxYdcXEtpeTIOzCvm07iUg9QRyD407oXiJNiYpoqKmlKyAPpDjH3CnAuKD1ZdH+3+tR8pbUQMLkdolqQ82w0oJBypzpkZ4HnXFusolx4qi57xIbddbARlOGygKyf4xS0YXaJQT2fHeP4aKjSkjqCPiKKeVBmZMuNBba0ZxuSU58siqPbtB+7pgAT21phGIpCNh2pW2povEf6+wRjyJV51fKTaSW28HBOST95zVSSitCx6lZnabedvDt2+UnRLE1uQ02lALSW0AI2Ebd2SguDIOMrNNzYo0K7uXx6a22ET3JbhkFQaDSkbOh4SsdQoeZHjVtC0tkKWQAD1NZHd7ZfZsC4RX7Vf1PLUoNBNzcWyrkYQtKne8g85UMYBHApU5ZlqElYudq0y9EvMWcqe85K7d9yShSB2S0O5Kko7uRgpaxkn6FSr9uTF/aOZIkttsTWgoqUCA0lDOwlR/Os/l2q9rTOlRLZfyhx9KWAu4uJkRx2fOxId2lIXgAkHgnw6PdR2W8TA8LnCus6RJtLTDRgSyhpEvaoOFxO8JwSU+BTgHgmpkSfhafh2CExc4LsGIYtpeYck7cIcUoNKS6SOqR2ZP8AFRbNHKhRZTMK5OvMTLYYK+3APeAPZrSUgZHfcznJORzVS19YL/Naah262yd3u7TSnYUpfYuENhKmy2VhKACPs8g9cjB96zs+o5OoAq3QZjcVvsNxhvOltaA2AvAD6ANpGAhIBOM560AWVi1W212o3azy7fDbFtXF96SDsLpUgBZI64UkjHXJxXi16YjqsVxast597t1xtZgJW5tVtWlKkIUCkDgBRBB54FV+62O9nSeneyt6hGiL/wCtszLrid/zu8LO0rJJwCoHcRuJHPNWX2biLFtRYQ7HRJnuO3D3WOdzccfNpLYV0JTlGfVWehBoAfzrZdZtritOvW9EqLKZkNlIWUKDZzhWeefSlfcXEXW1T5jsdDkdiS0tDQUUqLimyCCfIN8586nKTfaDzZQr7j5GhDaFKKhy680S2tbgKeMDFFPKLMTFIOblDAUU854pL39opOQsEeGK8pmsk/WT8Rn9KqqRlwTjJCM5SwlDa1JO47uBjp/fFQMT5+4OvH6KM4pW5S47MZyZM3LTlzntXE8BxSUpSlKhycAAdSTULEvtrcFlQ1EcSu7NhxCA873ElpTg34XxkJIHmQfI1l/PKFFyg07rfT8X/oteElOzuX+A32cVGequ8fv5pxTC0rUUyEFSlJQtITuUVEAtoVjJ5PKj1p8o4BOCfQVqU6iqRU1yVNZXYTY+m8P3/wCQpNjiVJT6pV+Veo6tzj3BHeBwevQV56XD0U3+h/vVhE7HOyY+keO1YqPtNjttnuEl2BG7JckE9cpQM5UlA+qCcEgdcDyFP192e2ftoKfw5r3K7qEuDq2c/d0NAC1FeG1KUCVIKPLJH8qbZVMWpIJSwk4V5qPl6CiwXEZMqMp05aLpHG4UU5chMLIJRjAxwcUVJNEbMXUhKsbkg48xXFtocGFpCviKKKgTKhcYEe4Q2GpKVlCHXHEhDimyFB5zBykg8VXrfpe3xUWNxpUvtY3Z7VGSs79rK0gKGcYwo8AAckdCQSivm2OqzjiKsVJ2v6/xZs0opwi7f65oVo6y/wDyN/8AxbqRoor6Bg/sQ/Rk1PMxJH+Id+CT+tJvcTY/qFD8hRRXUVhL4djEde0x+INOFAKSUnoRg0UUAJxiVR2yeu0UkR2c9O3gOJJUPMjxoooDgdUUUUhn/9k=: Live location: 12.9570957, 77.7017728 — https://maps.google.com/?q=12.9570957,77.7017728

[2:32 PM] **Aashu:** aaj time bahut lag reha swati

[2:32 PM] **Aashu:** rush hai kya

[2:33 PM] **You:** Bus ruka hua h

[2:37 PM] **Aashu:** jldii aao bhai

[2:37 PM] **Aashu:** so nahi paa rahe

[2:42 PM] **You:** So jao call kar denge

[2:43 PM] **Aashu:** nahi uthe tab dikkat ho jayega

[3:15 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAMEBwIFBgEI/8QAPBAAAgEDAgMEBggFBAMAAAAAAQIDAAQRBSESMUEGE1FhFCJxgZGhBxUjMkJScsEzorHh8DRigtFDkvH/xAAaAQACAwEBAAAAAAAAAAAAAAABAgADBAUG/8QAKREAAgEDAgUEAgMAAAAAAAAAAAECAxEhBDEFEhMUQQYjUWEy0SJDgf/aAAwDAQACEQMRAD8A+koSTGOI5IyD7tqxXEUpVmJEhJUHoeoz8/jXse0ko8wfl/aspF4l2C8Q3UkZwape4xVvaiz9E1SRcYRtx7tv2z767XsNd+ldnoEZiZLcmBs+X3f5StaztvYvPbRXixlWUZdfA9fkP5T41puxOp/V+r9xK2Le7wh8BJ+E+/l8K3yXVo3W6MkX06n0yy6yTnWNZJzrBHc2MwiUN3ysARx8j7BUWe0aLLQ5ZeZXqP8APjUyL+LN+oH+UU2r72EtcjWUyPEiA+soxg1jqKBokb8rg0u5iEt0FhwrgcTN/T30u4nkEDwzqePGzeO9G2boF8WZNuHZGiC82cA+ysYsi8nBzghSPnWMzBrm132PE3y/vXvLUD5xfv8A3oBNfq6n0oEDOVFFTL3uu9HeMAeHrRTqWBHHJmv+of8ASv70yo4kzOeBGbK+GOvnTMStzZUHkMmszRamJu4Y2DiTdJsKQRkcXQ+/l8KqzXLA2N9LB6ypnKHqB/2D/SrYaBWUhyzZGMluXsrmO2Wn+lWXfoeOeDZsDG+Mn5b+6tOmqcsuX5KK0Lq5tOyuqfWukRySMDcx/ZzfqHX3jB99aftV9IGndn7l7SKJ76+X78cbBVj8mbofIA+eK5DTtdl7PpfXUe6tbvlTuONVJQ/Hb31WV7cPFE8zkySsclmOSzE7k1h4hOWnmlDyeh9P8Pp69SqV3/GPj5Lh0z6WbV7vGo6VLaxPgGWKbvuHzK8KnHsyfKrIhvbe4sEvLaVZrd040dDkMPKvkzT7155THIByyCKuz6Dr2WWx1awkPFBbvHLGD07zi4h7Mpn2k1RpdVOU+nUN/F+D0KOn7nTYS3RZFkhEXeMcvJ6xNNljSVeFwCK8hiWJOFAQuc4zypldK55WxqruCSGIgHjizsT+E0+SQFVuIWDGNcMrbEis5vt7lYv/ABp6z+Z6CsbmxV8tFhT4dDTX+RLfBGT0a44pbmTDseWcYHSimtdcJ4biAGQeyipkmB7f6hPNT/UUylvtNH7x/nwplZmWoKj3MfF6vBlZPVYgbjwPuNSK8dQ6MrciMGonYDV0VJ2m0sWl3PbOPsZQQB5HYj/OmKri9sZbZvR7yNhxLxKWGBImSAw8jg+8Hwq+u2Gnm701nQ8dxBgE4xk4/fOPbiuQ7baauq9l9CurVcyRWCpEwHN02dPefnim11LuaKmvyR0uA8Q7DUOE/wAJb/X3+yqYLaK24mQY23JPSro+iK1+q0ube8jMV/eFXXJ+6FG0bDodyfInHSuK+j/Rl1CPUNYkOYtOEZjUjZpXbY/8Rv7SvhXc9nUkl12yEeSwlVj7Acn5ZrDodP8A2y/w6/qLiSb7Olst/wBFjRsHQMOtY3EohiZzvjkPE0qwcSwtIpyjyOynyLHFeMDPdgEfZxb79Wrpo8oZ2kRji9f+Ix4mPnT6KKAQoooqEIsv34j/ALv2NMpc34D4OKZVL2GCiiigQTcJxfgDK/qPtvjfHwJrg5Z4tC1CbS9YydGuZDJHMvO1kPNv0nOSOmfbVhMAykEZBGDXM9q9MW901lGJJoQAxI3I6H+o95PSrqLV+V7MqqJrKMNM7HXulwmHRNQSGykcy/ZyuoYt+LAyPDrUmz06Owlks7B++vGHDcXOMCFeqr/uPyrgdH1bU9JaC3i1O5i0tXxJAAp4VPPhJBK454BHKrbsLeG2tkS2wYyMhs54s9c9asnTdPBFU6rcm8joY1hiWNBhVGAKzoopBwoooqECiiioQi3H8MHwZT8xTKRPKpiYKeI+QyB76fVTWBvIUUUUpApNwo2buw/FhH2ySp/+/DNOoO43okauVb2p05rHUpBj1HOR556+/wDqDXVfR7qhudPfT5mJmtfuE/ijPL4cvhT+0+mrdaU/Npbdc5PMp4+7x8j41wOmX0ukapDdqDmJsSIPxJ+If51Arox96nbyYn7U7+C5aKXBKk8McsTBo5FDKw6g8qZWQ1iJmcTRhMHIOQTjwr3vJB96En9LA/8AVMdFkGHUHFYejx9Aw9jkfvRAHfjqkg/4GijuB+eT/wBzRUwTIqcAQMBsMYplLuP4R8yB86ZVHgcVc3MNrGj3Mqxq8iQqTnd3YKo28SQKSNSsmsbq9F1H6JamQTTb8K8H3t8b43G2dwR0qB2s01tZ0pLGGbu2N1byOyycDKiSqzFT0YAHHnWuGj6i/Zez0OOW0Vbe5SNpwAwe2jPGhMYx6zFVVlyM+seW1PGKaFbydDLqVjDDYzS3cSxX0iRWzk7Ss6llAPmAcUTalYQGPv7yKPvLr0JOLIzNgng5c9jXMzdlbm47P6XpOptBLaWOoO5kRuAm37qUIVG/CymRQB04QaW/Za7vdJsbLXJoJ2XVZbqeRHCl4+5kQSL4PllbA5H2U3IiczOqu7+xt7ee8kuY0t7QutxIQcIFHrA7b9K4PXdEhhvYmivLeKC7kWO04yftmK8SgEDw2354862sOiavNokdjcXdo8rakbm5uAveCSNPWT1MjJZlQkZ23pdx2X1C+7P6PprXEBOm3EwS4R8YQRSCBuHJIKsY9s/hq2E3DYrnFT3Np2EkMcFxpEtzFJdWfAzRKTxQrIMqrbY6H3VthrmlnRDrAv4Tpgzm5GSow3Aen5tq4eDSr7TYNcmmvLO31HVLeNBIZxhJi8ve4J6RrKAP0ip1t2eupOzWrabbTWd5YXb289syL3abMokThJOBiMNz3LGhLL5gxwrHZT6hZW63TT3UUa2sazTMxwqI2cHPLfhNY6fqVlqEEs1rcK0cRxLxKUMZxn1lYAjbfccq5JezF9Fa61ZRTxPETafV5kYkhIZDIscnUD8GfygHnUm50zXb/TtchlkSD6zeONEeRZGt4iSJd1Vc+qSFGSeW9KNc6iwu7fUbKC8sZVntZ1445F5MKK0Og2+saJDdWyQW15bvcPPCynuAgfDMvASceuXPPrRQJc30ihkIPKoUIM8zI7vgedFFCmSZKeCKKMkIGx+bcfCoHp0zOEUqgzj1RRRVkciywbCG3DlHkkkc88M23wqvNOF0e2V9Ld6hdXh0i0M9oswQBWkjlDZ4VGRhBt/bBRQIahe0vaFdNurj67ume20aDVlBihw0khGUb1Puc8AYO/OrNvtLuNQSK7h1nUbDigDGG07oJxYzn142PXxoooBKv0W/ubTTtGd3W6XUZdRluY7hFZZJEDsr7AYOYxsMDc7VN7K9qNWvuyfacNcJDJY6fHd28kESIY2YOxGMY4cqOmdzvRRRv4ASdOu77TrftdqAv7i4v1SxhW4nCFlVwDyChcjvGxkeHOtt2d13U37S2GnXN21zbyHUIX7xEDHuJyqNlQPW4dj0PhneiigE7qiiigMf/9k=: Live location: 13.0290212, 77.7600551 — https://maps.google.com/?q=13.0290212,77.7600551

---

## September 21, 2026

[11:10 AM] **You:** [Forwarded] [Document] 8253982938.pdf

[1:51 PM] **Aashu:** [Image]

---

## September 22, 2026

[10:43 AM] **You:**
> _Aashu: Image_
Ye to mai bolti hu

[6:24 PM] **Aashu:** Follow this link to join my WhatsApp group: https://chat.whatsapp.com/DvYyfHYMAdV2guNk1rm1ER?s=sw&p=a&mlu=4&ilr=4

[7:21 PM] **You:** Order kiye ho

[7:22 PM] **Aashu:** nahi yaar

[7:22 PM] **Aashu:** ruk jao

[7:22 PM] **Aashu:** cart me add hi kar rahe sab

[7:23 PM] **You:** Gazab ho yaar

[7:23 PM] **You:** Hum wait kar rhe yaha

[7:23 PM] **You:** 1 1 minute me bolna padega ab kya

[7:23 PM] **Aashu:** swati pagal mat bana karo samji

[7:23 PM] **You:** Rhne do

[7:23 PM] **You:** Hum kar le rahe

[7:23 PM] **Aashu:** sab kaise kar le machine hai

[7:24 PM] **Aashu:** [Image]

[7:24 PM] **Aashu:** [Image]

[7:24 PM] **Aashu:** cart me add hai

[7:24 PM] **Aashu:** kare ya nahi

[7:25 PM] **You:** Koi matlab hi nahi hai

[7:26 PM] **You:** Jab tak 10 bar nahi bolenge hoga hi n

[7:26 PM] **You:** Jate jate bole h

[7:26 PM] **Aashu:** karna hai ya nahi

[7:26 PM] **Aashu:** faltu behas kar rahi

[7:26 PM] **Aashu:** net nahi chal reha

[7:26 PM] **Aashu:** 10 baar recoonevt kar rahe

[7:26 PM] **You:** Thik h

[7:27 PM] **Aashu:** kar de prder

[7:27 PM] **Aashu:** jldi bolo yaar

[7:27 PM] **You:** Karo na to

[7:30 PM] **Aashu:** [Image]

[7:30 PM] **Aashu:** payment kat gqya

[7:30 PM] **Aashu:** order hua hi nahi

[7:30 PM] **Aashu:** akbaka di ho tm lekin sach me

[7:38 PM] **Aashu:** [Image]

[7:41 PM] **Aashu:** aaya baby

[7:41 PM] **Aashu:** dudhu

---

## September 24, 2026

[8:11 AM] __[Call]__

[8:16 AM] **Aashu:** [Forwarded] [Video] B Block

[6:12 PM] **Aashu:** [Forwarded] [Video] Street light bidirectional near park and other places material came 🥳 finally

[7:06 PM] **Aashu:** [Forwarded] https://youtu.be/GF2Wy5A-TdI

---

## September 25, 2026

[1:17 PM] **Aashu:** [Forwarded] No begging. Those who have shradha & bhakti in Maa Aadi Shakti Durga, they are requested to be puja contributors.
Not applicable to Ravan & Mahishasur.

[7:55 PM] **Aashu:** [Forwarded] [Contact: BEGIN:VCARD
VERSION:3.0
N:EAST;Bescom;;;
FN:Bescom EAST
TEL;type=Mobile;waid=918277884013:+91 82778 84013
END:VCARD]

---

## September 26, 2026

[9:14 AM] **You:** Direct marathallli ka bus mil Gaya 😊

[9:14 AM] **Aashu:** wahh mast have a nice day

[1:07 PM] **Aashu:** 9971833341

[1:07 PM] **Aashu:** hum ph nahi uthaye to ispe call kar ke key le pena

[1:07 PM] **Aashu:** lena

[1:07 PM] **Aashu:** abhsihek ka number hai ye

[1:47 PM] **You:** Ok

[3:12 PM] **Aashu:** pauchi swati

[3:13 PM] **You:** Abhi nahi 5 minutes or

[3:13 PM] **Aashu:** okk

[3:38 PM] **Aashu:** paucho

[3:38 PM] **Aashu:** mila

[3:39 PM] **You:** Le liye key

[3:43 PM] **Aashu:** ok good

[4:25 PM] **You:** Kitne pyar se bol ke gaye the kachada fek dena

[4:26 PM] **You:** Aapne kitna confidence me kaha tha ha

[4:27 PM] **Aashu:** are sorry yaar

[4:27 PM] **Aashu:** bhul gaye ekdum

[9:02 PM] **Aashu:** [Forwarded] [Video] check this out

[10:22 PM] **Aashu:** [Forwarded] [Document] Skandagiri Phase 2 Transition Guide.pdf

---

## September 27, 2026

[10:22 AM] **Aashu:** tm dono laptop ka charger lekar chali gayi kya

[10:43 AM] **Aashu:** please give me reply maa don’t ignore my message this is not good behaviour

[11:01 AM] **You:** Nahi ek hi h mere pass

[11:01 AM] **Aashu:** oh is it ok

[12:26 PM] **You:** Mila charger

[12:27 PM] **Aashu:** yes

[12:27 PM] **You:** Kaha tha

[12:27 PM] **Aashu:** mere office bah me

[12:28 PM] **You:** Bhai saab

[12:28 PM] **You:** Mujhe lag raha tha kahi mai bhul to nhi aayi yahi

[12:28 PM] **You:** Mai bhi kal ghar me dekhi thi to dusra mila nhi tha

[12:28 PM] **Aashu:** okk chill

[12:28 PM] **You:** Chupchap the hun

[12:29 PM] **You:** Ho gaya lunch

[12:29 PM] **Aashu:** nhi

[12:29 PM] **Aashu:** jaa rahe ab

[12:29 PM] **You:** Okk

[12:29 PM] **You:** Bhujiya thoda garam kar lena to sahi lagega

[12:30 PM] **Aashu:** ok thik hai

[12:30 PM] **Aashu:** chalo jaa rahe garam kr le kha hi lete

[12:34 PM] **You:** Okok

[2:27 PM] **You:** I'm leaving now from the class

[2:27 PM] **You:** [Image]

[2:27 PM] **Aashu:** itna late

[2:27 PM] **Aashu:** aao hum aa jayenge

[2:28 PM] **You:** Okk

[2:39 PM] **You:** Roti h bacha hua

[2:39 PM] **Aashu:** 4 eoti khaye hai

[2:40 PM] **Aashu:** ek do hoga bavha hua hai

[2:40 PM] **Aashu:** but bujiya to pura kha gaye

[2:40 PM] **You:** Okk

[2:40 PM] **You:** Thoda sa bas chawal bana doge

[2:40 PM] **You:** Bilkul thoda

[2:40 PM] **You:** Aadha glass se bhi km

[2:41 PM] **Aashu:** hum abhishek ke ghar hai

[2:41 PM] **Aashu:** [Image]

[2:42 PM] **Aashu:** match dekh rahe

[2:42 PM] **Aashu:** yeha

[2:42 PM] **You:** Aa nahi skte ho

[2:42 PM] **You:** Koi n

[2:42 PM] **Aashu:** aa jayenge

[2:42 PM] **Aashu:** are tm aao na

[2:42 PM] **Aashu:** ho jayega sab turant

[2:43 PM] **Aashu:** chawal kiske sath khayegi aise

[2:43 PM] **You:** Kha lenge hum

[2:43 PM] **Aashu:**
> _You: Kha lenge hum_
bus chawal

[2:43 PM] **You:** Aane ke baad banaoge fir chhod dena

[2:43 PM] **Aashu:** to kuch order kar dete

[2:43 PM] **Aashu:** eatclub se

[2:44 PM] **You:** Kya karoge

[2:44 PM] **You:** order

[2:44 PM] **Aashu:** kar dete roti paneer  ye sab

[2:44 PM] **Aashu:** apna location bej do

[2:44 PM] **You:** Ok

[2:44 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQDBQIGBwEI/8QAPBAAAgEDAwEFAwoFAwUAAAAAAQIDAAQRBRIhMQYTQVFhIjKBBxRCcYKRobHB0RUzUnLwI5LhFjRiY/H/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/8QAKxEAAgEDAwIFAwUAAAAAAAAAAAERAgMhBAUSEzEUIkFhcYHR8AYjMlGh/9oADAMBAAIRAxEAPwDunZXX7jXNLmklisreWJkia1iZy9vkYMcqOowR0yBg846VQ632qhs5NR03s9aiXU7QmSYw2sTqO7wWwu4Nkb+CwAOGAya26w0S10pL6W2a5lubkKZZ7mZpXbYDsGT4DJ++k9Y7OaddNc3Ra+iF1g3MVtdvFHPwBllBxkjAOMZFMQhpHa+0v9ZsdPeGWW+nt4pbh7dFaIM0He467iu08HGOQK0+07Y67OkjiEXNisyxNHLpqiPaFQ7ZGViI2ySOchdvtY6V03TtMtbW6N7Y2UVvNJBHASrkK0aD2AVHHA4B644qnT5P9CWDudt/3ONhi+eybO73bu6xnGzPOKAyY3vajT7bWdY025tJJo7GESeyVYTbVDOoDAINispOW6GldC7fQ692k0/TINMlt7G5g76N7tV3ybQxBVVYgKNnDdMjHBxm3vOxuj3WsXGqFLuG8nIZ3t7p4suAAH9kjngenpVhpGmw6VZR6fpxkitrcHbubexLMWYknk5JzQCUFlVVqExlk7ocIh9r1PhTV1LLbwli6Nk7R7ODk/GqoAqoAyzE4HmxNSpXqKp+hLbwi4uAjfyx7TevpVu0MbHO3Dea8H8KitrRIoAkgV2J3MSOprG5UwoDC7qxYKBnI5PkaTcsaUIJbTf4q/8AeOfvFR7J4vcaQDy98fvTP+sv9Dj/AGn9a8WcnIMUmQcHGD+tEhCF/nkg4KwsfPvNv4HmimTMvjHJ/sNFH0D6mUDb4EJ8VGagI3aeynqqkfEf/KIriKNWVnHDHGOeM58KiS8Re8VEZ8sSAPX/AA0QEoltJx83QbXYjjhT+dTb5D7sOP7mA/LNKadKscTpIwUhvpcf50prvwfcR3+pcfiaH3BdjOPfz3m3021pXaj5QNO7P3lxaxxPfXwb2o42CqnA4ZvA+gBPnitm169msOz+p3saAS21tLMgJzkqhIz91fL17cPHE8zkySMclmOSzE8kmsOr1FVqKaO7PQbJtdvWuq5eflp9P7OsR/KnDeXUQ1DTJLWBfpRS97gnxI2qcY8smug6HJDfMt3byLLBsDRupyDnx+786+XLC8eaUpIB0yCK7Z8hd5K9nq1ixzDA8cqehfcCPq9jPxNV6XV11VdO4at42bT2rHidNiO6Oo0tc+1cW6f+RY/AUwxIUkdcUrD3klyXcbdqbRwRyT610UeWY0SAQCRk9Kjh96X+/wDQViY5S6t3iZUEDKefxrOJGQNuIJY54FAEVzP3Thc44zRUskMcjZdQT0oowDTII7eJJ3XYCNoI3c+eetSqAlyQAAGQHj0P/Iok9m4ibzBX9f0ol4lhb1K/eP8AgUAK71gv5S/CkZBxny/5qRr+LOFDsfQVjeKovIGcAqeCCOP85pjvoU4Vk+pefypiEr4PqFlcWklsxhnjaJwTjKsMHy8DXzj2g0W50bUZ9N1KM94nQnpIng49D+ByPCvpvvs+7FI3wx+daV8puifxzTMpEBf2wLwEHJbgkp9RA+/FY9Xp+tTNPdHb2TcvBXuNf8KsP29/ucGht4rfcyDHmSa7z8lXZ+50PQ5Li7g23d8yyMjHDIgHsKR58k/ax4VoHyWaJFqerpqN2u6ztJF2KRw8mN3PoowfiPKu9Vn0Nhr92r6HS/UW4qp+Dtdl3+wsLpsnMEhAOMrzUkMyykhQwI6hlIqRVCjCjA617XTPJ5CsFfc7rj3Tj8M1nUNvyJG/qc/hx+lIZBeXvzeUIE3cZoqG/wBpuDuYLgDrRViSgrbcjtzxGG/pYN+PP4UXXEJb+khvuOaWaW5ljKC36jByf3xXpW8kQq3dqCMH/OajBKT3VB/pI+M7WpxcBfZwB6UkbWeRQss42+QGf2r0WCEDfI7YowGZGGniX3pEz5Z5qqu5BLdblyVGT09AB+tWS2cC/Qz9ZNVLrtuJRgDbgED7/wBadMCqmCHs9pVlp0ht7G3SGA75WRc8sxAJ5q/7hfBpB9s/vVXZTLDNK7KzAqF9nw6k/mKru0vaaWyvtPsdMWFp5bm3S5abkRRyyBAAAeXOSfQKSeopccwh83V5qnLNl7nHSSQfaz+dS1p3/WF387hjOkSIralNZlFxJJIkcTsdgD8NuUA54wfHwc17tZBYdk4td0+E30cwiaKLOxmVz+YAPHmMUcWHJGy1Fa/9uhPiN3381SXnaazXtDbaRCveCe0e6e63hY4UCkruz5gZ8MDBp211rTZ7aCSxu4LyN50tswTJ7LEZ5yR4c4GSR0BpQxyhpQjSSlyB7WOvoKKUg1PSXUv/ABHTn3MWDC4Q5B5Hj5YooEPNMFlKFWOACNoJ86971vCGQ/cPzNYysI7hGIJDKV4GfUfrWXfeUch+zj86BhvlPSHH1sKMzn6MY+0T+leGVwM9y/xI/eo7i7W2AN09tbZ6d/OEzSbVKljpTqcLJm3eqpZpI1AGT7B/eqdSWy7e853H409eTPLZFozFJC52l4X3jHjzSDgsu1feYhR8eKnRlSiuvDgtNLTbZqx6yEv9/T8MUj2h0bSb/up9Q0+3mmSZJBIY13MV5AJIORxjHlVuu1FCggADAGaV1I57lcE5boPu/Wknkk1grrXRLG11GO7jmvVKXU92sbKCgeZcPj2c4ySRk9T5YAjTQrBdG0bTfnbiHTZIX3OBmYRg4VvQk1e995xyD7OaO/TxEg+tD+1EsIRpll2Jjs7aNLLWCLhLa5gFwVywMixpGRz0SONV9evBrG37HX6Sd4bmzZmvI7k5lmbhLeSMDc+5j7bA8npmtyMtu3vFPtCvMWh5Hc/DFPkxcUco7S/Jzq13FoqaTDpDJa6bDbTNI23dKu7cRgcg5zn66K63ajFtF/aPyoqXVqWBdNMguTMkazZQ7DkKB58dfjUa3TsoJnt1yM4wcj8anAL2JX6QUr8Rx+lZ7l2IwiLBhngCoEin1jVn03Srq8WVJnQiKIBeBIecnzwOa0b+EXGoWZ1Ke6kd5I2mYshPQTHGc/8ApA+2PLna+1Vs99pN/bxRsJoZFvFTjLrt2tjHlWoWur3UPZi7skutqGaNVj4zsYSF8eOMhc/X615fd609TxvTx4yvn8wep2ehrTc7Mc+UP4/35G5kvexmr2wWcSNJCsk0QHsEEkFT59OtbvGsDXigMvzZoxOm44yrDgf55Vz7WLm51y40tmcXN7JB3bbQAd3eyYBA6cY+HNdB0+ONLhkCd8lrDHZhwuQSgOfxJHwrTstfnuU256eI9p/Mmbe6PJbquR1Mz7x+YJ7gWgixD3e/IxtOT1FZ6g4W4gJBIXnA+sftTHexojsI2G1S2NhGcDzxWq6N2sh1a1uNQ+aqptbAX+2G5WYbSrEI5AGx+OhFd+Tz5sv8Qj8UkH1gfvQNQgP9VUMna8RdlbrWmtLedYTCFhtL1ZmYyOq4J2gKRuHBp09pbOTtBFpdvGZ1ksTfCdXG3bxhceJIIPoCPOkGSzF9AfpH/aa8kuoGRvaycHHsmsNIuYtU0ew1BYBGt3bx3ARsMV3qGxnxxmlYrqG9GqRxWwjeyuxa54O87I3yOOP5mPhQoByPxXMKxoN/QAdDRWkax27sdI1GaybRL27EJ2C4hQFZCvst4eDhl+zRTgJZvUHBlHgHP6Gi1/kKPLI/GiikMQ7QZgszewsUuLcF0YfkfMGobnsfpOqJHdPHJbSyqHf5uwUEkZ6EECiisWut0V2nyScG3QXK6Ly4NqRTV9Ktey2jvcaUhW6kdYu/kO51DddvgD8Kk02MWtjDFCWChQevJPmaKKnZopt2aVQo+Dn7ncrruN1NtyWFuzSmRHdirIwPPpWn9kdMjm0LUmlllPcab/DowAq4i2nk4UZbgcn96KKvo7FWnbdGSXR9+o9l7i1uZCY4Liz2bFVT7MyEZwOfdFN6PoFpp+pQNbtLkLfINzA4XdEgXp0VY0UegooqZeQdi726TSGsmmZ4bKGGGHIAIUeyMkAZ4AqSzuJ7Ptpe20MpNvdXHziRGVSN/cqODjI9xfGiin6B6jmh9kdIfR7N5o7mWV4lkdzdSgszDcxwrADLMTwB1oooqIz/2Q==: Live location: 12.9611468, 77.71664 — https://maps.google.com/?q=12.9611468,77.71664

[2:45 PM] **You:** Bhukh lag gya tez

---

## September 28, 2026

[4:20 PM] **You:** cscript "%ProgramFiles%\Microsoft Office\Office15\ospp.vbs" /dstatus

[4:21 PM] **Aashu:** bhai ye sab kya bej rahi

[4:21 PM] **Aashu:** ph hack karegi kya mera

[4:22 PM] **You:** hmmm soch rhe h

[4:22 PM] **You:** cscript "%ProgramFiles(x86)%\Microsoft Office\Office15\ospp.vbs" /dstatus

[4:22 PM] **Aashu:** apple hai orange nahi ki hack ho jayega

---

## September 29, 2026

[9:01 AM] **You:** [Video]

[12:25 PM] **Aashu:** [Forwarded] Respected Sir/Madam,

In reference to your post, regarding No power supply, we have informed to the concerned sub division and issue will be resolved at the earliest. Inconvenience regretted.

With Regards, 
BESCOM Helpline
(1912)

[12:38 PM] **Aashu:** [Forwarded] [Video] Have a look at the number of stray dogs roaming inside the premises.

[4:23 PM] **Aashu:** [Image]

---

## October 1, 2026

[12:32 PM] **You:** Aa gaya

[12:32 PM] **Aashu:** ok

[12:33 PM] **You:** 631750

[12:33 PM] **Aashu:** nhi ruko

[12:34 PM] **Aashu:** ye pehle ka aaya hoga

[12:34 PM] **You:** Ok

[12:37 PM] **Aashu:** aaya ab kya

[12:37 PM] **You:** 485981

[12:37 PM] **Aashu:** cool

[12:37 PM] **Aashu:** come now

[12:37 PM] **Aashu:** thanks

[12:41 PM] **You:** Bhejo

[12:42 PM] **Aashu:** ek min

[12:43 PM] **You:** 506675

[12:43 PM] **Aashu:** ho gaya login

[12:44 PM] **You:** Aa jaye

[12:44 PM] **Aashu:** aa hai

[12:44 PM] **Aashu:** jao

[12:44 PM] **Aashu:** yes

[2:38 PM] **You:** _You deleted this message_

[3:03 PM] **Aashu:** aawaz km kar diye the swati

[3:04 PM] **Aashu:** us time dekh liye the tumhara msg

[3:21 PM] **You:** Hmm ok

---

## October 2, 2026

[8:35 AM] **Aashu:** [Forwarded] Doing Karma is in our hand so doing my karma and organizing Durga Puja in our Skandagiri society. Fruits of action is not in our hands
Our Intentions determine/decide our future, heaven, moksha or next birth so we should work with good Intentions

This is my personal view as per my best of the knowledge.

[9:08 AM] **Aashu:** [Forwarded] [Video]

[5:37 PM] **You:** Kahan gaye ho

[5:38 PM] __[Call]__

[5:39 PM] **Aashu:** abhishek ke ghar hai

[5:40 PM] **You:** Ok

---

## October 6, 2026

[4:01 PM] **Aashu:** [Image]

---

## October 7, 2026

[1:35 PM] **You:** Kya chal raha hai

[1:37 PM] **Aashu:** ho gaya

[1:38 PM] **You:** Kya raha

[1:52 PM] **Aashu:** wo formality tha bus

[1:52 PM] **Aashu:** aa kar batate hai

[1:57 PM] **You:** Ok

---

## October 8, 2026

[11:20 AM] **Aashu:** [Image]

[11:23 AM] **You:** [Document] EPFO.pdf

[1:07 PM] **You:** Take a look at this Xtenso Care Sulfate-Free Shampoo & Masque with Free Absolut Repair Mini Shampoo on Flipkart
https://dl.flipkart.com/s/fER!ePuuuN

[1:47 PM] **You:** Ab to nhi aa raha na nind

[1:49 PM] __[Call]__

[9:47 PM] **Aashu:** [Forwarded] https://youtu.be/nsLudTutdo0?si=FRAaJSCc7Ww2HF65

---

## October 11, 2026

[12:57 PM] **Aashu:** hello

[12:58 PM] **Aashu:** mami rakhi amit uncle aaye hai

[12:58 PM] **Aashu:** ye log kahi 1000 sibling dekhne gaye the to acchanak se call kar ke aa gaye kyuki ye log isi taraf se wapas jaa rahe the

[1:41 PM] **You:** Ohh no

[1:41 PM] **You:** Fir

[1:41 PM] **You:** Abhi hain na

[1:44 PM] **Aashu:** chale gaye

[1:44 PM] **Aashu:** tm aaram se aao

[1:46 PM] **You:** Chale bhi gaye

[1:46 PM] **Aashu:** hh

---

## October 12, 2026

[4:39 PM] **You:** _You deleted this message_

[4:40 PM] **You:** https://www.myntra.com/mailers/jeans/glitchez/glitchez-women-mid-rise-light-fade-pure-cotton-wide-leg-jeans/31362836/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=wAEoegHQFI7HbhUg&shared=true

[4:40 PM] **You:** https://www.myntra.com/mailers/flats/inc-5/inc-5-women-printed-round-toe-mules/32212353/buy?utm_source=social_share&utm_medium=social_share_pdp&utm_campaign=wAEoegHQFI7HbhUg&shared=true

---

## October 13, 2026

[8:58 AM] **You:** Blootooth off kr lo

[8:58 AM] **Aashu:** off hai mera

---

## October 15, 2026

[2:47 PM] **You:** [Forwarded] Dear Kumari, Thanks for Contacting PIGEON Service Support Team. Product Category: INDUCTION COOKTOP , Area Pin 560049. Kindly note, this Product category for the mentioned Area Pin, cannot be home-serviced. Please visit our nearest Authorised service centre, mentioned below to avail best service. 🏢 Service Partner :SRIDHAR V-DSC-BNG 📍 Location :S/o Venkatesh Naidu No 867, 6th Main, 6th Cross, Prakash Nagar, Near Govt Schol 560021   560021 Bengaluru KARNATAKA 🌆 Contact Number :9972910873 Operating Hours: Mon-Sat: 9AM - 6PM Sunday: Closed For any assistance or queries, please contact us at 6364914202. Our team is here to help. Thank you for your understanding and cooperation. Best Regards, Stovekraft Service Support Team

[2:48 PM] **Aashu:**
> _You: Dear Kumari, Thanks for Contacting PIGEON Service Support Team. Product Category: INDUCTION COOKTOP , Area Pin 560049. Kindly note, this Product category for the mentioned Area Pin, cannot be home-serviced. Please visit our nearest Authorised service centre, mentioned below to avail best service. 🏢 Service Partner :SRIDHAR V-DSC-BNG 📍 Location :S/o Venkatesh Naidu No 867, 6th Main, 6th Cross, Prakash Nagar, Near Govt Schol 560021   560021 Bengaluru KARNATAKA 🌆 Contact Number :9972910873 Operating Hours: Mon-Sat: 9AM - 6PM Sunday: Closed For any assistance or queries, please contact us at 6364914202. Our team is here to help. Thank you for your understanding and cooperation. Best Regards, Stovekraft Service Support Team_
let the game begin

---

## October 16, 2026

[6:15 AM] **Aashu:** [Forwarded] [Image]

[8:10 PM] **Aashu:** [Forwarded] [Video] Jai Ma Durga arrived to our Society 🙏

[11:14 PM] **Aashu:** hello

[11:14 PM] **Aashu:** hum nitini abhiahek ghumne nikal gaye hai

[11:14 PM] **You:** Kya

[11:15 PM] **Aashu:** gate khol kar so jana tm ok

[11:15 PM] **You:** Gate khol k kyu

[11:15 PM] **You:** Khol k nahi so rHe hun

[11:15 PM] **You:** Hun

[11:15 PM] **Aashu:** mere pass key nahi hai

[11:15 PM] **You:** To call karna

[11:15 PM] **Aashu:** ghanta call nahi lagta

[11:15 PM] **Aashu:** tumhara

[11:16 PM] **You:** Lag jayega

[11:16 PM] **Aashu:** ok

[11:16 PM] **You:** Khol ke hum nhi soyenge

[11:16 PM] **You:** Kab tak aaoge

[11:16 PM] **You:** Kahan ja rahe ho

[11:16 PM] **Aashu:** nahi lagega to abhishek ke ghar so jayenge

[11:17 PM] **You:** Or bhi kuch puche hum

[11:18 PM] **Aashu:**
> _You: Or bhi kuch puche hum_
lagega time

[11:18 PM] **You:** Kahan ja rahe ho

[11:22 PM] **Aashu:** idhar udhar

[11:22 PM] **Aashu:** [Video]

---

## October 17, 2026

[1:05 AM] **Aashu:** jagi ho ya so gayi

[2:20 AM] __[Call]__

[1:23 PM] **You:** Ghar aa gaye ho ya nahi

[1:24 PM] **Aashu:** nhi yaar

[1:24 PM] **Aashu:** 2:30 tak

[1:24 PM] **Aashu:** 1:45 min lag reha

[1:24 PM] **Aashu:** bahut traffic hai

[1:25 PM] **You:** Mera to ho gaya class

[1:27 PM] **Aashu:** kaha ho tm

[1:27 PM] **You:** Nikal gaye

[1:28 PM] **Aashu:** myntra ka delivery aaya tumhara

[1:29 PM] **You:** Haa

[1:29 PM] **Aashu:** kaise legi

[1:32 PM] **You:** Security guard ke pass bolenge dene

[1:57 PM] **Aashu:** kaha pauchi

[1:57 PM] **Aashu:** mera ph off hone wala hai

[1:58 PM] **You:** Idhar bhi bahut traffic h

[1:58 PM] **Aashu:** humko 29 min dikha reha aise aur

[1:58 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAIDBAUGAQcI/8QAPRAAAgEDAwEGBAIIAwkAAAAAAQIDAAQRBRIhBhMiMUFRYRRxgbGRoQcjMkJSYsHRcoLhFRYXU2OS0vDx/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAEFAgMEBgf/xAAvEQACAAQFAgMHBQAAAAAAAAAAAQIDBBEFITFBURJhBhORFDJScYHB8SKx0eHw/9oADAMBAAIRAxEAPwD3jpy5G57STBVxlQfXzFXsBC5h7xMYAy3JIx4/f8KxKO0bh0JVgcgjyrSaTez3aZcLmNlDP4bweMf1+nvXZUys+tFVQVKaUqLXYuKKRK/ZpkDJPAHqaQImbmSRs+inAFcZbD1FMiN0YGNyV81ck/gaeoAooooAoqPBErxI8m5mYBjlifyqRQBXAQQCDkHzpq5k2IVGdzKcf+/UUuLb2YCnIHH4cUAuio4VpmciRlUNtAB9P9c0VJFyuh0GJGYvJ2n8IK4x+fNT0tooIVDHCId3ACjPvipVMRgSuZG5AbCDyGPP71lFHFF7zNUEiXL9xWOFtx7VwVjQEgHxJ9abt4WlhR5JZdzd4gNgU/dDNtKP5D9qVCcwofVRWNzbbMYeBkUsk8oIGeTuH51nOp+uNP6chhjuA91fyIHEEWMgHwLHwUH8fatTcHbBIc4wp+1fK+oX8t3JcX9wS8sxMrZPr4D5AYHyFclXUOVCunVl1gmGwV0yJzH+mHX6/g9Ytf0vRtOovNFkjh82huRIw/ylV+9eiadqlpq2lC+06dZrd1JDDjBHiCPEEehr5PtL+SS4CSBcN4Y8q9V/Q1fTJqmp6eGPw81qZyvo6sq5HzD/AJCuamqpjmKCZnctMVwamgpoqimy6dV+T2mMYjUegFKooqzPJEK6b9cSfBQPyyx+wp5GEMG08sibmqMR2kx89zf1/spp099j/wBSTH0Xx+x/GsjES1yLVUjZSW25OPU+NFOwhXDSPg72JGfTwH2opkMyo0Pqa21TpWTW5YjapCjNPFv3lMDcBnAzlSpHHnS9J6gtJunrC/vtmnG4DKIJJNzAqxBA4BOMZPHFZ/S+n76CDRbSRUjspYIBqiGRTtkhGVHB53d1TjPCVJhs9StLHSofh7lkiFz2ospIhMrPJuTvMeEIznB8dufCrKZIp22oGs3zorPL1W+1uThgmzrJxLbjfL7ffg0V3rOlQCBLjULdfikDQ4bPaqeAVx41G0TULfVtN+JsLifs1keDaygHKsVHl54z9arOltNvNLfS5r237MQac1s57RGIczA44PPAzn/5U7p3trG3trS7geJvj7kgllKurvJIrLgnjvKOcHNaJ0qVBC1A7tPld9vQ3S5kyOJOJWXy+X9me6n6wvLa/n0npuIXl9ArNcTuobZt8Qi+ePPxrw8jDNG4GDkjjgitL09fS6d1lZ3VySJI7sdsfPlsP+RNbb9I2taLqGgXdraWFq0ySgQ3ELLujIP7RAGQCARj3xVljGCKOTDTyJd4tVF33T7Pbg5PDPiaKkqo6momWlvJw9tmrbrO/J4/DaQwuXRefc+Fev8A6JNCltLK41i6idHu1WK2BUjMe4Et8mIGPZc+dYTonRjrmo7pVHwlqUedWGQxL4Ef1wx+SmvdWmnZQpkAVcYVUAAx4V46hponF5kex9D8Q4pAoPZJG9m2uNV/JcIzk4ePb7g5rsrbI2c/ugmqcz3B8bmT8FH9KSzytw80jA+RNWvSeO6ybBhHLHwjUk/QY/8AKlYKrtH7SoEH+JjzVdt/mc/NjzXDGmO8oPlzzU2MeodvSZJyI5GVEAQY88UU1uRABlVHp4UVkiGVV5q1zYz6glxdW9xcWpd+xWywsqKiOQGB7rEOFGSe9jxzipA1O/uJtQhgWHeLiVLMTlR2hjJVo1Bx/CWzn5+NaCDT7Rba3jksrT9Sd6KIVxG3qoxwfcUS2VnNdTdtZWkhlUGQvCpL88ZOOfDzro9olfDn9P2y/wBkavJmfEZiC51mGyTUJXiuY70QiHbnG18HCxFgoIHmcH3PhVvd2l3LZouxvi1YSK6oidmeCAcMQSCPWrqSKOSLspIo3i4GxlBXjw48OKChw21sFjuJxmtU2epiySRslyXBq7nmOt9Jz63fnVdDZLLWY2Etxau+3vg8SRn0JGfnVVZ9CdW3El5Heutnb3bB7qSWdWEmCW3EKTk5JPNem3NoZVjuIJDBdQw7klA9fIjzHHhSzbalfBY9UuIPhhgtHAhXtP8AESTx7V3ysaqZUtS8nbRtXa49Ctm4JTTpnmZq+qTsnz69jPdNdOWdsu3RUEdkrbpLiQFnupQMb8Z4UZOAPU1pRprfvXB/yoB981Ls1CWyBRhfEfU5p+qlxNtt7luoVZLjL0KtbFTE7tNLlSw4x5Ej09qcgsIXhR3MhLKCe+R9qlTgJbS44G1j9zSrfiCMfyj7Uux0oixWNuTIGj3bWwMsT5D3p4WVsDkW8WfdBTyqFLEZ7xya6xwpPoM1FyUkQdNijaBiyIe9xx4cCijT3CW+CrnnyUmipd7kK1ifXMDcTjkjGa7XCQMZIGTgViZHaKKKAi3bNskjQLjZzn34pwiYgjdGM+x/vSZUYmQ4PJRR8s/61IqSBMa7I1UfugCkxOzFldQGXxwcilO6oMuyqPUnFUWs66dO1GK3tbWO5aW2lumZ7kRKqxlVIBIOT3x6eFAXN2cWs3+A/anIxiNR7CqDWOpbO10bS70wzyQalsYDhWhhZQzSP7KCM/OpGvapeaXeWEFvp0V0l3MLeN2uuzIk2O/I2HjCHnNAXNN3Bxbyn0U/aqUdQ7up5tHWG1VoWjVmlvQjtvUN3E25bGfWpVrqS6jp13KkZjEVzPakFs57OQx5+uM0QuTLAYtU+v3NFKtBi2i91Boo9QtB6mX71zGP4QW/p/U13tH/AOS/0K/3ptWkEzuYZMEADlff396AfVgxYDPdODTV7dQWNnPd3koitoEMkjkEhVHieK5GzqXJhk7zZHh6D3qD1XYT6r0vqtjahfiLm1eKMOcDcRgZNBcsIbq3nmWKCeOR2iWcBTkGNiQrA+GDg1GXWNNbTbrUEvImsrUyLNMuSEKHDA8Z4qjtdC1PR7vXG0t4Xge0EWmKz4MLbpG2H+VWfI/lwPKq9OlNRs+ntf0i2nt7m3vbFY4W7Mw4mVOzOQSf2lVDu8yDQXNfp+p2WoRzPa3CkQHEodWjaPjPeVgCBjnOKp7pND1W40zW55ba6tniNtbdtFvidpXUqeRwcpt5x+1jzqJc6DqHwfUFlFdCaXU5YYhfTyAydgVCupUYGVG/GMZ3fM07a6FcxaJrOkXk1vLBPI72xjXstpkG7AXJ2FZcsOfOhFxXUNloeqQ3eqazeFrKyhkspQrvHHEd363lcFs91ccjK49al3MNon+7drqGoHt4J1a1kbGbt1gdTnyGQ5PuagzdP3sugaJo8L28KW7pNeNIvah3Vd3K5G7dKdxOf3aiy9J3l7pegWGoyqw05p4xcxvhwoUrBKvidwwh9iPOgJ03wFjrE2tDVwkV3OImgFt2jO8OY3VcDdxsOSB701aNp2lpeztrkEmnyCXUgrxDCJNIzBxIOSNxP5UzHoWqjQbCO7hhm1OG5uriV7W6aCSNpZXYNG/hghuVYYwfbnuodK3upL0/HqDW8iRwNb6psG0SAFJF2jAz34x5DhjxQGkgkgZ54IrqRpLZxFKqqTsbarY8PRlP1oqL0Npd3o+h9lq0iSajLK8s7ochj+yp/wCxVopckt6KKKgkKKKKAKKKKAgX7bJDgDvxPn2wD/eqbp6d7f8AR5Y3yENcQaNFIjNzysAYfnRRWRiVGjxH/h5rlq00zf7Od3t5WcmRWWJJ1bd6h2P04prSZn1fp3Qbm9ZmbXNYc3qqxUOqpNtTxzsAhjGM84Oc5NFFQCVDut9SsrKN3+GtepWhhQsTsjNk8mz5BnOB5DHpUPW7eG66Q6ke4iWSSDULtonbkxntVHB8uKKKA3KiOwUWtnDFFbxcIijAAzmiiigP/9k=: Live location: 12.9559776, 77.7289793 — https://maps.google.com/?q=12.9559776,77.7289793

[1:58 PM] **Aashu:** tmko

[1:58 PM] **Aashu:** nahi skandgiri dekh kar batao

[1:58 PM] **Aashu:** tmko kitna lagwga

[1:59 PM] **You:** 44 min

[1:59 PM] **Aashu:** ohh ok

[1:59 PM] **You:** Aaj itna traffic kyu h

[2:09 PM] **Aashu:** no idea

[2:09 PM] **Aashu:** mera ph off hone wala hai

[2:09 PM] **Aashu:** hum ghar pauxh kar chaege lagate

[2:10 PM] **You:** Ok

[2:41 PM] **Aashu:** kaha ho

[2:50 PM] **You:**
> _You: /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAIDBAUGAQcI/8QAPRAAAgEDAwEGBAIIAwkAAAAAAQIDAAQRBRIhBhMiMUFRYRRxgbGRoQcjMkJSYsHRcoLhFRYXU2OS0vDx/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAEFAgMEBgf/xAAvEQACAAQFAgMHBQAAAAAAAAAAAQIDBBEFITFBURJhBhORFDJScYHB8SKx0eHw/9oADAMBAAIRAxEAPwD3jpy5G57STBVxlQfXzFXsBC5h7xMYAy3JIx4/f8KxKO0bh0JVgcgjyrSaTez3aZcLmNlDP4bweMf1+nvXZUys+tFVQVKaUqLXYuKKRK/ZpkDJPAHqaQImbmSRs+inAFcZbD1FMiN0YGNyV81ck/gaeoAooooAoqPBErxI8m5mYBjlifyqRQBXAQQCDkHzpq5k2IVGdzKcf+/UUuLb2YCnIHH4cUAuio4VpmciRlUNtAB9P9c0VJFyuh0GJGYvJ2n8IK4x+fNT0tooIVDHCId3ACjPvipVMRgSuZG5AbCDyGPP71lFHFF7zNUEiXL9xWOFtx7VwVjQEgHxJ9abt4WlhR5JZdzd4gNgU/dDNtKP5D9qVCcwofVRWNzbbMYeBkUsk8oIGeTuH51nOp+uNP6chhjuA91fyIHEEWMgHwLHwUH8fatTcHbBIc4wp+1fK+oX8t3JcX9wS8sxMrZPr4D5AYHyFclXUOVCunVl1gmGwV0yJzH+mHX6/g9Ytf0vRtOovNFkjh82huRIw/ylV+9eiadqlpq2lC+06dZrd1JDDjBHiCPEEehr5PtL+SS4CSBcN4Y8q9V/Q1fTJqmp6eGPw81qZyvo6sq5HzD/AJCuamqpjmKCZnctMVwamgpoqimy6dV+T2mMYjUegFKooqzPJEK6b9cSfBQPyyx+wp5GEMG08sibmqMR2kx89zf1/spp099j/wBSTH0Xx+x/GsjES1yLVUjZSW25OPU+NFOwhXDSPg72JGfTwH2opkMyo0Pqa21TpWTW5YjapCjNPFv3lMDcBnAzlSpHHnS9J6gtJunrC/vtmnG4DKIJJNzAqxBA4BOMZPHFZ/S+n76CDRbSRUjspYIBqiGRTtkhGVHB53d1TjPCVJhs9StLHSofh7lkiFz2ospIhMrPJuTvMeEIznB8dufCrKZIp22oGs3zorPL1W+1uThgmzrJxLbjfL7ffg0V3rOlQCBLjULdfikDQ4bPaqeAVx41G0TULfVtN+JsLifs1keDaygHKsVHl54z9arOltNvNLfS5r237MQac1s57RGIczA44PPAzn/5U7p3trG3trS7geJvj7kgllKurvJIrLgnjvKOcHNaJ0qVBC1A7tPld9vQ3S5kyOJOJWXy+X9me6n6wvLa/n0npuIXl9ArNcTuobZt8Qi+ePPxrw8jDNG4GDkjjgitL09fS6d1lZ3VySJI7sdsfPlsP+RNbb9I2taLqGgXdraWFq0ySgQ3ELLujIP7RAGQCARj3xVljGCKOTDTyJd4tVF33T7Pbg5PDPiaKkqo6momWlvJw9tmrbrO/J4/DaQwuXRefc+Fev8A6JNCltLK41i6idHu1WK2BUjMe4Et8mIGPZc+dYTonRjrmo7pVHwlqUedWGQxL4Ef1wx+SmvdWmnZQpkAVcYVUAAx4V46hponF5kex9D8Q4pAoPZJG9m2uNV/JcIzk4ePb7g5rsrbI2c/ugmqcz3B8bmT8FH9KSzytw80jA+RNWvSeO6ybBhHLHwjUk/QY/8AKlYKrtH7SoEH+JjzVdt/mc/NjzXDGmO8oPlzzU2MeodvSZJyI5GVEAQY88UU1uRABlVHp4UVkiGVV5q1zYz6glxdW9xcWpd+xWywsqKiOQGB7rEOFGSe9jxzipA1O/uJtQhgWHeLiVLMTlR2hjJVo1Bx/CWzn5+NaCDT7Rba3jksrT9Sd6KIVxG3qoxwfcUS2VnNdTdtZWkhlUGQvCpL88ZOOfDzro9olfDn9P2y/wBkavJmfEZiC51mGyTUJXiuY70QiHbnG18HCxFgoIHmcH3PhVvd2l3LZouxvi1YSK6oidmeCAcMQSCPWrqSKOSLspIo3i4GxlBXjw48OKChw21sFjuJxmtU2epiySRslyXBq7nmOt9Jz63fnVdDZLLWY2Etxau+3vg8SRn0JGfnVVZ9CdW3El5Heutnb3bB7qSWdWEmCW3EKTk5JPNem3NoZVjuIJDBdQw7klA9fIjzHHhSzbalfBY9UuIPhhgtHAhXtP8AESTx7V3ysaqZUtS8nbRtXa49Ctm4JTTpnmZq+qTsnz69jPdNdOWdsu3RUEdkrbpLiQFnupQMb8Z4UZOAPU1pRprfvXB/yoB981Ls1CWyBRhfEfU5p+qlxNtt7luoVZLjL0KtbFTE7tNLlSw4x5Ej09qcgsIXhR3MhLKCe+R9qlTgJbS44G1j9zSrfiCMfyj7Uux0oixWNuTIGj3bWwMsT5D3p4WVsDkW8WfdBTyqFLEZ7xya6xwpPoM1FyUkQdNijaBiyIe9xx4cCijT3CW+CrnnyUmipd7kK1ifXMDcTjkjGa7XCQMZIGTgViZHaKKKAi3bNskjQLjZzn34pwiYgjdGM+x/vSZUYmQ4PJRR8s/61IqSBMa7I1UfugCkxOzFldQGXxwcilO6oMuyqPUnFUWs66dO1GK3tbWO5aW2lumZ7kRKqxlVIBIOT3x6eFAXN2cWs3+A/anIxiNR7CqDWOpbO10bS70wzyQalsYDhWhhZQzSP7KCM/OpGvapeaXeWEFvp0V0l3MLeN2uuzIk2O/I2HjCHnNAXNN3Bxbyn0U/aqUdQ7up5tHWG1VoWjVmlvQjtvUN3E25bGfWpVrqS6jp13KkZjEVzPakFs57OQx5+uM0QuTLAYtU+v3NFKtBi2i91Boo9QtB6mX71zGP4QW/p/U13tH/AOS/0K/3ptWkEzuYZMEADlff396AfVgxYDPdODTV7dQWNnPd3koitoEMkjkEhVHieK5GzqXJhk7zZHh6D3qD1XYT6r0vqtjahfiLm1eKMOcDcRgZNBcsIbq3nmWKCeOR2iWcBTkGNiQrA+GDg1GXWNNbTbrUEvImsrUyLNMuSEKHDA8Z4qjtdC1PR7vXG0t4Xge0EWmKz4MLbpG2H+VWfI/lwPKq9OlNRs+ntf0i2nt7m3vbFY4W7Mw4mVOzOQSf2lVDu8yDQXNfp+p2WoRzPa3CkQHEodWjaPjPeVgCBjnOKp7pND1W40zW55ba6tniNtbdtFvidpXUqeRwcpt5x+1jzqJc6DqHwfUFlFdCaXU5YYhfTyAydgVCupUYGVG/GMZ3fM07a6FcxaJrOkXk1vLBPI72xjXstpkG7AXJ2FZcsOfOhFxXUNloeqQ3eqazeFrKyhkspQrvHHEd363lcFs91ccjK49al3MNon+7drqGoHt4J1a1kbGbt1gdTnyGQ5PuagzdP3sugaJo8L28KW7pNeNIvah3Vd3K5G7dKdxOf3aiy9J3l7pegWGoyqw05p4xcxvhwoUrBKvidwwh9iPOgJ03wFjrE2tDVwkV3OImgFt2jO8OY3VcDdxsOSB701aNp2lpeztrkEmnyCXUgrxDCJNIzBxIOSNxP5UzHoWqjQbCO7hhm1OG5uriV7W6aCSNpZXYNG/hghuVYYwfbnuodK3upL0/HqDW8iRwNb6psG0SAFJF2jAz34x5DhjxQGkgkgZ54IrqRpLZxFKqqTsbarY8PRlP1oqL0Npd3o+h9lq0iSajLK8s7ochj+yp/wCxVopckt6KKKgkKKKKAKKKKAgX7bJDgDvxPn2wD/eqbp6d7f8AR5Y3yENcQaNFIjNzysAYfnRRWRiVGjxH/h5rlq00zf7Od3t5WcmRWWJJ1bd6h2P04prSZn1fp3Qbm9ZmbXNYc3qqxUOqpNtTxzsAhjGM84Oc5NFFQCVDut9SsrKN3+GtepWhhQsTsjNk8mz5BnOB5DHpUPW7eG66Q6ke4iWSSDULtonbkxntVHB8uKKKA3KiOwUWtnDFFbxcIijAAzmiiigP/9k=_
Dekho

---

## October 18, 2026

[9:58 AM] **Aashu:** aaj chawal daal puri mix veg hai

[9:58 AM] **You:** Waaah

[12:13 PM] **You:** Today's class is completed 😃

[12:25 PM] **Aashu:**
> _You: Today's class is completed 😃_
itna jldii

[12:25 PM] **Aashu:** kab tak aayegi

[12:26 PM] **You:** Aa gaye bus me

[12:27 PM] **Aashu:** location

[12:27 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAMEBQYHAQII/8QAPhAAAgEDAwIEAgYIAwkAAAAAAQIDBAURAAYhEjETIkFRYXEHFDKBkcEVFkJSoaKx4SNi0SQzNFNygpOy8P/EABoBAAIDAQEAAAAAAAAAAAAAAAABAgMEBQb/xAAsEQACAQMEAQEGBwAAAAAAAAAAAQIEESEDBRIxQWETFCJRgdEGIzKhsfDx/9oADAMBAAIRAxEAPwDeLvtKguO6LHe2LRy2lWSOFQOhxg9GfbpJJGuXnblDX3+G73R0qWp6NqeGkmiV4lYtkyYOcscAazi+/SneIq2qNDJaoP0dRwz1FDNGzvLKSFmi6s+Qoxxj4eup/wCkTdVztMG3ay2S2qloLlF4kr3IF2iJCsPKD1MMNjCg8+2mhMs9psNstG4q6tt08dO9dSxmW3xKqr5DgShRyO+O2OdJy2ung3Hcbyks5qKyljpzGyYVQhzkeus6+j66Xe8fSZb7lulYqKpmtMppI4YDGJow7DD5OR2LDPpjtqxb53BuGHetFZdt/omUS0RqpTUxMxgQE9TsQexxwACfxGorEg7Q/pbdSzXuz3GWVhVRxS0kUBdFEys3U5GT1HpHJwPTU3RWqkj3PcL4amUT1VPHTNEcBVCHOQe/Osqoqy63Temxqi+1NuW1SzPPb6mgp2TxJBjMbB8MoJx6YOR92027xSkojCcscFieDgemO2rHltiWMEduex0m5bLLa5q140kkjk6kYMR0MG9flpnetq2jcm4bJuSOrBqLfL1JNTlXWdVbPQSPZgR8MnVYiu++LhFWix3vZl0rKZCWp6Qs0ntxk4/HjOonbNzbbX0Em62qrp5amKdpJBVwHpjkZwrQqgPBzjHzzxqIy/V+2rZ+sNZdrg1NWVdwEVPTw1iRlYwik9EYbuTyTpzadp0FshvlLD5rbdZTLJRMgEcfUvS4XHo3Hy1md8XdE182PHvJ7bR0M9wjnje3wESRTgArE5J46s4yMjPvgast/vO56j6RKuxbaazLT09MlTLJVxOTF1Y4JB5JJyMDsdAD9NgVD0dJa6jclxqLFSyJJDRNDEGwhBRWlA6ioIHp+Wpu6bYpbnuSC8XNEqzBStTw0c8atCpZstJyDluANY7um+b4uKXOzV0tDElBWQRV4oIZifCcFlclCWMR9QoDdvfWp/RcjHY1raW3vbZD1s1P1yH9s+b/ABCXwQMgMex0AV/df0Q2m/3dq+CpltXWiq9PRxqI+ocdQHGMjHp6aNX24eP4y+C7hen098nRp2ApNR9GxrnWXdG47jeKaJvE+q+GkCSMO3X08n+up7dmzkv9fbLhRXGotN0t4ZIJ4EV1Ct3BQ8fLViqeVRf3nA/jn8tKSOUjZx3UE6Q7GIU9StBT3jcFlq7nuC/fUZVS41bRw+BGBnxIoXHnT1OM+owM83Dc+1f1graC+0F4qKC6yW7wXkowpSoiK9WB1Y6cljg/L21Kz7L2rnEu37UPFbxHJhAyw9vYc9u2pGv6AQIyvQseAFxhR6AAdu2knd2E8IznZ20TSXPbMl/rq956V5Zaa2PIkqU0h6m5kU+YeUEfHHx1aNxbytlgpJaOqSapqp0YeDAQCFZcZZj9n+vw0jaFLbktxAyF8Rj8PIR+esSuFfLVyVFfUEvLMTK3zPp8hwPkNZ67WdPaMe2djYdujXzlLVfwx/f+5JG01Vvt9Ha0pIq613Gh61F0opUeWRXYkq8ZVQ4GeMtwPfWnW7ZtgvH0ZR2K3XKskopZ/rL1gi6neTPmyuOPQY9Mawykr5JJwkgXDdsemtY+hO4yQXuuoWc/VpaczlfZ1ZVyPmH5+Q1lpqvUeooambnX3XZaaFO6imxx7X+mh70stHuP9FGonnh+o1yViCNPtlc8HPppjuXaC3TcC3203S42S8eGIZJqeMOsqDsGQ9/T4cDVjuMqPCoRgSGzj7jp11TDvEp+T/211DyBXNl7ZpNr/X5xWVtfc7hIJKqsqVPVIRnAAxwBk/j8sWZHWQllOT2Jxzrz4jjvC/3EH89dSTqbBR1PxGkNCmjRo0hjeRiZoh7Zb+GPz0VLZgcY7jH48ajBNOG6vFBbGOVH5a61TUMMMYiMg/YI7c++o8JpoXOJIzBjKrqoYAEEE49tRV0fHjEjpxHjH46XFbOO6RH7yNM6xZKmOX7Ks+PXIHb/AE09OElK8hTkmsENYedyUw9FglY/D7I/M6yTdljksd2lpnQ/VZcvTt6Mh/Z+Yzg/cfXWyW2gnpbm1SxQr4DQ4B55ZTn+X+Ove5rXTX2wyW+oicSjLwzgA+HJzg9845wR6jOq6/Q9svh7Onsm5e4a15fpff3+h89Q0kMLl0Xn4ntrYPobtIooai8VuUepQRU6lTnw85Lf9xAx8Fz66pexbCLtuIwXKFxTURLVUYGcsCQIz8yDn4KdbytVQ9IHSqgejREAfw1goadt+0n9DvfiHc4xj7po2zl/ykcr5o5YkWNsnq9vgdOpGmRGbEYCgnuTplVPSsqeA0OerzFMZA+OnFRUK8UioCVKHBCnvrrWPHXFh4xAPVGM/wCU/wCuvSCQN53Qj2Ckfnrz0S/87+Ua9KsgYdTqR7dOPz0hiUlbAjFWfkd8AnRpwAB2AGjRgMkOaSdQxZ06QCc9P99AppycDwycA8kj8tQu7bvU2nctplM0i2yKlmmrYgfK0fiRx9RH+UyBs+yn30xtV7ukO1dxVddJO1zev8GliwXaF5ooSkaqO4QyHgfunSUpNXE4xuWbwJ/EKCNSwGThv7abTVCwqhdWy3YAZ1ASXOsl2tBGste1wgucNvn8xgqJkDZUknBBeNkJz6nSctwq5NrUyLUVgr6yslpImjUzVNNErkuGwMl1VCM+hYcnuZxk/JFx+RaEJdVKI7ZGcAc41xyQPMki8/tIRqGuddNc9hQ3VZ6ujrYykcggmeErL4qRyqyjGcEMBntqUqqi40O7aOhtqNWwrbnYx1NWy8iUAOWIYk+n36OTDiIUNBQUNRVz0kUcU1W/iTsCcu3vz/8Acn309DAgEEEHtjVXuN9uSbb2w1BJWTXA26G5VTQxtI0wSNcRuQDgSMW5P7p1NVl1rZdwZs0cdXQzWhKpEefwlXqdsOPKcnGPbQnbpDleTvJ3H5XOcjXnwUHIjUfEDVavN8rYLdYTRfWpKqKhiuda0EJkMygKBHIQDgOPFOT6qNWBa2lk3ZPStVoLfJbKaanjaXoVi0s3mXkckBfwGjkLiLhSuOlpF+Tkfnr2JJV7SyZ+LE/102sFaai63KCaqV5IbnKiRPIOpUCIQACc47nRtBZbltGy1dXPJJUS0cbO7nJZivJJ0ckHF+B39ZnHaZvwH+mjTo2/2l/l/vo07xC0hzUKrPGGRGLZQllB8uMkc+hwNenVM58OPqL+IT0D7WMdXzxxnXpsDBI0i0ydZBbpPbzcaom8WRal8yK3BcY7UKeR6aoqGqZekCEQA9YHl5kZcn2xk8arTbykhrroamxVsVPStCi4SFJkklyC0hMmAjYUBwcZBHpxLbpo6G6RA18Uj/V3PgtFMY2GcBhkehI/gNR1u2pZ52iJiuHTL0K0bV8jI0aHqVCD3UHOB8dWRi+KbK21ew/j3hRQ0tzjrrdUQT0UD1kkLmBxKqsAxDIxUsGxkEg5I12k3JcJ79VpPZZqbwaCOeKnmeJaiQtIR5W6+np7ZBIIIHvp5SbOsVNJcGWjZ1ro3ilSSVmUI7dTKoz5QTzx7D21z9U7THTVMVRHU1oq41ppXq6l5X8IHIRWJyoB549edBIgrJvpa2qvdTDQJDRWumgHgtJDHIT1sDhy/QYwOftDtx357t7fdPfL1SQ2ykp6aihjmFX4ksDSdCLlRGqMWIDfDBGdSn6mWOjt9fF4FRMK0oJ5JahmkIDdS4b0IbDZ9T3zpSj2parNXRXKmWrkqYpGkBnqnkHiOOl5ME/aI4J0CK7bt6V9beKSut9FTLt2rrIbciyKqzvlF8w6Sc9JZj7BQRgEHWgyUdK7xl6WnZogFQtEp6QOwHHAGqXctsLt++R37bNqSomld1qYlVeuMPjzRcADkHkk4zwMEg3ShWpSgpUr5ElrFhRZ3QeVpAo6iPhnOgaOimpxUmoFPAKg5PiiNevkY74zptFN9UYwygCNQAnSuAB6AAaf6b1kHjR8fbHKnQgfoIyXBY2w8MgzyMjHGjSBrmAAaJWYcEnRqVvQjy9SSfP3abVc6wRjKF2c9KoMeY4J9SB2BPPtrz9VnYkvUEH0xn+2mdek6TUolcMvVJj/AMMnw1jqfy4PUXgug7uzIquiqqiONFgwBy2Z4uf59SVul8CdfGgdEwI1brjYAkgDPSxPfA7euqDX1V9TdLyQW+pkiFJUR08fWnhMQ0PS7ecck9fHBxjA+1qY2Mar9BuletUJkrWXqqSOt1+uDpPBIxjA9uOOME8Kn3zX1ZQUuNpW6ec3+xplSQjdq+DQ9JVP+7B9nX/2GldN6tP8MvlsjBxk47+2vToxs7XL1Uko9lz+HOioHi0T/wCZM/npWReqNl9wRpKjPXSRZ/dxoEe4iJYFJ5DKM/hrlMSYgrfaTyn7tJ0B/wBmCnuhKn7joMa/Wm6urDDqAyQMjg/loAcEgDJ4GmU0ktSjim4jH7Xq3wGla9GeEFcsFOWT94e2loWVolaP7BHGjrId4GcVNBPGroCgxggHsfjo08EaAkhRknJ+ejRdhxR71DX/ADlHUlXiRnQj0OMffxkfedGjUJK8XcZH2/FVaqepZQjtIkZCk4wSBnnJzzpxRBZb5U0ZAENN0uMd3IOR1H4EA4GO2jRrztJTaMaqTUErW8I2ak5OCyWHSVV/w0v/AEH+mjRr0q7Mb6FdNqDinx6BmA/E6NGjwLyFJxJUAdvEz/Aac6NGhgg1zto0aQzujRo0Af/Z: Live location: 12.9569168, 77.7019771 — https://maps.google.com/?q=12.9569168,77.7019771

[12:31 PM] **Aashu:** abhi hi chal legi na zudio

[12:34 PM] **You:** Aate h phle

[12:41 PM] **Aashu:** aao

[12:41 PM] **Aashu:** aaj traffic nahi hai ekdum

[12:42 PM] **You:** Haa

[12:54 PM] **Aashu:** aao yahi niche hai

[12:54 PM] **Aashu:** hum chodhuary

[12:58 PM] **Aashu:** net off kar di ho

[1:13 PM] **You:** Okk

[1:25 PM] **You:** Call bhi karna padega

---

## October 19, 2026

[8:41 AM] **Aashu:** [Document] aadhar_card.pdf

[11:39 AM] **Aashu:**
> _You: Video_
cutupie

[4:57 PM] **Aashu:**
> _You: Video_
maa koicha mtlb

---

## October 20, 2026

[12:25 AM] **Aashu:** [Video]

[12:25 AM] **Aashu:** [Video]

[12:25 AM] **Aashu:** [Video]

[4:14 PM] **Aashu:**
> _You: Video_
😍

[7:30 PM] **Aashu:** [Forwarded] [Video]

[11:34 PM] **Aashu:** [Forwarded] https://youtu.be/-gyqUcDpBhg

---

## October 21, 2026

[10:11 PM] **You:** [Document] adarsh passport .pdf

---

## October 22, 2026

[2:01 PM] **Aashu:** [Forwarded] [Video] अपने घर के पास का वीडियो

[10:49 PM] __[Call]__

[10:49 PM] **You:** Aa gaya

[10:49 PM] __[Call]__

[10:50 PM] **Aashu:** ok

[10:53 PM] __[Call]__

[10:58 PM] __[Call]__

---

## October 23, 2026

[11:14 AM] **Aashu:** [Forwarded] https://www.facebook.com/share/v/1KcBY19nDR/

[1:16 PM] **You:** Lunch kb Krna h

[1:16 PM] __[Call]__

[1:17 PM] **You:** [Image]

[1:17 PM] **Aashu:**
> _You: Image_
delete karo

[1:17 PM] **You:** Noo chance

---

## October 24, 2026

[10:13 AM] **You:** [Forwarded] Availability Check: Delivery of  Order V-WALK Women Metal Detail P...
     
Your Myntra order is out for delivery. 

Kindly pay Rs 1032.0 for your cash on delivery order.

For a smooth delivery experience, confirm your availability to collect the order today between 7 am - 11 pm.

Contact Delivery Partner: 08047947777 
PIN: 132

[10:13 AM] **Aashu:** hum to rahenge hi nhi

[10:13 AM] **Aashu:**
> _You: Availability Check: Delivery of  Order V-WALK Women Metal Detail P...
     
Your Myntra order is out for delivery. 

Kindly pay Rs 1032.0 for your cash on delivery order.

For a smooth delivery experience, confirm your availability to collect the order today between 7 am - 11 pm.

Contact Delivery Partner: 08047947777 
PIN: 132_
kya hai ye

[10:14 AM] **You:** Chappal mera

[10:14 AM] **Aashu:** ohh

[10:14 AM] **Aashu:** but hum to nikal rahe ab

[10:15 AM] **Aashu:** online hi payment kar do nahi to aap par

[10:15 AM] **Aashu:** bolo guard ko dekar chala jayega

[10:15 AM] **You:** Okok

[5:15 PM] **You:** Momos lete aaoge na

[6:06 PM] **Aashu:** shayad nahi

[6:06 PM] **Aashu:** aaj dusre taraf se aa rahe

[6:17 PM] **You:** 🥺

[7:08 PM] **Aashu:** le liye momos

[7:08 PM] **Aashu:** but dusre jagah se liye

[7:40 PM] **You:** Kitna time lag rha aaj

[8:00 PM] **Aashu:** aadha ghanta aur

[8:01 PM] **You:** Itna time aaj kaise lag raha

[8:02 PM] **Aashu:**
> _You: Itna time aaj kaise lag raha_
traffic

[8:03 PM] **You:** Ohh

---

## October 25, 2026

[10:55 AM] **You:** [Image]

[10:56 AM] **You:** Kon sa le

[10:56 AM] **You:** Bata dena

[10:56 AM] **Aashu:** abhi nhi lena

[10:56 AM] **Aashu:** or meal nhi lena

[10:56 AM] **You:** Dekh ke rakhte h

[10:56 AM] **Aashu:** ruko hum batate hai

[10:56 AM] **You:** Last me bas order kar denge

[10:57 AM] **Aashu:** [Image]

[10:57 AM] **You:** Ok

[10:59 AM] **You:** Yahi n

[10:59 AM] **You:** [Image]

[10:59 AM] **Aashu:** nhi yaar

[10:59 AM] **Aashu:** ye nhi hai

[11:00 AM] **Aashu:** zomato login karo

[11:00 AM] **Aashu:** mere number se

[11:00 AM] **Aashu:** ya apne number se hi karo

[11:00 AM] **Aashu:** delivery free hai

[11:00 AM] **Aashu:** woha

[11:00 AM] **You:** Ok

[11:00 AM] **You:** Link share karna

[11:00 AM] **Aashu:** ok

[11:02 AM] **Aashu:** nhi aa reha tmko invite karne ka option

[11:02 AM] **Aashu:** tumhara is number se zomato bana hai

[11:02 AM] **You:** Meghana Special Boneless Chicken Biryani from Meghana Biryani
https://link.zomato.com/xqzv/dshare?id=15191114939fdade8

[11:02 AM] **You:** Ye h

[11:03 AM] **You:** But ek chij pata h meghna ka ratin waisa nhi dikh Raha or sab ka to accha hai

[11:03 AM] **Aashu:**
> _You: But ek chij pata h meghna ka ratin waisa nhi dikh Raha or sab ka to accha hai_
chill

[11:03 AM] **Aashu:** jo dikhta hai wo bikta nhi

[11:03 AM] **Aashu:**
> _You: Ye h_
hh

[11:05 AM] **You:** Delivery fee le raha

[11:05 AM] **You:** 32

[11:05 AM] **Aashu:** mere bhi lega

[11:05 AM] **You:** Kyu

[11:05 AM] **Aashu:** mera expire ho gaya hai

[11:05 AM] **You:** Ohk

[11:05 AM] **Aashu:** gold

[11:05 AM] **You:** Koi n kr dete h

[11:05 AM] **You:** 433 ka aa raha

[11:05 AM] **Aashu:** hh kk

[11:06 AM] **Aashu:** [Image] mereko 611

[1:57 PM] **Aashu:** le li

[1:58 PM] **You:** Le liye but time jyada le raha aane me

[1:58 PM] **You:** 1 30 pe hi order kiye the

[1:59 PM] **Aashu:** ohh

[1:59 PM] **Aashu:** kitna time dikha reha

[2:00 PM] **You:** Thodi der phle 55 minutes dikha Raha tha

[2:00 PM] **You:** Ab 15 dikha Raha

[2:00 PM] **Aashu:** okk

[2:01 PM] **You:** Ab 18 dikha Raha

[2:01 PM] **Aashu:** accha koi nahi

[2:04 PM] **You:** Tab se wahi time pe h

[2:07 PM] **Aashu:** please call him

[2:07 PM] **You:** [Image]

[2:17 PM] **Aashu:**
> _You: Image_
kon hai

[2:18 PM] **You:** Zomato wala

[2:18 PM] **Aashu:** aaya

[2:18 PM] **You:** Almost

[2:18 PM] **Aashu:** ok

[2:18 PM] **Aashu:** aaj jao jldi ab

[2:21 PM] **You:** Aayega tab n

[2:21 PM] **Aashu:** aao

[2:21 PM] **Aashu:** aao

[2:38 PM] **Aashu:** baithi

[2:38 PM] **Aashu:** babu

[2:38 PM] **You:** Haa abhi bus mila h

[2:53 PM] **Aashu:** location

[2:55 PM] **You:** Battery low ho rha h

[2:55 PM] **You:** Isiliye data off kr rhe

[2:55 PM] **You:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAQDBQEGBwII/8QAPBAAAgEDAwICBwYEBAcAAAAAAQIDAAQRBRIhBjFBYRMiMlFxgaEHFEKRwdEVUmKxIyTh8DM0U2OCkvH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQMCBQQG/8QAJxEAAgEDBAECBwAAAAAAAAAAAAERAgQhAwUSMSIGgRMUMkGx0fH/2gAMAwEAAhEDEQA/APpulrn1ri2Tw3FvyH+tM0nO226Zv+nCT8z/APKaBnux5SR/55CR8O36V7h4mmU+0SG+Ixj9KLRNlrEv9IrE/qMkvgpw3wP+xQBPRRRSGL3ft24/7g/saYpe45nth/UT9DXtpHRwHQbScBgf70xEtFFFIYVGYhtk28F+5+WKkooAURLqNFRWgIUADINFN0U5FAVWz+ubnH43WIfrVg7BEZj2UZqtEbvHbRhtsjZlJ8/D+9NAy0rDKGUqwyCMEUpDe5jRpY3UHjcBlacpRA5kXO+3Gcl4h3z3X9xWvdX9bab00Vhl33N667lt4SMgeBYnhR9fKtpr5U1K/kvJrnULj1pZmMrfPsB5AYA8hXju7h6NK49s7WybbRfalT1H409nU4ftajkvIGu9GkigQnc0NwJG5GOxVR9a6LaapZ6tpCXunTCeByNhXvuB7Edwc+Br5StL+SScJIFw3bHhXVvsVuZjrl7YCRhC9ubnGeA6sq5x5h+fgKhbXeo9RUamZOnuuzW1FtVr22OPa/p2hGDoGXsRkV6pWMyW5cSjMZOQyDt7+KYVldQykEHxFdNnySPVFFFIAooooARu2naHY6Iochchsnk0SMFluXHAjjCD+/7Vql71TDaw6e9r95k3arHZXUFxbyemizE7gBDzk4UgjPBp4dQW0+mLcRyXdwsszQGCOxdrgSJ7SsgxtxjnP7VuDHIvnTbDaReO5c/IZNO1omtdYyJHJdaSbW4thodxqUEjRtkukiKMgkEDDEEd81sFnrRnuNRicwO1pJEpWNWUqHiV/WJ4J58PDzpOljVSLuvm/rjp2Tp3XJ7V0P3KUs9s/g0ZPs/Fc4PyPjXZ9S670DSro22pahDBcL7UYV5CvkdinB8jzVZqupdNde6TcadZ6jFJcoPSRMEdXjcDhgGUEj348Ce1ea6tnrUYWUdbaNzVjry/peH+/Y4NDaQwuXRefM9q7P8AYx09La20+t3aFGukEVup4Po85LfBiBjyXPjWkfZ906ut9Sm31JdlrZZa6RjjcwOBH8yDnyU19B7cJtjwuBgccD5V4rG3bfxa/Y7nqDcqaaflNH75f5SB22ozHnAzUZhRvXQshPOVOM/HwoMUjAhpjg+5RWbY5t0z3AwfiOK6p8cYxOvZkkHmNp/Oj0+3/iRuvnjI+lTUUDI1mjYZEiEfGistGjHLIpPmKKQGiaV0bLbXsM7XOnx79Sh1JYbRG9GESBo9qk987gc+PPA7VPfdHX0kjPb3lpNG+o3F49pcq/oZBIqhdwXkshBIHbmlNKvru1uLNdU1BdB02KyhWG2d8Fka2UbV3KcuspPOS3qAYwc0jq2r6y7WRlu7i0u8W/popLloDIjD15RGEO1VHLH8JDZxjBrmSOIG16KNv080MurWQji0i60x5/ZjV3nDbic4AGCCM5zV7aaaLHVLy69Ok8WpXNo6BAcBUiSM89jnGePfWszyzDT7Geb7wdCa5YzyW1zuM0ySFxIJGZPVfauGB4K4HcGtv6dtDB0+lvFGtrIGa5htTJueCN3Zow3PkfLOQCcUm2NJHI+l9Ht+ofs01cyQRza9NfSyW85QGV2SOORkDd+Rv495q21vTLHQ9b+zy30yKGOdLw2l3PEgVpnDQq+4jk8s4595rFz0prek3ijp3VobG0iumvIYJ4GLQyMuw4KxvuG3jnHHhTHTnSerSanY3GtalHfCynkubaOGJlAlkIZnZmRT7QDYweR4c1R1LuSapfUG3aNp1naCa5tbdYprsiSZgT67Y7/79599U2udXapp2o9SLbXGjpZaMkRFvdbhNcExB2VGD8HnA9U84FbzHpkaRKgkkGBjjH7VrOq9BQ3Z1a7iuYf4tc30d/aXL24zbsgQKhOSWU7Tnt37VJcei1TrbluWRdQ9cWukWtwLaeSfVF9ABZywsVjeRkwjSABQwVicbs8VY9TdU2vS89gt8JGhvrw24kGMQjGS7e8DPPlmqvUOkdYmuL21t5dLOlXurRapLJK7iZcNGzx7Qu1h6nBJHgPOrLqPpmTWte0Z7mOCbTIVvVuQzYb/ABYwi4HwLfSn4i8izh1oTapqWmxp/mrAwiRnwkchlUsoTknPHj7xTguLsAbrJsf0t/pXL4Omde0qG4udStZr94tbsZQbfDyT2tumxZNoOSeFJHfOTTNlol5q2twDUdKv47C8128vJ0kjZMRC2CR7yDwCcYGcHkUcUHJnSRdSfis7nPkAf1orS+gukbK76Zhm1eC/Nw004SOa5nQxRiVwihdwwu0Aj40VlwjSbZ0AOw8TWQ7D8RpRPWvpT/IgX8+aZrJoH/xFZXLbXUqcMQcH3Edqo+munxoayKb2S7ABjgDRhPQxli23j2jk9z8gKvKKJFB4jkEm/bn1W2nPvr3S1jzE7fzSMfrTNDGgopdeb9/KMD6mmKACiiigBabm8tx7gx+lM5PvNV9zLN973W8e8Rja3zrH8QkTiWDafMkfpWoFKI7yVxdSgOwGR4+QopS4kMsrOABuPjzRW0ibLS1mjMlw5kQEvgesOwFNB0PZlPzryYYiOY0/9RXk2sB7wp8hip4KZJqwTgEnsKg+5weEePgSKXlt4/vUMY3FSGLLuPajADFgMWkXmM/nTFLCzhHshl+Dn96z919004/86MAEfN7N5Iv60xUMEHomdt7uWxkt5VNQxoKKKKQFaYJJppnhZY8OR3OT9aDb3eVDussYIO0t3+eKbe1iZyxUhjySGIqGeMQKCJbgknCqHzk/OtSZgSCLIzs5CtuPFFQpKUyNxGefpRWoZmUX0bFo1Y9yAa9UUVMoFLJzqEpP4UAFFFNCYzRRRSGFFFFABRRRQAUrc/8AMW/luP0oopoTKJ/a/Kiiiroif//Z: Live location: 12.9776453, 77.7161326 — https://maps.google.com/?q=12.9776453,77.7161326

[2:55 PM] **Aashu:** ok location bej do

[2:55 PM] **Aashu:** bus

[2:55 PM] **Aashu:** aur call karna

[2:55 PM] **Aashu:** pauchne par

[2:55 PM] **You:** Ok

[2:56 PM] **Aashu:** bbyy traffic nahi hai jada 35 mjn lagega bus

[2:56 PM] **You:** Haa

[2:56 PM] **You:** Kadugudi me bus mil jaye bas jldi

[3:26 PM] **You:** Aa jao

[3:26 PM] **Aashu:** kab se aaye hur hai

[3:27 PM] **Aashu:** bus ruk gaya tha lya

---

## October 27, 2026

[12:14 AM] **Aashu:** [Video]

[12:17 AM] **You:** [album message]

[12:17 AM] **You:** [Image]

[12:17 AM] **You:** [Image]

[12:17 AM] **You:** [Image]

[12:17 AM] **You:** [Image]

[12:17 AM] **You:** [Image]

[12:23 AM] **You:** [Image]

[12:23 AM] **You:** [Document] swati___singh53_d08dae57_1.jpg

[3:40 PM] **Aashu:** [Document] adarsh passport .pdf

---

## October 28, 2026

[9:14 AM] **Aashu:** [Document] IMG_6419.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6420.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6417.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6423.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6418.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6416.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6422.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6412.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6415.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6414.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6410.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6411.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6413.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6408.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6407.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6409.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6405.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6404.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6406.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6402.HEIC

[9:14 AM] **Aashu:** [Document] IMG_6403.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6401.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6396.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6399.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6393.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6391.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6389.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6398.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6388.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6392.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6386.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6387.HEIC

[9:15 AM] **Aashu:** [Document] IMG_6390.HEIC

[10:07 AM] **Aashu:** [Forwarded] Flat C-701 – Available for Rent from 2nd December

🏠 2 BHK Flat (Fully Furnished) Available for Rent

🏢 Flat Name: Skandagiri BDA Apartments

📍https://maps.app.goo.gl/B1B4Z1rmhcrxGCaL6?g_st=ic

Amenities:
- ⁠Covered Car & Bike parking
- ⁠East Facing
- ⁠Geyser
- TV unit
- Cupboards/wardrobes
- Covered varandah
- Shoe stand 
- Furnished utility 
- Fans and lights
- Towel hangers
- Cloth Drying hanger 

Please contact 📞 +91 8143192378
for more details or to schedule a visit.

[10:07 AM] **Aashu:** hello ise puchna to ye kitna me flat laga reha

[10:07 AM] **Aashu:** bolna tumhare ek friend ko chaiye

[10:13 AM] **You:** [Image]

[10:14 AM] **Aashu:** ok

[11:23 PM] **Aashu:** [Forwarded] [Document] Booking_Confirmation_Voucher

[11:24 PM] **Aashu:** [Forwarded] [Document] Property_Rules_and_Policy

[11:30 PM] **You:** https://youtube.com/shorts/bDZ-XBBozR4?si=fXC0TUrnpliynPGL

---

## October 29, 2026

[6:35 PM] **You:** [Image]

[9:09 PM] **Aashu:** kuch problem hoga to bolna

[9:10 PM] **You:** Okok no problem

[9:10 PM] **You:** So jao

[9:10 PM] **You:** I love you 😘

[9:10 PM] **Aashu:** abhi reel dekhenge

[9:10 PM] **Aashu:**
> _You: I love you 😘_
ye chat me i love you gajab ❤️

[9:11 PM] **You:**
> _Aashu: ye chat me i love you gajab ❤️_
Ye reply hota hai

[9:11 PM] **Aashu:** i love you too babes

[9:40 PM] **You:** [Image]

---

## October 30, 2026

[10:44 AM] **You:** [Image]

[7:22 PM] **Aashu:** [album message]

[7:22 PM] **Aashu:** [Image]

[7:22 PM] **Aashu:** [Image]

[7:22 PM] **Aashu:** [Image]

[10:06 PM] **Aashu:** [Document] IMG_6542.JPG

[10:06 PM] **Aashu:** [Document] IMG_6539.JPG

[10:06 PM] **Aashu:** [Document] IMG_6513.JPG

[10:06 PM] **Aashu:** [Document] IMG_6537.JPG

[10:06 PM] **Aashu:** [Document] IMG_6510.JPG

[10:06 PM] **Aashu:** [Document] IMG_6509.JPG

[10:06 PM] **Aashu:** [Document] IMG_6508.JPG

[10:06 PM] **Aashu:** [Document] IMG_6511.JPG

[10:06 PM] **Aashu:** [Document] IMG_6500.JPG

[10:06 PM] **Aashu:** [Document] IMG_6498.JPG

[10:06 PM] **Aashu:** [Document] IMG_6464.JPG

[10:06 PM] **Aashu:** [Document] IMG_6455.JPG

[10:06 PM] **Aashu:** [Document] IMG_6458.JPG

[10:06 PM] **Aashu:** [Document] IMG_6452.JPG

---

## October 31, 2026

[1:36 PM] **You:** Radhe radhe 🙏🙏

[8:18 PM] **Aashu:** [Video]

[9:47 PM] **Aashu:** [Document] IMG_6555.MOV

---

## November 1, 2026

[11:48 AM] **Aashu:** [Video]

[5:14 PM] **Aashu:**
> _You: Video_
😍

---

## November 2, 2026

[7:50 AM] **Aashu:** [Document] IMG_7014.JPG

[7:50 AM] **Aashu:** [Document] IMG_7015.JPG

[7:50 AM] **Aashu:** [Document] IMG_7012.JPG

[7:50 AM] **Aashu:** [Document] IMG_7024.JPG

[7:50 AM] **Aashu:** [Document] IMG_7013.JPG

[7:50 AM] **Aashu:** [Document] IMG_7010.JPG

[7:50 AM] **Aashu:** [Document] IMG_7016.JPG

[7:50 AM] **Aashu:** [Document] IMG_7009.JPG

[7:50 AM] **Aashu:** [Document] IMG_7011.JPG

[7:50 AM] **Aashu:** [Document] IMG_6996.JPG

[7:50 AM] **Aashu:** [Document] IMG_7008.JPG

[7:51 AM] **Aashu:** [Document] IMG_7002.JPG

[7:51 AM] **Aashu:** [Document] IMG_7005.JPG

[7:51 AM] **Aashu:** [Document] IMG_7007.JPG

[7:51 AM] **Aashu:** [Document] IMG_7006.JPG

[7:51 AM] **Aashu:** [Document] IMG_6994.JPG

[7:51 AM] **Aashu:** [Document] IMG_6829.JPG

[7:51 AM] **Aashu:** [Document] IMG_6993.JPG

[7:51 AM] **Aashu:** [Document] IMG_6995.JPG

[7:51 AM] **Aashu:** [Document] IMG_6821.JPG

[7:51 AM] **Aashu:** [Document] IMG_6815.JPG

[7:51 AM] **Aashu:** [Document] IMG_6816.JPG

[7:51 AM] **Aashu:** [Document] IMG_6812.JPG

[7:51 AM] **Aashu:** [Document] IMG_6827.JPG

[7:51 AM] **Aashu:** [Document] IMG_6813.JPG

[7:51 AM] **Aashu:** [Document] IMG_6817.JPG

[7:51 AM] **Aashu:** [Document] IMG_6808.JPG

[7:51 AM] **Aashu:** [Document] IMG_6809.JPG

[7:51 AM] **Aashu:** [Document] IMG_6807.JPG

[7:51 AM] **Aashu:** [Document] IMG_6806.JPG

[7:51 AM] **Aashu:** [Document] IMG_6805.JPG

[7:51 AM] **Aashu:** [Document] IMG_6794.JPG

[7:51 AM] **Aashu:** [Document] IMG_6790.JPG

[7:51 AM] **Aashu:** [Document] IMG_6795.JPG

[7:51 AM] **Aashu:** [Document] IMG_6788.MOV

[7:51 AM] **Aashu:** [Document] IMG_6772.JPG

[7:51 AM] **Aashu:** [Document] IMG_6762.JPG

[7:51 AM] **Aashu:** [Document] IMG_6760.JPG

[7:51 AM] **Aashu:** [Document] IMG_6759.JPG

[7:51 AM] **Aashu:** [Document] IMG_6755.JPG

[7:51 AM] **Aashu:** [Document] IMG_6751.JPG

[7:51 AM] **Aashu:** [Document] IMG_6715.JPG

[7:51 AM] **Aashu:** [Document] IMG_6706.JPG

[7:51 AM] **Aashu:** [Document] IMG_6638.JPG

[7:51 AM] **Aashu:** [Document] IMG_6657.JPG

[7:51 AM] **Aashu:** [Document] IMG_6631.JPG

[7:51 AM] **Aashu:** [Document] IMG_6618.JPG

[7:51 AM] **Aashu:** [Document] IMG_6574.MOV

[7:51 AM] **Aashu:** [Document] IMG_6572.JPG

[7:51 AM] **Aashu:** [Document] IMG_6838.JPG

[7:51 AM] **Aashu:** [Document] IMG_6589.JPG

[7:51 AM] **Aashu:** [Document] IMG_6843.JPG

[7:51 AM] **Aashu:** [Document] IMG_6855.JPG

[7:51 AM] **Aashu:** [Document] IMG_6861.JPG

[7:51 AM] **Aashu:** [Document] IMG_6856.JPG

[7:51 AM] **Aashu:** [Document] IMG_6858.JPG

[7:51 AM] **Aashu:** [Document] IMG_6862.JPG

[7:51 AM] **Aashu:** [Document] IMG_6875.JPG

[7:51 AM] **Aashu:** [Document] IMG_6885.JPG

[7:51 AM] **Aashu:** [Document] IMG_6863.JPG

[7:51 AM] **Aashu:** [Document] IMG_6873.JPG

[7:51 AM] **Aashu:** [Document] IMG_6886.JPG

[7:52 AM] **Aashu:** [Document] IMG_6892.JPG

[7:52 AM] **Aashu:** [Document] IMG_6890.JPG

[7:52 AM] **Aashu:** [Document] IMG_6887.JPG

[7:52 AM] **Aashu:** [Document] IMG_6893.JPG

[7:52 AM] **Aashu:** [Document] IMG_6895.JPG

[7:52 AM] **Aashu:** [Document] IMG_6965.JPG

[7:52 AM] **Aashu:** [Document] IMG_6915.JPG

[7:52 AM] **Aashu:** [Document] IMG_6900.JPG

[7:52 AM] **Aashu:** [Document] IMG_6979.JPG

[7:52 AM] **Aashu:** [Document] IMG_6972.JPG

[7:52 AM] **Aashu:** [Document] IMG_6537.JPG

[7:52 AM] **Aashu:** [Document] IMG_6505.JPG

[7:52 AM] **Aashu:** [Document] IMG_6543.JPG

[7:52 AM] **Aashu:** [Document] IMG_6501.JPG

[7:52 AM] **Aashu:** [Document] IMG_6513.JPG

[7:52 AM] **Aashu:** [Document] IMG_6493.JPG

[7:52 AM] **Aashu:** [Document] IMG_6498.JPG

[7:52 AM] **Aashu:** [Document] IMG_6474.JPG

[7:52 AM] **Aashu:** [Document] IMG_6496.JPG

[7:52 AM] **Aashu:** [Document] IMG_6484.JPG

[7:52 AM] **Aashu:** [Document] IMG_6469.JPG

[7:52 AM] **Aashu:** [Document] IMG_6458.JPG

[7:52 AM] **Aashu:** [Document] IMG_6466.JPG

[7:52 AM] **Aashu:** [Document] IMG_6455.JPG

[7:52 AM] **Aashu:** [Document] IMG_6453.JPG

[7:52 AM] **Aashu:** [Document] IMG_6491.JPG

[12:38 PM] **Aashu:** [Document] IMG_6875.JPG

[12:38 PM] **Aashu:** [Document] IMG_7047.JPG

[12:38 PM] **Aashu:** [Document] IMG_7024.JPG

[12:38 PM] **Aashu:** [Document] IMG_6880.JPG

[12:38 PM] **Aashu:** [Document] IMG_6873.JPG

[12:38 PM] **Aashu:** [Document] IMG_6505.JPG

[12:38 PM] **Aashu:** [Document] IMG_6452.JPG

[12:38 PM] **Aashu:** [Document] IMG_6484.JPG

[12:38 PM] **Aashu:** [Document] IMG_7084.JPG

[12:38 PM] **Aashu:** [Document] IMG_7077.JPG

[12:38 PM] **Aashu:** [Document] IMG_7068.JPG

[12:38 PM] **Aashu:** [Document] IMG_7062.JPG

[12:38 PM] **Aashu:** [Document] IMG_7064.JPG

[12:38 PM] **Aashu:** [Document] IMG_7050.JPG

[12:38 PM] **Aashu:** [Document] IMG_7027.JPG

[12:38 PM] **Aashu:** [Document] IMG_6862.JPG

[12:38 PM] **Aashu:** [Document] IMG_7026.JPG

[12:38 PM] **Aashu:** [Document] IMG_7029.JPG

[12:38 PM] **Aashu:** [Document] IMG_7028.JPG

[12:39 PM] **Aashu:** [Document] IMG_6831.MOV

[12:39 PM] **Aashu:** [Document] IMG_6824.JPG

[12:39 PM] **Aashu:** [Document] IMG_6798.MOV

[12:39 PM] **Aashu:** [Document] IMG_6788.MOV

[12:39 PM] **Aashu:** [Document] IMG_6727.MOV

[12:39 PM] **Aashu:** [Document] IMG_6569.JPG

[12:39 PM] **Aashu:** [Document] IMG_6459.MOV

[12:39 PM] **Aashu:** [Document] IMG_6685.JPG

[12:39 PM] **Aashu:** [Document] IMG_6446.MOV

[1:11 PM] **Aashu:**
> _You: Video_
😍

[1:36 PM] **Aashu:** [Document] IMG_7071.JPG

[4:58 PM] **Aashu:** [Image]

[4:58 PM] **Aashu:** [Image]

[7:36 PM] **Aashu:** [Document] IMG_7197.JPG

[7:36 PM] **Aashu:** [Document] IMG_7198.JPG

[7:36 PM] **Aashu:** [Document] IMG_7191.JPG

[7:36 PM] **Aashu:** [Document] IMG_7194.JPG

[7:36 PM] **Aashu:** [Document] IMG_7196.JPG

[7:36 PM] **Aashu:** [Document] IMG_7195.JPG

[7:36 PM] **Aashu:** [Document] IMG_7193.JPG

[7:36 PM] **Aashu:** [Document] IMG_7189.JPG

[7:36 PM] **Aashu:** [Document] IMG_7192.JPG

[7:36 PM] **Aashu:** [Document] IMG_7190.JPG

[7:36 PM] **Aashu:** [Document] IMG_7184.JPG

[7:36 PM] **Aashu:** [Document] IMG_7187.JPG

[7:36 PM] **Aashu:** [Document] IMG_7183.JPG

[7:36 PM] **Aashu:** [Document] IMG_7182.JPG

[7:36 PM] **Aashu:** [Document] IMG_7188.JPG

[7:36 PM] **Aashu:** [Document] IMG_7185.JPG

[7:36 PM] **Aashu:** [Document] IMG_7180.JPG

[7:36 PM] **Aashu:** [Document] IMG_7174.JPG

[7:36 PM] **Aashu:** [Document] IMG_7181.JPG

[7:36 PM] **Aashu:** [Document] IMG_7179.JPG

[7:36 PM] **Aashu:** [Document] IMG_7175.JPG

[7:36 PM] **Aashu:** [Document] IMG_7168.JPG

[7:36 PM] **Aashu:** [Document] IMG_7171.JPG

[7:36 PM] **Aashu:** [Document] IMG_7177.JPG

[7:36 PM] **Aashu:** [Document] IMG_7176.JPG

[7:36 PM] **Aashu:** [Document] IMG_7167.JPG

[7:36 PM] **Aashu:** [Document] IMG_7172.JPG

[7:36 PM] **Aashu:** [Document] IMG_7166.JPG

[7:36 PM] **Aashu:** [Document] IMG_7170.JPG

[7:36 PM] **Aashu:** [Document] IMG_7173.JPG

[7:36 PM] **Aashu:** [Document] IMG_7165.JPG

[7:36 PM] **Aashu:** [Document] IMG_7162.JPG

[7:36 PM] **Aashu:** [Document] IMG_7163.JPG

[7:36 PM] **Aashu:** [Document] IMG_7164.JPG

[7:36 PM] **Aashu:** [Document] IMG_7160.JPG

[7:36 PM] **Aashu:** [Document] IMG_7157.JPG

[7:36 PM] **Aashu:** [Document] IMG_7159.JPG

[7:36 PM] **Aashu:** [Document] IMG_7158.JPG

[7:37 PM] **Aashu:** [Document] IMG_7156.JPG

[7:37 PM] **Aashu:** [Document] IMG_7154.JPG

[7:37 PM] **Aashu:** [Document] IMG_7151.JPG

[7:37 PM] **Aashu:** [Document] IMG_7153.JPG

[7:37 PM] **Aashu:** [Document] IMG_7155.JPG

[7:37 PM] **Aashu:** [Document] IMG_7152.JPG

[7:37 PM] **Aashu:** [Document] IMG_7150.JPG

[7:37 PM] **Aashu:** [Document] IMG_7147.JPG

[7:37 PM] **Aashu:** [Document] IMG_7148.JPG

[7:37 PM] **Aashu:** [Document] IMG_7149.JPG

[7:37 PM] **Aashu:** [Document] IMG_7144.JPG

[7:37 PM] **Aashu:** [Document] IMG_7145.JPG

[7:37 PM] **Aashu:** [Document] IMG_7141.JPG

[7:37 PM] **Aashu:** [Document] IMG_7146.JPG

[7:37 PM] **Aashu:** [Document] IMG_7142.JPG

[7:37 PM] **Aashu:** [Document] IMG_7143.JPG

[7:37 PM] **Aashu:** [Document] IMG_7138.JPG

[7:37 PM] **Aashu:** [Document] IMG_7139.JPG

[7:37 PM] **Aashu:** [Document] IMG_7140.JPG

[7:37 PM] **Aashu:** [Document] IMG_7135.JPG

[7:37 PM] **Aashu:** [Document] IMG_7136.JPG

[7:37 PM] **Aashu:** [Document] IMG_7137.JPG

[7:37 PM] **Aashu:** [Document] IMG_7134.JPG

[7:37 PM] **Aashu:** [Document] IMG_7132.JPG

[7:37 PM] **Aashu:** [Document] IMG_7133.JPG

[7:37 PM] **Aashu:** [Document] IMG_7130.JPG

[7:37 PM] **Aashu:** [Document] IMG_7131.JPG

[7:37 PM] **Aashu:** [Document] IMG_7124.JPG

[7:37 PM] **Aashu:** [Document] IMG_7126.JPG

[7:37 PM] **Aashu:** [Document] IMG_7121.JPG

[7:37 PM] **Aashu:** [Document] IMG_7127.JPG

[7:37 PM] **Aashu:** [Document] IMG_7119.JPG

[7:37 PM] **Aashu:** [Document] IMG_7122.JPG

[7:37 PM] **Aashu:** [Document] IMG_7120.JPG

[7:37 PM] **Aashu:** [Document] IMG_7118.JPG

[11:40 PM] **You:** Kya abhi rukna h

[11:40 PM] **You:** Kab tak

[11:40 PM] **Aashu:** chalte hai 20 min me

[11:40 PM] **Aashu:** khana kha le yelog tab

[11:41 PM] **You:** Ok
